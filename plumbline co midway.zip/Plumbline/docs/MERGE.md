# How Fieldwork Manager became part of Plumbline

**Merged 2026-10-03.** Fieldwork Manager (FM) used to be a separate program: raw Carlson download in,
checked `.fwk` working file out. Plumbline draws the survey. A surveyor's job crosses both, and the step
between them was done by hand.

The merge is deliberately **lopsided**: FM's *core* became part of Plumbline's engine where it can be
tested headless, its *window* was ported and opened beside Plumbline's, and its *standalone program* is
gone. Nothing was rewritten for the sake of it.

```
   RAW FIELD DATA                 the job folder                     THE SURVEY
   Carlson .fwk / F2F          Field Data/Week 1/Crew 6/           drawing, surface,
   duplicate PtNums            Field Book/ (1,717 codes)     -->   volumes, imagery,
   bad descriptions            Control/  Reports/                  DXF / KML / reports
            \_______________________ Field Data _______________________/
                    one job folder, two windows in one program
```

## Where each piece went

| Fieldwork Manager | Now | Notes |
|---|---|---|
| `program/fieldwork_manager/config.py` | `plumbline/fieldwork/config.py` | point blocks, the crew rule, correction rules, file extensions |
| `…/detectors.py` | `plumbline/fieldwork/detectors.py` | exact duplicates, look-alike numbers, points on top of each other |
| `…/io_carlson.py` | `plumbline/fieldwork/io_carlson.py` | `.fwk`, `.fwb`, `.chk`, `.fwc` read and write |
| `…/parse.py` | `plumbline/fieldwork/parse.py` | description parsing, line-order validation |
| `…/coord_systems.py` | `plumbline/fieldwork/coord_systems.py` | **kept as the coordinate-system library** (see below) |
| `…/steps_report.py` | `plumbline/fieldwork/steps_report.py` | the "what is left to fix" report |
| `…/utils_sort.py` | `plumbline/fieldwork/utils_sort.py` | natural sort; the one `QTableWidgetItem` subclass moved to the window |
| `…/clean.py`, `…/renumber_tool.py` | `plumbline/fieldwork/clean.py`, `renumber_tool.py` | the fix dialogs, ported as-is |
| `…/ui_main.py` (7,498 lines) | `plumbline/fieldwork/ui_main.py` | the window, PyQt6 → PySide6 |
| — | `plumbline/fieldwork/bridge.py` | **new**: the seam. Rows → project points, F2F → feature codes, checks |
| — | `plumbline/fieldwork/sample_real.py` | **new**: builds the Real World sample out of a real download |
| `program/run.py`, `Run Fieldwork Manager.bat` | *(retired)* | the window is `Survey > Fieldwork Manager` in the one program |

`plumbline/fieldwork/` is **Qt-free except `ui_main.py`** and a test enforces it: the CLI and the test
suite import the whole field-data core in a subprocess with `PySide6` poisoned, so a stray Qt import in
`detectors.py` fails the suite rather than the user's terminal.

## The four seams, and how each was settled

**A — the office code library.** FM read the office's Carlson Field-to-Finish standard; Plumbline drew
on its own generic starter layers. Now `bridge.feature_codes_from_f2f()` reads the F2F and produces
Plumbline `FeatureCode`s, so a job draws on `V-PROP-CRNR`, not `TOPO-GROUND`. The real job's 1,717-code
standard loads unchanged.

**B — one description engine.** FM validated (`/` starts free text, `PC`/`PT` are curve commands, the
code must exist in the F2F); Plumbline interpreted (`B`/`E`/`CLS` flags, `EP1` line instances). Both
dialects now run in one place. The rule that settled the conflict: **an exact whole-word match against
the code table wins, and only then are trailing digits read as a string number** — which is what a
1,717-code standard where 1,314 codes end in a digit actually needs. On the real job that is the
difference between resolving 3,749 and 3,763 of 3,773 descriptions.

**C — one QA pass, two windows.** FM's detectors (clerical errors) and Plumbline's surface checks
(geometric blunders) stayed where they were and are honest about it: FM cannot spike-test an elevation
without a surface, and Plumbline cannot know that point `600B` is a re-shot of `600`. Each window shows
what it can prove. Merging them into a single `qa.run_checks()` was proposed and **not** done — it would
have made a field-data check depend on a built TIN.

**D — ground scale: SAF, flipped on purpose.** This was the one place the merge could move real numbers.

| | Old FM | Old Plumbline | Now |
|---|---|---|---|
| Name | SAF | `GroundScale.factor` (a combined factor) | `SurfaceAdjustmentFactor.saf` |
| Direction | ground / grid | grid / ground | **ground / grid** |
| Scales from | origin (0, 0) | a base point | either, recorded in the project |
| `ground =` | `grid * saf` | `base + (grid - base) * factor` | `base + (grid - base) * saf` |

`SAF` is always slightly above 1 (a ground distance is longer than the grid distance between the same
two points); the old combined factor was its reciprocal, which is why the two must never be typed into
the same box. There is now exactly **one** implementation of the scaling - `SurfaceAdjustmentFactor` in
`core/crs.py` - and the field window's export code calls it (`fieldwork/coord_systems.py` keeps its old
function names and delegates), so the two halves of the program cannot drift apart by 170 ppm. Projects written before the rename stored the reciprocal and are **inverted automatically
on load** — old jobs move exactly as they did the day they were saved. *Scale from origin (0,0)* is a
one-click button because that is the TXDOT SOP.

## The coordinate system

**The field side's library wins.** `plumbline/fieldwork/coord_systems.py` is now the one list of Texas
systems, and `plumbline/core/crs.py` uses it as its Texas library rather than keeping a second copy.
It is the better of the two: NAD83(2011) codes only, metres and US survey feet side by side, a
`migrate_epsg()` that moves legacy 2275-2279 forward instead of handing back a deprecated zone, and a
pure-Python Lambert fallback so a job still converts on a machine where pyproj will not install. It was
tested on Windows against imagery, which is the other reason not to touch it.

**The default is unassigned, and that is a feature.** A new project starts with **no coordinate system**.
Drawing, surfaces, volumes, DXF and point handling never ask. The first tool that genuinely needs to
know where on the earth the job is — imagery, KML, GIS, reprojection, grid convergence — stops and says
so, by name:

> Grid convergence needs a coordinate system — this project's CRS is UNASSIGNED.
> Select CRS first (Coordinates > Project Coordinate System…).

## What deliberately did not merge

- **FM's standalone program.** No second launcher, no second settings folder, no divergent copy of the
  code. `python -m plumbline fieldwork job.fwk` does headlessly what the window does.
- **FM's hand-rolled LCC maths.** The numbers were kept; `pyproj`/PROJ does the projection work, with
  FM's pure-Python LCC kept as the fallback when pyproj is missing.
- **The two UIs were not made visually identical.** The field window is 7,500 lines of working UI. It was
  ported (four import lines, PyQt6 → PySide6) and opened beside the drawing rather than rebuilt as
  docks, because "the tools already work" beats "the two windows match".
- **FM's QA into Plumbline's QA** (Seam C above) — see the note there.

## How this was verified

| Check | Result |
|---|---|
| Full test suite | **228 passed** (`QT_QPA_PLATFORM=offscreen python -m pytest -q`) |
| Field-data core without Qt | in a subprocess with `PySide6` poisoned: imports, reads a `.fwk`, rounds half-up |
| Real World sample rebuild | two independent builds differ **only** in the `.plb` `saved` timestamp and the `Root` line of `Job Setup.txt` — every file holding data is byte-identical |
| The real job through the whole path | 3,773 points imported, 3,749 coded against the office standard, 390 polylines, 50 office layers, 14 duplicate numbers renumbered |
| Surface maths | `verification/check_surface_math.py` + three property-test harnesses, all pass |
| Libraries | `python -m plumbline doctor` — every library ok on Python 3.13 (this release targets 3.14) |

## Housekeeping

The workspace was left holding the merged project and nothing else. Removed once the suite was green:
FM's original `program/` tree and its uploads (every module is in the table above; the uploads are
byte-identical to `samples/Real World/Source/` — verified with md5), the Phase-1 review package and its
patch (the fixes are in the code; the review itself is `docs/CODE_REVIEW.md` and `docs/FIXES_APPLIED.md`),
the merge proposal (folded into this file), the standalone launcher, the project handoff snapshots, all
zip containers, and the generated caches (`__pycache__`, `.pytest_cache`, `.plumbline`).

Kept because it is not reproducible: `docs/WORKING_PROFILE.md` (how this workspace is run and what the
domain rules are), `docs/FUTURE_FIX_TOOLS.md` (your note that flags should be decision points, not
auto-fixes), and the Google Earth and steps-report examples under `docs/examples/`.

## Still open

1. **Curves.** FM understands `PC` / `PT` (point of curvature / tangency). Plumbline stores DXF bulges
   but has no code-level curve command. Should `PC`/`PT` become first-class in the parser?
2. **The renumber tool** (482 lines, with protected-number logic) is currently field-window only. Does it
   belong in Plumbline as a drawing-side tool too?
3. **Seam C**, above: one QA pass instead of two, if a field check is allowed to depend on a surface.
4. **Ship shape**: one program is now the answer. `Plumbline.bat` and the console script both open the
   same thing.
