# Plumbline v0.1 → fixes applied

Companion to `CODE_REVIEW.md`. Every finding from the review is now fixed, with a regression test
for each. **193 tests pass (up from 181)** — and on Python 3.13 the suite went from *6 failed /
175 passed* to **all green**.

- **Patch:** `review/plumbline-review-fixes.patch` — 25 files, +401 / −73. Applies cleanly to the
  shipped zip with `git apply` (verified against a fresh extraction).
- **Patched tree:** `/home/user/workspace_repo/plumbline` (also rebuilt at `/tmp/verify/plumbline`
  by applying the patch to a pristine checkout, and the suite passes there too).

```
$ git apply --check review/plumbline-review-fixes.patch && echo OK
OK
$ QT_QPA_PLATFORM=offscreen python3 -m pytest -q
193 passed in 68.54s
```

---

## Finding #1 — Python version policy (the big one)

`requires-python` was `>=3.14,<3.15`, and `doctor` treated anything older as a fatal error. But the
whole test suite — Qt UI tests included — passes on 3.13. Now:

| File | Change |
|---|---|
| `pyproject.toml` | `requires-python = ">=3.13"`; classifiers list 3.13 and 3.14 |
| `plumbline/doctor.py` | new `PREFERRED_PYTHON = (3, 14)` / `OLDEST_PYTHON = (3, 13)`. Below 3.13 = problem; 3.13 = *advisory note*; 3.14 = silent; above 3.14 = note (as before) |
| `install_windows.bat` | tries `py -3.14`, falls back to `py -3.13`, and uses whichever it found for the venv |
| `README.md`, `docs/WINDOWS_SETUP.md`, `requirements.txt` | reworded: "3.13 or newer, 3.14 recommended and tested" |

`doctor` now says, on 3.13:

```
Note: Python 3.13 works and passes the test suite, but this release was built and tested
against Python 3.14. If anything misbehaves, that is the first thing to rule out.
Everything Plumbline needs is installed and working.
```

and exits 0, instead of failing. 3.14 remains the recommended, fully tested version and stays the
one the Windows installer prefers — this widens the supported range rather than moving it.

## Finding #2 — one acre / cubic-yard convention

`area_to_acres` used the conventional 43,560 ft² but `volume_to_cubic_yards` converted metrically,
so 27 ftUS³ came out as 1.000006 cy and your quantities disagreed with an estimator doing `÷ 27`.

`core/units.py` now applies the earthwork convention (`÷ 27`) to foot units and converts exactly
for metric, with `SQ_FT_PER_ACRE` / `CU_FT_PER_CU_YD` / `CU_M_PER_CU_YD` named constants and a
comment explaining the choice. Added `volume_to_cubic_feet`. Metric behaviour is unchanged.

## Finding #3 — writer argument order

`write_dxf` was the only writer taking `(project, path)`. It is now `write_dxf(path, project, opts)`,
matching `write_landxml` / `write_gis` / `write_kml` / `write_points_csv` and every reader. All five
call sites updated (`cli.py`, `sample.py`, `ui/export_dialogs.py`, two test files).

It also fails loudly if you use the old order, because a silently-swapped call is the kind of thing
that eats an afternoon:

```
TypeError: write_dxf(path, project, opts) - the file path comes first; got Project where a path
was expected. Did you mean write_dxf(path, project)?
```

(Two of my own harnesses still used the old order, and this guard caught them instantly — that is
the point.)

## Finding #4 — dead code

- `ui/app_state.py`: `if not quiet or True:` → `if not quiet:`. The `quiet` parameter now actually
  works, so the rollback path in `edit()` stops emitting a repaint it said it would skip.
- `io/csv_points.py`: the `... if False else roles` expression is now an explicit early return with
  a comment saying why (a header that names E and N is trusted as-is).

## Finding #5 — the TIN locator race

- `core/surface.py`: `finder()` now builds under a per-TIN lock with double-checked locking, so the
  GUI and a background `prepare()` can no longer both construct a `TriFinder`. The fast path
  (`_finder is None` check) is untouched, so there is no hot-path cost — the benchmark is unchanged.
- A failure is no longer permanent: `ui/canvas.py` got `prepare_surface_locator()`, which forgets a
  failed attempt so the next hover retries, and `ui/main_window.py` uses it instead of starting a
  bare thread. (Also removes a private-method reach from `MainWindow` into `CanvasView`.)

**This turned up a second, latent bug the review had not spotted:** a `TIN` whose locator had been
built could not be pickled at all (matplotlib's `Triangulation` isn't picklable). Project snapshots
were safe because `Surface.__getstate__` drops `_tin`, but the class was a landmine. `TIN` now
implements `__getstate__`/`__setstate__` that drop the lock *and* the derived locator, so a TIN
pickles cleanly and rebuilds lazily. Covered by `test_tin_survives_a_pickle_roundtrip`.

## Finding #6 — incomplete undo state

`_STATE_KEYS` now includes `"name"`, so undo restores a rename and
`edit(discard_if_unchanged=True)` no longer silently swallows one. `path` is deliberately still
excluded — undoing an edit should never change which file you are saving to — and that is now
commented in the code.

## Finding #7 — documented the dedup tolerance

`build_tin`'s docstring now states that `dup_tol` snaps to a grid rather than testing true distance
(0.9·tol apart may survive; 1.1·tol apart may merge), so a user setting `dup_tol = 0.01` isn't
surprised. Pinned by `test_build_tin_documents_grid_snap_dedup`.

## Finding #8 — nits

- `core/tiles.py`: md5 for cache keys goes through `_md5()` with `usedforsecurity=False`, with a
  fallback, so it keeps working on FIPS-restricted builds.
- `core/geometry.py`: `arc_to_bulge` now raises `ValueError` on a full circle instead of returning
  `tan(π/2) ≈ 1.6e16`. The one caller (`landxml.py`) was *also fixed properly*: a closed LandXML
  `Curve` (Start == End) is now imported as a real circle — two antipodal vertices with two
  semicircular bulges, exactly like the DXF `CIRCLE` path — rather than being degraded. Verified
  round-trip: area = π·100 and circumference = 2π·10 to 1e-9 relative.

---

## Tests added (181 → 193)

| Where | Test |
|---|---|
| `test_portability.py` | rewrote both version-policy tests for the new range; the installer test now checks the 3.14→3.13 fallback |
| `test_core.py` | one acre/cy convention; undo restores a rename; `edit(discard_if_unchanged)` keeps a rename but drops a no-op; tile cache key stability; `arc_to_bulge` refuses a full circle |
| `test_surface.py` | the locator is built once under real thread contention (8 threads racing); TIN pickle round trip; grid-snap dedup |
| `test_io.py` | `write_dxf` parameter order; the old order raises a helpful `TypeError`; LandXML full-circle curve; CSV header-is-trusted |
| `test_ui.py` | one call site updated for the new signature |

The concurrency test uses a `threading.Barrier` to release all 8 threads at the same instant, and
asserts none of them deadlocked. (My first version of that test passed 7 to a barrier expecting 8
and hung the suite for 70 seconds — I fixed the test, which is a fair reminder that this class of
test needs as much care as the code.)

## Verification after the change

Re-ran all the independent harnesses from the review against the patched tree:

- `check_surface_math.py` — **ALL PASSED**. Volumes still exact to 4.1e-9; contours still exact on a
  plane to 5e-8. The cone check is now a proper convergence test: the mean deviation from a true
  circle matches the predicted inscribed-polygon sagitta (measured 1.4345e-2 vs predicted 1.4364e-2)
  and falls as the mesh is refined — proof it is discretisation, not a bug.
- `property_tests.py`, `property_tests2.py`, `property_tests3.py` — **ALL PASSED** (I corrected the
  expectations where *my* original tests were wrong, not the code).
- `bench.py` — no performance regression. 100k points: TIN 0.99 s, contours 0.13 s, volume 0.04 s,
  QA 1.09 s, save 0.83 s, load 0.37 s.
- CLI smoke test: `doctor` (now exit 0), `info`, `export-dxf`, `sample` all work.

## Not changed (deliberately)

- The conforming-Delaunay midpoint breakline strategy, the +1e-8 contour level offset, the
  local-CRS refusal, and the NSSDA honesty — these are the right calls, per the review.
- Pre-existing behaviour that is correct-but-surprising was documented rather than changed:
  multi-layer GeoPackage import reads the first layer unless the dialog picks one (by design);
  `volume_between` reports `cut` when the existing surface is above the proposed one (matches its
  docstring).
- Deeper items from the review's "next steps" are untouched: the linear `search_crs` scan over the
  full EPSG+ESRI catalogue, and the label-spacing edge case on closed contours. Both need a design
  decision (an index; a placement rule) rather than a patch.
