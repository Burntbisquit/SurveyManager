# Extending Plumbline

Three levels, from least to most work: **scripts** (one-offs), **plugins** (commands / importers / exporters that live in the menus),
and **editing the source** (everything under `plumbline/` is ordinary Python; the engine in `core/` and `io/` has no Qt in it).

## The data model (`plumbline/core/model.py`, `project.py`)

```python
project = Project(name, crs)            # everything for one job
project.crs            # ProjectCRS (pyproj CRS + optional ground scale + elevation unit/datum + datum strategy)
project.h_unit, v_unit # "ftUS" | "ft" | "m"
project.points         # {id: SurveyPoint(id, number:str, x=easting, y=northing, z (NaN = none), desc, layer, attrs)}
project.entities       # {id: Polyline | TextEntity}
   Polyline(id, layer, verts (N,3) x/y/z, closed, bulges (N,) DXF-style or None, kind, color, linetype, attrs, derived)
   TextEntity(id, layer, x, y, text, height, rotation, color, attrs, derived)
project.surfaces       # {id: Surface(name, pts (N,3), tris (M,3), params, style, report)}   .tin() -> TIN
project.layers         # {name: Layer(name, color, linetype, visible, locked)}
project.codes          # FeatureCodeTable
project.imagery / .checks    # imagery layers and recorded checks
project.settings       # dict saved with the project (contour interval, text height ...)
```
Conventions: **x = easting, y = northing** everywhere in code (the UI shows N,E by default); angles are azimuth degrees clockwise from north in `cogo`,
counter-clockwise from +x for text rotation; arcs are DXF bulges (`tan(sweep/4)`, positive = counter-clockwise).
`derived` marks generated entities (`"linework"`, `"contours:<surface>"`) that are replaced when regenerated.
After changing things directly, call `project.touch()` (the UI's `state.edit(...)` does it for you).

Useful functions: `project.add_point / add_polyline / add_text` (adding many points in a loop? pass `number=` yourself - without it every call scans all existing points for the next free number, which gets slow beyond ~10,000 - or build an `ImportBatch` and use `apply_batch`), `project.apply_batch(batch, dup_policy)`, `project.process_linework()`,
`project.apply_similarity(...)`, `project.reproject(new_crs)`, `project.assign_crs(new_crs)`, `project.point_arrays()`;
`core.surface.build_tin / build_surface_from_project / generate_contours / volume_between`, `TIN.z_at / contours / volume_to_datum / profile / sections`;
`core.crs.search_crs / ProjectCRS / make_transform / list_operations / combined_factor`; `core.cogo.inverse / direct / traverse / parse_bearing`;
`core.imagery.compute_check_stats`; `core.qa.run_checks`; `core.scene3d.build_scene / Camera / render_orbit / DepthSpec` (the 3D and depth views);
`core.maps.google_maps_url / maps_link_for_view`; `io.dxf_io / landxml / gis_io / kml_io / csv_points / f2f / reports`.

## Scripts

```python
# run via Plugins > Run Script, the console dock, or:  python -m plumbline run fence_offsets.py job.plb --save out.plb
import numpy as np
fence = [p for p in project.points.values() if p.desc.upper().startswith("FNC")]
print(len(fence), "fence points; mean elevation", np.mean([p.z for p in fence]))
with api.edit("Move fence layer"):            # one undo step (a no-op wrapper when run headless)
    for p in fence:
        p.layer = "SITE-FENCE-REVIEW"
        project.ensure_layer(p.layer, (255, 128, 0))
```

A 3D picture without opening the window (`core/scene3d.py` has no Qt in it):

```python
# python -m plumbline run picture3d.py job.plb
from PIL import Image
from plumbline.core import scene3d as S
sc = S.build_scene(project)                                    # the visible layers + surfaces, flattened to arrays
cam = S.Camera(azimuth=30, elevation=35, vexag=S.auto_vexag(sc.bounds))      # bearing it looks along / height angle
cam.fit(sc.bounds, 1400, 900)
Image.fromarray(S.render_orbit(sc, cam, 1400, 900, S.RenderOptions())).save("view3d.png")      # RGBA, transparent background
```

## Plugins

Files in the plugin folder (`~/.plumbline/plugins` unless `PLUMBLINE_HOME` is set) are imported at start-up and on *Reload*. The decorators register things:

```python
from plumbline.plugins import command, importer, exporter, Param
from plumbline.core.model import ImportBatch, SurveyPoint

@command("Survey/Shift elevations", params=[Param("dz", float, 0.0, "Add to every selected elevation")])
def shift(api, dz=0.0):
    with api.edit("Shift elevations"):
        for p in api.selected_points():
            p.z += dz

@importer("Space-delimited PNEZD (*.txt)", [".txt"])
def read_it(path, api):
    batch = ImportBatch()                                  # coordinates in the FILE's system; Plumbline asks which and converts
    for line in open(path):
        parts = line.split(None, 4)                        # point  northing  easting  elevation  [description...]
        if len(parts) < 4:
            continue
        num, n, e, z = parts[:4]
        batch.points.append(SurveyPoint(0, num, float(e), float(n), float(z), parts[4].strip() if len(parts) > 4 else ""))
    return batch                                           # (x = easting, y = northing)

@exporter("Point count (*.txt)", ".txt")
def write_it(project, path, api):
    open(path, "w").write(f"{len(project.points)} points\n")
```
(`api` offers `project`, `state`, `log()`, `message()`, `ask()`, `edit()`, `selected_points()`, `selected_entities()`, `points()`, `add_point()`, `import_batch()`.)
Commands run inside one undo step and are rolled back if they raise; a broken plugin file shows up in *Plugin Manager* and never blocks start-up.
`plumbline/plugins/examples/` has four small working examples.

## A new importer in the source

1. Write `io/myformat.py` with `read_myformat(path) -> ImportBatch` (points / polylines / texts / surfaces / layers, plus `batch.info` such as `{"epsg": 2276, "units": "ftUS"}`).
2. Add a branch in `ui/import_export.py::Importer.import_path` that calls `Importer._generic(path, batch, title, file_crs=..., unit=...)` - that gives you the CRS / units / duplicate-handling dialog for free.
3. Add a round-trip test in `tests/test_io.py`.

## Threading rule

Heavy work may run on a worker thread via `ui.widgets.run_blocking(...)`, but **only code that reads the project or computes pure results** - never mutate the project there
(the canvas repaints while the busy dialog is up). The pattern used for surfaces and contours: gather inputs on the GUI thread -> compute on the worker -> apply inside `state.edit(...)`
on the GUI thread (`core.surface.compute_contour_data` / `apply_contours` show it).

## Tests

`pytest` runs everything (`QT_QPA_PLATFORM=offscreen` on a machine without a display). `tests/test_ui.py` shows how to drive the real window: dialogs are auto-accepted by patching
`QDialog.exec`, clicks go through `QTest.mouseClick` on the canvas, and a tiny local HTTP server stands in for the tile service.
