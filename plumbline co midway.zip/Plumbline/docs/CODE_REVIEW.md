# Plumbline v0.1 — Independent Code Review

**Repo:** `Burntbisquit/SurveyManager` (the project ships as `plumbline/` inside `workspace-01a1009b-….zip`)
**Reviewer:** Arena.ai Agent Mode · **Date:** 2026-10-03
**Scope:** full source (21 kLOC Python across 64 modules), the test suite, the docs/claims, and the shipped sample data.

---

## 1. Verdict

This is a genuinely strong v0.1 — well above the quality bar for a from-scratch survey/CAD tool. The
parts that usually go wrong in this kind of software (volume integration, contour topology, breakline
enforcement, CRS/unit handling) are **correct**, and I verified that independently rather than by
trusting the test suite.

Two things stood out most:

1. **The README is honest.** That is rare and valuable. Every quantitative claim I could check held up
   (see §2). The "What was verified, and what wasn't" section is accurate, including the accurate
   admission that imagery isn't survey-grade.
2. **The test suite is real, not decorative.** 181 tests, and when I ran it here **175 passed** — the
   only 6 failures were the app's own "you must be on Python 3.14" gate (see Finding #1).

**Nothing I found would corrupt a deliverable.** There is no wrong-volume, wrong-coordinate or
wrong-unit bug. The findings below are about support surface, consistency and polish.

---

## 2. Claims I verified independently

I wrote my own test harnesses (in `review/`) that do **not** import the project's tests, so these are
independent confirmations.

### The core maths is right

| What I tested | Method | Result |
|---|---|---|
| `_split_volumes` — the exact cut/fill integrator | 20,000 random triangles vs an independent analytic half-plane/triangle integration | **worst relative error 4.1 × 10⁻⁹** |
| `volume_to_datum` | Inclined plane `z = 0.02x + 0.01y` over 100×100, 4 datum levels, vs closed-form SymPy integral | **exact to 1.4 × 10⁻¹⁶** |
| Region-clipped volumes | Half-plane clip vs full | ratio **0.5000000**; region entirely outside → **exactly 0** |
| Contour vertices | Plane `z = 0.5x + 0.25y`, level 5.0 | every vertex on the analytic line to **5 × 10⁻⁸** |
| Contour topology | Cone (closed loops) | all interior levels close correctly; levels clipped by the square domain correctly report open |
| Label placement | 628-unit loop | labels land on the contour (|r−100| < 0.5), carry elevation attrs, get suppressed on short lines |

> Note: an early check of mine "failed" at a 0.014 radius error on the cone. That is exactly the
> inscribed-polygon sagitta (0.339² / 8 ≈ 0.0144), not a defect. I mention it so you know the harness
> was calibrated, not just green.

### Breaklines are enforced exactly

- A ridge breakline across a flat 100×100 grid: **59 / 59 sub-segments appear as TIN edges**, `n_unenforced = 0`.
- `z_at(50, 50) = 12.000000` exactly, and approaches the ridge from both sides.
- No data points moved (the design claim holds).

### CRS and units

- 5 CRS pairs (2276↔32138, 2276↔4326, 32614↔4326, 3857↔4326, 2276↔6580): **max round-trip error 2.8 × 10⁻⁸** — sub-micrometre in feet.
- `Project.reproject` 2276 → 32138: horizontal and **vertical** units converted, text heights scaled, contour interval scaled — and it round-trips back to 1e-9.
- Local-coordinate projects correctly **refuse** geodetic operations (`LocalCRSError`) instead of silently producing nonsense. This is the right call and the message is actionable.
- Z is never pushed through a horizontal datum shift. Correct, and not everyone gets this right.

### Round trips

- **Save → load → save is byte-identical** (JSON, `saved` timestamp aside). NaN elevations, bulges, closed flags, surface geometry, settings, notes all survive.
- **DXF** export→import: layers, colours, arc bulges, 3D polylines with varying Z, and point elevations all preserved.
- **CSV**: comma+header, tab-delimited, and space-delimited files all sniff and parse correctly; blank elevations become NaN; thousands separators handled.
- **Undo/redo**, the four duplicate-import policies (`renumber`/`skip`/`overwrite`/`keep`), linework assembly (B/E/CLS flags, polygon closure, breakline flagging, no duplication on re-run), and feature-code parsing (10 cases incl. `EP-1`, `TREE 18 OAK`) — **all correct**.

### Statistics

- The NSSDA 95% figure correctly switches to the circular formula when RMSE_x/RMSE_y < 0.6, and says so in a note rather than hiding it.
- The Umeyama similarity fit recovers a planted scale 2.5 and rotation 37.000000° with **RMSE 1.9 × 10⁻¹⁴**.

### Documentation claims

- **"The 10-minute tour finds the planted bust on point 186"** — verified against the shipped `sample_site.plb`: point 186 is at z = 517.81 against neighbours at ~513.2, and `qa.run_checks` flags it ("largest 4.82"). Accurate.
- **"Every library has a ready-made 64-bit wheel for Python 3.14 on Windows"** — verified with `pip download --platform win_amd64 --python-version 3.14`: all 11 dependencies resolved, including optional `rasterio`. The claim holds.
- **Performance claims** (README: "2 CPU sandbox"). On this box:

  | Step | Claim | Measured |
  |---|---|---|
  | import 100k | 0.14 s | 0.26 s |
  | TIN build | 1.3 s | 1.03 s (199,972 tris) |
  | contours | 0.1 s | 0.14 s |
  | volume | 0.03 s | 0.04 s |
  | QA scan | 1 s | 1.14 s |
  | save / load | 0.9 / 0.5 s | 0.89 / 0.40 s |
  | DXF points only | 6 s | 8.4 s |
  | DXF with labels | 47 s | 61 s |
  | undo snapshot | 0.6 s | 1.39 s |

  Everything is the right order of magnitude and within ~2×. The two big numbers (DXF export) are
  honestly explained in the README as ezdxf creating 300,000 text entities one at a time.

### Safety posture (better than expected)

`.plb` files are **pure JSON** — I confirmed `to_dict()` never serialises a pickle; `pickle` is used
only for in-memory undo blobs in `Project.snapshot()`/`restore()`. So opening a project file somebody
emailed you is safe. The only arbitrary-code-execution surface is the plugin loader, which the README
explicitly warns about. That's a defensible split.

---

## 3. Findings

### Finding #1 — `requires-python = ">=3.14,<3.15"` is stricter than the code needs

**Severity: medium (blocked installs) — Evidence-backed**

This sandbox has Python 3.13.14, and the suite failed with 6 errors — all of them the app's own version
gate, none of them a real defect. So I copied the tree, relaxed *only* the version check in
`doctor.py` (`< (3, 14)` → `< (3, 10)`) and the `pyproject.toml` pin, and re-ran:

```
2 failed, 179 passed in 67.49s
```

The 2 remaining failures are `test_doctor_insists_on_python_3_14` and
`test_the_project_declares_python_3_14_only` — i.e. tests that assert the version policy itself.

**That means: numpy 2.3, scipy 1.17, shapely 2.1, pyproj 3.8, ezdxf 1.4, pyogrio 0.13, matplotlib 3.10
and PySide6 6.11 all work, and the entire Qt UI test suite passes, on Python 3.13.** The pin costs you
every user still on 3.13 (which is most of them, since 3.14 is brand new) for no technical reason.

Also note `install_windows.bat` hard-gates on `py -3.14`. A user with 3.13 gets "Python 3.14 was not
found" and stops, even though 3.13 would work.

**Recommendation:** widen to `>=3.12` (or whatever you actually want to support and test), and keep
`doctor`'s message informational rather than fatal for versions that are newer-but-untested or
older-but-working. If 3.14-only is a deliberate support-cost decision, that's legitimate — but then
`doctor` should say *why* rather than "too old".

---

### Finding #2 — Area and volume use inconsistent unit conventions

**Severity: low-medium (quantity accuracy ~6 ppm) — Evidence-backed**

```python
def area_to_acres(area, unit):
    if is_foot(unit):
        return area / 43560.0        # survey convention: 43,560 ft² per acre
    ...

def volume_to_cubic_yards(vol, h_unit, v_unit=None):
    m3 = vol * M_PER_UNIT[h_unit] ** 2 * M_PER_UNIT[v_unit]
    return m3 / (0.9144 ** 3)        # exact metric conversion
```

Measured:

```
43,560 ftUS²  ->  1.000000000 acres      (exact by construction)
but 43,560 ftUS² = 4046.872610 m² vs a true acre = 4046.856422 m²   -> +4.0e-06

27 ftUS³      ->  1.000006000 cy         -> +6.0e-06 vs 1 yd³
27 ft³        ->  1.000000000 cy         (exact)
```

So the same foot unit is treated as *conventional* for area and *exact-metric* for volume. The
practical consequence: on a foot-based job your **cubic yards are 6 ppm off from what an estimator
computing `volume / 27` would get**, while your acreage matches the conventional figure exactly.

**Recommendation:** pick one convention. For earthwork, `43,560 ft²/acre` and `27 ft³/cy` are what
estimators expect, and they're the conventional (not metric) definitions — so `volume_to_cubic_yards`
should probably divide foot-unit volumes by 27 rather than converting through metres. At minimum,
document which convention each function follows.

---

### Finding #3 — Writer argument order is inconsistent

**Severity: low (developer footgun) — I hit this for real**

```python
write_dxf(project, path, opts)          # project first
write_landxml(path, project, ...)       # path first
write_gis(path, project, ...)           # path first
write_kml(path, project, ...)           # path first
write_points_csv(path, points, ...)     # path first
```

All four `read_*` functions take `(path, ...)` first, so `write_dxf` is the odd one out. I called
`write_landxml(p, path)` from a test assuming the `write_dxf` order and got:

```
AttributeError: 'str' object has no attribute 'h_unit'
```

which is a confusing failure for a calling-convention mistake. Note the CLI itself uses both orders
(`dxf_io.write_dxf(pr, a.out, o)` in `cli.py`).

**Recommendation:** standardise on `(path, project, ...)` — it matches the reads, matches the majority
of writers, and reads naturally. Keyword-only for the rest.

---

### Finding #4 — Dead code / debugging leftovers

**Severity: low**

```python
# ui/app_state.py:109-112
def _after_change(self, kinds, quiet: bool = False):
    self._index = None
    if not quiet or True:            # <-- always true; `quiet` is a no-op
        self.changed.emit(set(kinds))
```

`if not quiet or True:` is a tautology — the condition was probably `if not quiet:` at some point and
got a `or True` bolted on while debugging. Its only caller that passes `quiet=True` is the exception
rollback path in `edit()`, which expects the refresh to be suppressed and now doesn't get it. The
`quiet` parameter should either work or be deleted.

```python
# io/csv_points.py:126-127
if {"easting", "northing"} <= used or {"latitude", "longitude"} <= used:
    return [r if r != "ignore" else "attr" for r in roles] if False else roles
```

`if False else roles` — an abandoned idea. The line always returns `roles`.

**Recommendation:** delete both; if the "blank columns become attributes" behaviour is still wanted,
implement it behind a flag.

---

### Finding #5 — Benign data race (and silent permanent failure) on the TIN point locator

**Severity: low**

`TIN.finder()` lazily builds a matplotlib `Triangulation` on first use. Two places also pre-build it in
a **daemon thread**:

```python
# ui/canvas.py:197 and ui/main_window.py:930
threading.Thread(target=tin.prepare, daemon=True).start()
```

`prepare()` calls `finder()`, which is not guarded by a lock:

```python
def finder(self):
    if self._finder is None:
        self._origin = self.pts[:, :2].mean(axis=0)
        ...
        self._finder = tri.get_trifinder()
```

The main thread can enter the same block concurrently (any `z_at`, contour, profile or volume call
does). Because `_origin` is deterministic and both threads compute the same value, **the result is
consistent — this is not a correctness bug.** But it means a ~1.5 s / large-allocation job on 100 k
points can be duplicated, and matplotlib's `TriFinder` construction isn't documented as thread-safe.

Separately, in `ui/canvas.py`:

```python
if tin._finder is None:
    if s.id not in self._prep_started:
        self._prep_started.add(s.id)
        threading.Thread(target=tin.prepare, daemon=True).start()
    return math.nan
```

`_prep_started` is never cleared, so if the thread ever raises, the elevation readout silently returns
NaN forever with no retry and no message.

**Recommendation:** add a `threading.Lock` around the builder (cheap), and clear the id from
`_prep_started` on failure — or set a "failed" flag and surface a message.

---

### Finding #6 — `_STATE_KEYS` omits `name` and `path`, so undo can't restore a rename

**Severity: low / latent**

```python
_STATE_KEYS = ("crs", "settings", "layers", "points", "entities", "surfaces",
               "imagery", "checks", "codes", "_next_id", "notes")
```

`Project.name` is not snapshotted. Consequences:

- **Undo does not restore a project rename.**
- `AppState.edit(..., discard_if_unchanged=True)` compares snapshots — so a plugin that only renames
  the project inside `api.edit()` has its undo entry **silently discarded** and the UI is never
  refreshed (the title bar keeps the old name until something else changes).

This isn't reachable through the stock UI — `save_as()` renames outside any `edit()` and calls
`update_title()` explicitly — so it's a trap for plugin authors, not a user-facing bug today.

**Recommendation:** add `"name"` to `_STATE_KEYS` (it's a one-word change and makes the undo model
complete).

---

### Finding #7 — Point de-duplication is grid-cell hashing, not distance

**Severity: informational**

```python
def key(self, x, y):
    return (int(round(x / self.tol)), int(round(y / self.tol)))
```

Two points 0.9·`tol` apart can land in different cells and both survive; two points 1.1·`tol` apart can
land in one cell and merge. At the default `tol` (`max(1e-4, extent × 1e-9)`) this is irrelevant —
but a user who sets `dup_tol` to, say, 0.01 ft expecting "merge anything within 0.01 ft" will get
"merge anything in the same 0.01 grid cell", which is a subtly different promise.

**Recommendation:** document it as a grid snap in the UI tooltip, or use a KD-tree radius query when
`dup_tol` is user-supplied.

---

### Finding #8 — Minor nits

- `core/tiles.py`: `hashlib.md5(self.url.encode())` as a cache key can raise on FIPS-restricted
  systems. `hashlib.md5(..., usedforsecurity=False)` avoids that (Python 3.9+).
- `core/geometry.py`: `arc_to_bulge(..., ccw=True)` maps sweep = 2π to `tan(π/2)` ≈ 1.6 × 10¹⁶ — a
  full circle is unrepresentable as a single bulge anyway. Only reachable via a degenerate
  start-angle == end-angle DXF ARC. Consider returning an error rather than a near-infinite bulge.
- `core/crs.py`: `search_crs` scans the entire EPSG + ESRI catalogue (tens of thousands of records)
  linearly on every keystroke, building a lowercased haystack per record at load. Fine at 400 results,
  but a trigram or prefix index would keep the dialog snappy on slower machines.
- `_place_labels` writes labels at the **midpoint** of a closed contour plus ±k·spacing. On a closed
  loop the label at station `total/2` and at `total` coincide on the ring — check visually that
  labels don't stack where a loop's start and midpoint are near each other.

---

## 4. Suggestions, in priority order

1. **Relax the Python pin** (#1). It's the highest-value change: it unblocks real users and the
   evidence says it costs you nothing. Re-run the suite on 3.13 and 3.14 and declare both supported.
2. **Settle the acre/cy convention** (#2) and write it in the docstring. Earthwork numbers going to a
   client should match the estimator's arithmetic.
3. **Standardise the writer signature** (#3) while the API is still v0.1 and nothing external depends
   on it.
4. **Delete the two debugging leftovers** (#4) and fix `quiet` (#5).
5. **Make `_STATE_KEYS` complete** (#6) before plugin authors build on the undo model.
6. **Add a `tests/` case for each of the above** — the suite is your best asset; these are all
   one-liner regressions to lock in.

## 5. What I'd leave alone

- The **conforming-Delaunay breakline strategy** (split at midpoint until it's an edge). It's simple,
  it never moves survey data, and it demonstrably works — 59/59 segments as edges. Don't trade it for
  a constrained-triangulation library that would change triangle topology.
- The **contour +1e-8 level offset**. It's the reason contours close perfectly and don't produce
  degree-4 vertex chains. Keep it.
- The **local-CRS refusal** rather than a silent identity transform. Refusing loudly is right.
- The **NSSDA honesty** — printing the imagery's stated accuracy next to the result is the single most
  professionally responsible decision in the codebase.

---

## 6. Harnesses used

Left in `review/` so you can re-run and extend them:

| File | What it does |
|---|---|
| `check_surface_math.py` | 20k-triangle volume integration vs independent analytic; plane/cone contour analysis |
| `property_tests.py` | Round trips: CRS, project save/load, transforms, CSV, DXF, GIS; unit consistency |
| `property_tests2.py` | Feature-code parsing, linework, duplicate policies, TIN breaklines, NSSDA, similarity fit, QA scan |
| `property_tests3.py` | Reprojection unit handling, breakline edge enforcement, acre/cy conventions |
| `bench.py` | README performance claims at 100k points |

Run with `QT_QPA_PLATFORM=offscreen python3 <file>` from a checkout.
