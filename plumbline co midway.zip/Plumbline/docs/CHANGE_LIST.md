# The change list, item by item

The list below is the user's own, kept in their words, with what was done and why. It is the
record of *decisions*, not a changelog: where a choice was open, the choice and its reason are
here so it is not re-argued later.

**State of the suite at the time of writing: 315 passed** (offscreen Qt, ~5 min). It was 229 when
this phase's work started.

## Where each item stands

| # | Item | State |
|---|---|---|
| 1 | SAF character limit + 4 | **done** — all three SAF boxes are sized for 18 characters (was 14) |
| 2 | Dialogs run off the screen | **done** — every dialog this program builds is clamped to the screen and its body scrolls |
| 3 | More Texas coordinate systems | **done** — 35 systems, every zone x realisation x unit; searchable by name, datum and unit |
| 4 | Vertical datums and geoid models (CONUS US) | **done** — core verified against NOAA's grids, Vertical Datum tab in the CRS dialog |
| 5 | Datum-transformation tab removed | **done** — reprojection only |
| 6 | Allow Downloads in the Coordinate System | **done** — the switch writes to settings and comes back on reopen (tested) |
| 7 | Titles in title form | **done** — menus, docks, tab labels, window titles and message titles |
| 8 | Tab and banner say "Vertical Datum" | **done** |
| 9 | "Surface Adjustment Factor (Ground Scale)" tab | **done** — origin-scaler button gone, "compute the SAF" under Advanced |
| 10 | Pan button and Esc releases the pick tool | **done** |
| 11 | Weeks-to-start field removed | **done** — `Field Data/` is created empty with a how-to note |
| 12 | Import: CSV points as a reference layer | **done** — one layer per role, its own numbering, out of the fieldwork list and the checks |
| 13 | Convert Field to Finish | **done** — Carlson's own layout by default, Custom for another layout (columns chosen by hand, rows ticked); it lives in Plumbline now, not only in the fieldwork bridge |
| 14 | Fieldwork Manager flags and linework cleanup | marked for later |
| 15 | Metadata columns and a Check Fieldwork dock | **done** — Source File / Parent Folder / Imported / Import are point-list columns shown or hidden from the headings (or View > Panels > Point Columns), every import writes the record; the checks have a dock of their own beside the point list, and a job with no code table is told so and offered both ways out |
| 16 | Imagery checks removed | **done** — the checks, the report and the view toggle are gone; measuring covers the ground, old records still open, and the Google Earth pins become reference points |
| 17 | "Point(s) Audit" report | open (decided: compared with the imported state) |
| 18 | Tools / File menu cleanup | **done** — the Tools menu is gone; its items are on Survey and File |

## Decisions this phase, and why

**Field to Finish — the columns are found by name, not by position.**  Carlson's export is 249 columns wide and
puts Code, Description, Symbol and **Symbol Size** first, then Layer and Entity Type in the fifth and sixth
columns.  A reader that takes the first six columns in order reads Symbol Size as the layer: every code lands on
a number, 216 layers become a column of symbol sizes, and nothing on screen says so.  So the facts are found by
the **header names** first ("Layer", "Entity Type", matched exactly, so "Distinct Pt Layer" and "Symbol Layer" -
which Carlson also writes - cannot stand in), and Carlson's own positions are the fallback for a file whose
header row was stripped.  All five drawing facts have to be found by name for the name pass to be used at all:
a map half from names and half from positions is how a table ends up 216 layers deep in numbers.

**The category is a row, not a column.**  ``Category,Corners,,,,...`` sits above the group of codes it labels.
Read as a code it puts a code called "CATEGORY" in the table; skipped, it takes the only hint about what to do
with the rows that have no layer of their own, which in the office standard is 0 rows but in a hand-made table
is exactly where the mystery rows are.  It is folded into the row's category, and a category of Corners /
Default / Utilities fills a blank layer with V-PROP-CRNR / V-SITE-DEFAULT / V-UTIL.  A file with no Category
rows at all invents *nothing*: the codes that have no layer get no layer, rather than a layer called "V-".

**Carlson is the default; Custom is one click away.**  A 1,717-code office standard converts with the format
radio already on Carlson, every code already ticked and one press of *Convert* - that is the case the item was
asked for, and it is the case that must not require an answer.  *Custom* exists for the table that is not
Carlson's: a combo per fact listing **every column of the file by letter and by whatever was written above it**
(so the headers may say anything, or nothing), a switch for "the first row is a header, not a code" that
re-reads the file, and the ticks.  A column map is applied live, and the ticks are remembered by *code* across a
re-read - changing the header switch must not lose the twenty codes the user just picked.

**Ticks, because half a standard belongs to somebody else.**  Rows are ticked individually, by rule (All, None,
Invert) and by the filter: type ``PROP`` and press *Only the matches* to bring in the property codes and leave
the 1,400 utility codes out.  The line under the buttons says what the ticks would produce - codes, points,
lines, layers, symbols - before anything in the job changes, and the Convert button is disabled while nothing
is ticked.

**Replace or merge, in the words of what it costs.**  Replacing a job's 42 starter codes with a file that does
not name 19 of them is a real loss, so the choice is a radio pair and the preview counts it: *"19 of this job's
42 code(s) are not in this file and would be dropped - Merge keeps them."*  Merge copies the job's table and
writes the file over it; nothing is written through the job's own table, so an undo gets it back exactly as it
was.  The counts are exact in both directions: 19 kept, 23 of the file's codes re-defining one the job had.

**One converter, two doors.**  The field window's *Load the Job's Feature Code Table* and the main window's
*Convert Field to Finish* now run the same code (`io/f2f.py`); the fieldwork bridge's
``feature_codes_from_f2f`` is a three-line delegate, and a test converts the real office standard through both
and compares all 1,717 codes name, kind, layer, symbol and breakline.  Fieldwork Manager also keeps its own
copy of Carlson's four entity numbers (it ships as a separate program and must not import Plumbline), so the
copies are pinned equal by a test rather than left to drift.

**A point file picked by mistake is refused by name.**  The likeliest wrong file in that dialog is the crew's
own download.  Turning it into hundreds of codes called "1" would be worse than saying so, so a header row that
names coordinates and a description - ``PT,N,E,Z,Desc`` or ``Northing,Easting,Elevation,Description`` - is
refused with *"looks like a point or job file, not a code table"*, which is the same guard the bridge has had in
the other direction since the merge.

**Where the item lives now.**  The item was written as *Tools > Convert Field to Finish*, and by the time it was
built there was no Tools menu (item 18): the field-data items had moved to **Survey**.  It sits there beside the
code table it fills, after Process Linework and before Feature Code Table, with no keyboard shortcut - it is a
once-a-year command, not a keystroke away.

**CSV reference layer — one layer per role.** Stake-out, Control and Other become three layers at
most; every CSV of a role merges into its layer. The alternative (one layer per file) multiplies
layers quickly on a job that imports control in five files, and the role is what a user reaches
for when they want to see or hide that kind of point.

**Point(s) Audit baseline — the imported state.** The audit reads against the point set as it
arrived, so the same report says the same thing tomorrow. A mark-your-own-baseline version was
offered and not taken.

**Check Fieldwork — its own dock.** The Points dock stays a point list; the check gets a dock of
its own next to it, opened from the View menu, so it can be sized and closed independently.

**Where the item lives now.** The column list was written as a tab, and a tab was the wrong shape:
the check needs the drawing (clicking a finding selects points, double-clicking zooms to them) and a
dock can be sized, floated or closed beside the point list.  It is `ui/check_dock.py`, its own tab
in the bottom group, and it is listed under **View > Panels** with the other panels.  It runs the
field window's own code (`fieldwork/bridge.check_project`, which is `run_checks` + `describe_flags`
over the project's field points), so the two windows cannot disagree about what a duplicate is; the
reference points are left out by `core/reference.py`, as item 12 decided.  Two things were added
that the field window has no equivalent of: the dock says when the drawing has changed since the
check last ran (the Run button gains a star) instead of silently showing stale findings, and the run
is logged to Messages.

**The code table is what makes the description check a check.**  A check that cannot run must say
so, or it gets switched off and stays off.  The dock resolves its vocabulary in order: the field
book this job remembers (`.fwb`), else the first one in the job folder's `Field Book` folder, else
the job's own feature codes *when they came from the office's table* (`settings["f2f_path"]`, set by
Convert Field to Finish) - and with none of the three it runs the three duplicate and position
checks, says on the strip that the description check cannot run, and offers both ways out when Run
is pressed: pick an existing `.fwb`, or build a code table from the Carlson export.  It never
invents a vocabulary: the 42-code starter library is not the office's standard, and checking
descriptions against it would flag most of a real job.

**Which columns start on.**  *Source File* and *Parent Folder* are shown, *Imported* and *Import*
are one click away.  The two that start on are the two columns a working file has always carried
(columns 7-8 of the `.fwk`, append-only since the beginning), so a job that arrives from the field
half shows something without being set up; the other two are about one import event and get in the
way of a long list.  The choice is remembered in settings, not on the job - which columns somebody
wants in front of them is a way of working, not a property of the job.

**SAF box — max characters you can type.** 18 characters rather than 14 on all three SAF entry
boxes (the CRS dialog and both on the field side). Qt does not impose a hard character limit on
these boxes, so the number that is felt is how much of the factor is visible at once; four more
characters is now visible. If what was meant was *more decimal places kept* (8 → 12), say so and
it is a one-line change.

**SAF box accepts 0.9 - 1.1 only.** Found while testing: the box used to take anything from 0.5 to
1.5, so a doubled digit or a reciprocal typed into the wrong box scaled every distance on the job
by that much with nothing on screen to show it. A real state-plane factor is within a few parts
per million of 1.0.

**NGVD29 says what it is.** Found while testing: the dialog said "No geoid model is needed for
this datum", which reads as "NGVD29 + 0 = ellipsoid height" — 26 m out in Texas. NGVD29 is tied to
NAVD88 by VERTCON, and NAVD88 is what carries the geoid, so the dialog now says exactly that and
the conversion row points at VERTCON first.

**The Tools menu is gone.** It held exactly four things - a window, an import, a folder and a
folder - and none of them is a tool.  The field-data half of the program (Fieldwork Manager and
Import Cleaned Field Data) now opens from **Survey**, above the checks and the code table, because
that is what it is: field data.  The job folder went to **File**, with the project it belongs to.
There is no Tools menu at all now, and the toolbar that used to be called Tools is **Draw Tools**,
so nothing in the window is called Tools any more.

**The job folder under File.** "Select Job Folder..." is one item doing what the two old
job-folder items did between them: it chooses the folder the Fieldwork Manager and the file
dialogs start from (the case it exists for is a download sitting in a job folder before there is
any project in it), it offers to open the project if the folder holds one, and choosing the folder
already in use opens it in the desktop's file manager.  "New Job Folder..." moved to File
unchanged.

**Search finds Texas first.** The systems with no EPSG code (the ten international-foot
realisations) cannot come back from a catalogue search at all, so the picker asks the Texas list
first: typing "international feet" returns those ten, and "nad27" returns the five Texas NAD27
zones above the other states' systems.

**CSV points are reference data, not field data.**  A CSV that arrives in the office is usually
somebody else's coordinates - a stake-out list from the engineer, published control, a design file
- and the one thing it must not do is pretend to be a crew's shots.  So the points get a role
(kind of point) and the role gets a layer: **STAKE-OUT**, **CONTROL**, **OTHER**.  The points
themselves still live in the project's own point store, so they draw, snap, select, move, hide by
layer and export with everything else; what changes is what the *program* does with them.  One
question - `reference.is_reference()` - separates the two lists, and the field-data paths
(the data-quality checks, the fieldwork list, the renumbering) all ask it first.  Each role also
has its own numbering space, which is the quiet reason this matters: a stake-out list numbered
from 1 does not collide with our own point 1, and importing control never renumbers a crew's work.

**A CSV is asked what it is before it lands.**  The import dialog leads with *"These points are:"*
- stake-out, control, other, or this job's field data - and defaults to **stake-out**, because the
common case is a file handed over, not our own download.  Choose a role and the layer box is taken
out of play (the role owns the layer, so a second place to type a layer name would only be a way
to get it wrong) and the status line says where the points are going in plain words.  The
field-data option is still there, one line below, for the times a CSV *is* the job's own points.

**A whole folder, one role, one dialog.**  *Survey > Import Points from Folder* reads every point
file in a folder (and, if asked, its sub-folders) and puts the lot on one role's layer.  Files are
read in the order a person reads them - `crew 2` before `crew 10`, natural sort, not string sort -
and a file that cannot be read is skipped and named in the log rather than imported half-guessed: a
control list with northing and easting the wrong way round is worse than no control list.  The
folder is then **recorded on the job** (`data_folder`, plus a short `reference_imports` history of
folder, role, file and point counts), so the next file dialog, the Fieldwork Manager and the same
job opened next month all start where the data came from.

**Export offers the lists separately.**  The point-CSV export now leads with *Points:* and a count
per list - field data, each reference role, or everything.  A stake-out file usually wants the
stake-out points, and until now the only way to get them was to select them by hand.

**The pick tool can drop a reference point.**  The Drawing toolbar has a *"New points are:"* box:
field data, or stake-out / control / other.  Chosen a role, a clicked point gets the role's layer
and the role's own next number, keeps out of the code table (a stake-out pin is not linework) and
is logged as what it is - "Stake-out point 3 added".

**What the data-quality checks do with reference points: nothing, and they say so.**  The checks
run on the fieldwork list and *name* what they set aside ("4 reference point(s) ... are not this
job's field data") instead of quietly ignoring it.  Before this, a control point numbered 7 would
have been reported as a duplicate of our own point 7 - a false alarm on every job that imports
control, which is how a check gets switched off and stays off.

**The imagery checks are gone.**  Checking points against imagery was a whole workflow: a tool that walked the
point list, a picking scale and a tolerance, a table of offsets, live NSSDA statistics, a suggested display nudge, a
CSV of picks, a thumbnail per pick, a report, a view toggle for the marks, and a section of this document's README.
All of it is removed - not hidden behind a setting.  **Measuring** covers the ground now: the imagery sits under the
drawing, and *Draw > Distance / Bearing* (or the Measure tool) gives the distance and bearing between two points,
which is what the check was being used to eyeball anyway.

**What "removed" had to include.**  The interface items (*Start Imagery Check*, *Imagery Check Report*, the *Imagery
Check* tool and its `K` shortcut, the *Imagery Check Marks* view toggle), the drawing of the check marks, the panel's
whole *Checks Against Survey Points* group (scale, tolerance, filter, table, statistics, suggested nudge, delete, CSV
export), the report and its renderers' entry, the README section and its two screenshots, and the simulated picks the
screenshot script wrote.  A removal that leaves a menu item, a toggle or a paragraph behind is not a removal.

**Old projects: the records are kept, and named.**  What is *not* removed is the data: `ImageryCheck` and
`Project.checks` stay, so a job written by an older version opens, shows what it holds and saves again unchanged -
pinned by a test that writes checks, reloads the file and checks every field, including the thumbnails.  The imagery
panel says so when it finds them ("N imagery check(s) saved by an older version are still kept with this project ...
use Draw > Measure between two points instead"), the Properties panel only grows a *Saved imagery checks* row when
there are any, and the record class itself says in its docstring why it is still here.

**Google Earth pins became reference points.**  Pins are coordinates somebody drew on the imagery, and since the
reference-layer work they have an obvious home: the pins import now puts every placemark on the **OTHER** layer, with
the pin's own name as its number and the same datum handling the KMZ export used, out of the fieldwork list and out of
the checks.  Re-importing a corrected pin file updates the pins instead of doubling them.  The comparison the old
workflow made automatically is a measurement now, and the panel says so.

**A bug the removal exposed.**  Regenerating the screenshots printed *"metadata lookup skipped: 'ImageryDock' object
has no attribute 'tol'"* - the imagery panel's **Source accuracy** note had been comparing the provider's stated
accuracy against the check tolerance, so removing the tolerance box broke the button that fetches the accuracy.  It
now states the figure and what it means in words, which is what the number was for, and the check caught it because
the screenshot script runs the real panel rather than a stub.  The datum-shift line the old imagery report used to
print (the operation PROJ chose, and its stated accuracy) moved to the Coordinate System Report rather than
disappearing with the report.

## What the tests check, and against what

The library is data, and data is where a mistake is quiet.  The newest work is a data-model
decision, which is the other place a mistake goes quiet.  Three new files:

- `tests/test_coordinate_systems.py` (17 tests). Every EPSG code is checked against PROJ's own
  database by *name* (a transposed 6584/6585 would put a job in the neighbouring zone and every
  distance would still look reasonable); each zone's natural origin is projected and must land on
  the declared false easting and northing **in the declared unit** (this is what catches a metric
  parameter list behind a feet system); the metre, US survey foot and international foot entries
  of one zone are compared to each other; and the geoid separation is checked for size *and sign*
  against NOAA's grid (N = -25.84 m at Mesquite — ellipsoid height is 84.8 ft *below* the
  published elevation, and adding instead of subtracting puts the number 170 ft out).
- `tests/test_ui.py` and `tests/test_ui_dialogs.py` pin the boundary of item 16: imagery tiles still arrive from a
  local tile server, still draw, still take a manual display nudge that leaves the survey untouched, and offline mode
  still never touches the network - while eighteen named controls, signals and methods must *not* exist on the panel
  any more, and no project statement writes a check.
- `tests/test_f2f.py` (20 tests).  The real office standard, end to end: 1,717 codes / 1,593 points / 124 lines
  / 216 layers / 133 symbols, compared code for code with the fieldwork bridge's door; a header row whose names
  say nothing falling back to Carlson's positions; somebody else's five-column layout mapped by hand; the
  Category rows folded and the "V-" layer that used to be invented now not invented; ticked rows, merged and
  replaced tables, a repeated code, and the job's own table never written through.  Then the dialog, driven: it
  opens on Carlson with everything ticked, the filter ticks only its matches, Custom follows the combos, the
  header switch re-reads the file with the ticks kept by code, and the whole way through the menu - file picked,
  codes applied, path remembered on the job, undo putting the table back.
- `tests/test_reference_layers.py` (13 tests). The two lists, end to end: a stake-out CSV lands on
  STAKE-OUT with its numbers intact while our own point 1 is untouched; the three roles keep three
  layers and six points out of three identical files; a plain import still renumbers against the
  field list (the old behaviour is pinned, not lost); the checks report the field duplicate *and*
  name the reference point they stepped over; a folder of files is read in name order, its
  unreadable file skipped by name, and the folder written into the job's settings; the import
  dialog defaults to stake-out and disables the layer box, the export dialog counts each list, and
  a stake-out list survives an export / import round trip as a stake-out list.
- `tests/test_crs_dialog.py` (12 tests). The real dialog, driven: the downloads switch is written
  to settings and read back on reopen, the legacy-zone button offers 2011 without applying it, the
  conversions in both directions are read off the screen text, a local project cannot reach the
  ground-scale tab, and the result round-trips through the project file with its datum, geoid and
  SAF intact.

## Verification

```
$ QT_QPA_PLATFORM=offscreen python3 -m pytest -q
315 passed in 302.48s (0:05:02)
```

The menus were read back off a live window rather than from the source: File now reads New /
Open / Open Sample / Open Recent / Save / Save As / **Select Job Folder / New Job Folder** /
Import / Export / Drawing as image / Exit, and Survey reads **Fieldwork Manager / Import Cleaned
Field Data / Import Points from File / Import Points from Folder** / the checks / **Convert Field to Finish** /
Feature Code Table / COGO, with no Tools menu between Reports and Plugins.

A test now checks the titles themselves: every menu item, dock title and toolbar title in the main
window is required to be in title case (small words and acronyms excepted), so the next dialog
added cannot quietly bring sentence case back.

The reference-layer path was driven through a live window, not just the tests: two CSVs (three
stake-out points, one control point) imported into a project holding its own points 1 and 2, with
the real dialog in front of them.  Both status lines read *"They become stake-out reference points
on layer STAKE-OUT, with their own point numbers - not this job's field data."*, the counts came
back `{'stakeout': 3, 'control': 1, 'other': 0, 'survey': 2}`, the field list was still `['1',
'2']`, the stake-out list was `['1', '2', '3']` (the file's own repeated 1 renumbered to 3 *inside
its own list*), the QA report read "No problems found." plus the named note about the 4 reference
points, and the menus were read back off the window: **Survey** now reads Fieldwork Manager /
Import Cleaned Field Data / **Import Points from File / Import Points from Folder** / the checks /
COGO, and the Drawing toolbar carries *"New points are: Field data (the fieldwork list) |
Stake-out (reference) | Control (reference) | Other (reference)"*.

Dialog fitting, measured offscreen on the 800x800 test screen: a dialog whose own content wants
1370 px is clamped to 712 px, its body goes into a scroll area (all 80 rows inside) and the
OK/Cancel row stays outside it and visible; a dialog that fits is not touched; Qt's own message
boxes and file dialogs are left alone.

The Check Fieldwork dock was read back off a live window, not just from the source: it is its own
dock tabified beside Points, it is in **View > Panels**, and its title is "Check Fieldwork" — the
two words the user's list asked for, which until now existed nowhere in the program.  On the
synthetic sample it reports `241 point(s) in the check` and finds the planted duplicate pair
(`7001 & 7001`, an ERROR row, 2 points); with a field book of 42 codes in the job folder the strip
reads *"Field book: office.fwb - 42 codes.  All four checks run."* and the description check adds
its own WARN row (`27 description(s) flagged unknown code (e.g. 'EP1 B')`).  Clicking that row
selects its points in the drawing; the same run on the real job (`samples/Real World`, 1,717-code
office standard) gives seven findings, each naming two to twenty-four points — the same pairs the
field window flags, which is the point of both windows calling one implementation.

The point list was read off the same window: `Source File` and `Parent Folder` on by default, all
four columns on after two clicks, the filter box narrowed to `3 of 241` for `2026-07-26`, and the
three rows it kept each read
`2026-07-26GPS S7.csv | 2026-07-26-S1 | 2026-10-04 06:01 | Cleaned field data (crew 7)`.
Twelve of the eighteen new tests drive the real window, the real importer and the real dock; the
other six pin the record itself (a Windows `folder\\file` source split into name and folder, a folder relative to the job,
the record surviving a save and a load, and a point with no record saying nothing rather than
guessing).
