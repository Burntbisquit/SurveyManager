# Future Fix Tools — Flags → Actions (Not Auto-Fix)

> You noted: we are catching the bulk, but we try too hard to automate. Instead, create flags + tools to solve them. Note for future, move-as-you-go.

## Principle

- **Flags are decision points, not auto-fixes.** System suggests, user decides.
- Keep OID-minimal + live-pull — edits happen in Edit table (source), error file is view.

## Four Tools (per flagged OID/token)

### 1. Fix Error — Best Guess Replace
- System proposes best guess: e.g., `asldf` → closest F2F code `NG` (Levenshtein + F2F frequency), or `ST PT` → insert `PC` between? `deck` → maybe `DECK`? 
- User clicks **Fix** → replaces token, validates (F2F + line-order re-check), updates Edit Desc live, clears flag if valid, may auto-clear second error if it was dependent (e.g., fixing code removes UnknownCode which also removes Orphan).
- Needs: `suggest_fix(flags, raw_desc, f2f_set)` helper in `parse.py`.

### 2. Key-In Fix Error — Replace Error Token (validate to accept)
- User types replacement for the flagged token only: e.g., flagged `UnknownCode:asldf` — user keys `NG` into inline editor.
- Validate: check `NG` in F2F (or `NG1` → `NG` via trailing strip). If valid, replace that token in RawDescription, keep rest, re-parse, update.
- UI: double-click flagged token in Desc Error row → small `QLineEdit` + Validate button.
- Same auto-clear of dependent second error.

### 3. Skip Error — Ignore
- User marks `Status=Skipped` or `Comments=Skip — ...` — row stays in `.chk` but filtered out? Or set `Status=Ignored` and future runs keep it suppressed per OID+flag?
- Needs: persist `Status` in unified `.chk` (already have column) + filter `Status != Skipped` option.
- Does NOT edit Edit table.

### 4. Key-In Entire Code — Full Rewrite
- User completely retypes entire code string: e.g., Raw `asldf` (OID 45) → user types `NG` → updates entire code after validation, removes second error token if it was inside same raw.
- UI: Edit button in Desc Error row → `QDialog` with `QLineEdit` for full RawDescription, Validate (parse + F2F + line-order), Save → updates Edit table's Description cell for that OID, re-runs line validation for that line_id across OIDs (may clear multiple flags).
- Catch if possible: after full rewrite, re-run `parse_desc_field` + `_validate_line_command_order` for that line_id, see if second error for same OID or other OIDs in same line now clears — show toast "also cleared LineOrderError on OID 46".

## Implementation Notes (for when we do it)

- All four tools edit **Edit table / .fwk source**, not the error file directly. Error file is regenerated or patched after edit + re-validate.
- Keep `DisplayTab` + `Flags` in `.chk` — after fix, re-run checks or patch that OID's row out.
- Need `edit_desc_for_oid(oid, new_raw_desc)` helper in `ui_main.py` that updates `edit_table.item(oid_row, 5)` + marks `edit_dirty`.
- Move-as-you-go: don't build all four at once. Start with **#2 Key-In Fix Token** (smallest) + **#3 Skip** — covers 80% of 10-year errors per your note.

## Move-as-you-go Plan

- Now: modules split done, flagged-only + unified done. Next session pick one tool (suggest #2) and wire it to Desc Error table double-click.
- Error catalog was removed 2026-09-23; use real field errors from uploads/ or live .chk as source.

