"""The seam between Fieldwork Manager and Plumbline.

Everything in here is Qt-free and has no opinion about user interfaces: it moves
data across the boundary in one direction (field data -> project) and answers
questions both halves need to ask.

    field data (raw download, .fwk, check report)
        |
        |  read_working_file / read_point_file      <- what the crew handed you
        v
    working rows  [OID, Pt#, N, E, Z, Desc, Parent, Source] + 7 spare columns
        |
        |  run_checks()                              <- duplicates, transpositions
        |  decode_crew()                             <- which crew shot this point
        v
    cleaned rows
        |
        |  batch_from_rows()                         <- ImportBatch
        v
    Plumbline project (points, then apply_feature_codes + process_linework)

Why the working-row list is the pivot
-------------------------------------
The 8-column list is the format Fieldwork Manager has always used internally and
it is also exactly what a consolidated .fwk file is on disk, so import and file
I/O are the same operation.  Column order is *positional* and must not be sorted:
source order carries meaning (a line's points must stay in the order the crew
shot them).  See ``natural_key`` in utils_sort for the display-side sorting rules.

Design rules carried over from Fieldwork Manager (do not "improve" these)
------------------------------------------------------------------------
* Round half up, never truncate: ``decimal.ROUND_HALF_UP`` via ``Decimal(str(x))``.
* Point numbers sort naturally with letters first; descriptions sort numbers
  first; N/E/Z sort truly numerically.  Never string-sort a number.
* Never renumber a point just because two numbers look similar - that is a
  *finding* for the check report, not an action.
"""
from __future__ import annotations

import csv
import csv as _csv
import math
import re
import tempfile
from collections import Counter, OrderedDict
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

from ..core import provenance as PROV
from ..core import reference as REF
from ..core.featurecodes import ENTITY_TO_KIND, FeatureCode, FeatureCodeTable
from ..io.f2f import CATEGORY_LAYERS, convert_file as convert_f2f_file
from . import config as F
from . import detectors as D
from . import io_carlson as IC
from . import parse as P

# --------------------------------------------------------------------------------------------- vocabulary
WORKING_COLUMNS = 8                 # the meaningful ones
WORKING_WIDTH = 15                  # .fwk files are written 15 wide (Corr_* metadata lives at 8..14)
OID, PTNUM, NOR, EAS, ELE, DESC, PARENT, SOURCE = range(8)

# ENTITY_TO_KIND (Carlson "Entity Type" -> Plumbline feature kind) is imported from
# core.featurecodes: it is a fact about feature codes, Plumbline's own Field-to-Finish converter
# needs it too, and two copies of a table like this is how the two halves start disagreeing.


# --------------------------------------------------------------------------------------------- numeric helpers
def to_float(value, default=None):
    """Parse a coordinate the way a surveyor's file writes it, or return *default*.

    Accepts '1,234.56' (thousands separator), ' 1234.5 ', '1234.5ft', '' and None.
    Never raises - a bad number in a field file is a finding, not a crash.
    """
    if value is None:
        return default
    if isinstance(value, (int, float)):
        f = float(value)
        return f if math.isfinite(f) else default
    s = str(value).strip().replace(",", "").replace("'", "")
    if not s:
        return default
    m = re.match(r"^([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)", s)
    if not m:
        return default
    try:
        f = float(m.group(1))
    except ValueError:
        return default
    return f if math.isfinite(f) else default


def round_half_up(value: float, places: int = 3) -> float:
    """Round the way survey practice expects (2.5 -> 3), never banker's rounding.

    0.5 rounding in Python's built-in round() is half-to-even: round(2.5) == 2,
    which is not what a surveyor checking a coordinate by hand will get.
    """
    if value is None or (isinstance(value, float) and not math.isfinite(value)):
        return value
    q = Decimal(1).scaleb(-places)
    return float(Decimal(str(value)).quantize(q, rounding=ROUND_HALF_UP))


# --------------------------------------------------------------------------------------------- working rows
def working_row(oid, pt, n, e, z, desc, parent="", source=""):
    """Build one 15-wide working row (the 7 spare columns are Corr_* metadata)."""
    return [str(oid), str(pt), str(n), str(e), str(z), str(desc), str(parent), str(source)] + [""] * 7


def row_xyz(row):
    """(n, e, z) as floats; any unparseable field comes back as None."""
    return to_float(row[NOR]), to_float(row[EAS]), to_float(row[ELE])


def row_is_usable(row) -> bool:
    """A row is usable only if it has a point number and a north/east pair."""
    if not row or len(row) < 5:
        return False
    if not str(row[PTNUM]).strip():
        return False
    n, e, _ = row_xyz(row)
    return n is not None and e is not None


def pad_row(row) -> list[str]:
    row = [str(c).strip() if c is not None else "" for c in row]
    if len(row) < WORKING_WIDTH:
        row = row + [""] * (WORKING_WIDTH - len(row))
    return row[:WORKING_WIDTH]


def read_working_file(path) -> list[list[str]] | None:
    """Read a consolidated field-data file (.fwk) into 15-wide working rows.

    Column count is not trusted: a 5-column file, an 8-column file and a
    15-column file with Corr_* metadata all arrive here and all leave as 15.
    Blank lines are dropped, order is preserved, encoding is utf-8-sig with a
    cp1252 fallback because that is what a Windows field tablet produces.
    """
    path = Path(path)
    last_error = None
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            rows: list[list[str]] = []
            with open(path, "r", encoding=enc, errors="strict", newline="") as fh:
                for raw in csv.reader(fh):
                    if not any(str(c).strip() for c in raw):
                        continue
                    rows.append(pad_row(raw))
            return rows or None
        except UnicodeDecodeError as exc:               # try the next encoding
            last_error = exc
        except OSError as exc:
            raise IOError(f"could not read {path.name}: {exc}") from exc
    raise IOError(f"could not decode {path.name}: {last_error}")


def write_working_file(path, rows, parent="", source="", width=WORKING_WIDTH) -> int:
    """Write working rows as a headerless .fwk (what the Edit Fieldwork tab saves).

    ``width=8`` reproduces the classic consolidated file; the default 15 leaves room
    for the Corr_* columns the check stage writes back.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    written = 0
    with open(path, "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh)
        for r in rows:
            r = pad_row(r)[:width]
            if parent and not r[PARENT]:
                r[PARENT] = parent
            if source and not r[SOURCE]:
                r[SOURCE] = source
            w.writerow(r)
            written += 1
    return written


# --------------------------------------------------------------------------------------------- source-file sniffing
def read_point_file(path) -> tuple[list[list[str]], dict]:
    """Read *any* of the field-file flavours and return (working rows, info).

    Recognised: a consolidated .fwk (8 or 15 columns), a headerless 5-column
    point CSV (N,E,Z,Desc,Code or Pt,N,E,Z,Desc), and a Carlson F2F code table
    (handled by :func:`feature_codes_from_f2f`, not here).

    ``info["kind"]`` says which one it was, so the caller can tell the user what
    it just did rather than guessing from the file extension.
    """
    path = Path(path)
    rows = read_working_file(path)
    if not rows:
        return [], {"kind": "empty", "path": str(path)}

    first = rows[0]
    looks_headered = first[OID].strip().casefold() in ("code", "oid", "seq", "sequence", "#")
    non_empty = [r for r in rows if any(c for c in r)]

    # 5-column point list: N,E,Z in the first three numeric slots, no point number.
    if not looks_headered and all(to_float(r[0]) is not None for r in non_empty[:5]) \
            and len({len([c for c in r if c]) for r in non_empty[:20]}) == 1:
        out = []
        for i, r in enumerate(non_empty, start=1):
            n, e, z = to_float(r[0]), to_float(r[1]), to_float(r[2])
            desc = r[3] if len(r) > 3 else ""
            if n is None or e is None:
                continue
            out.append(working_row(i, str(i), n, e, z if z is not None else "",
                                   desc, source=path.name))
        return out, {"kind": "points-5col", "path": str(path), "rows": len(out)}

    if looks_headered:
        raise ValueError(f"{path.name} looks like a Carlson F2F code table, not a job file - "
                         f"use feature_codes_from_f2f() instead")

    for i, r in enumerate(rows):                         # keep OIDs stable and numeric
        if not r[OID].strip():
            r[OID] = str(i + 1)
    return rows, {"kind": "working", "path": str(path), "rows": len(rows)}


# --------------------------------------------------------------------------------------------- crew decoding
def crew_of_point(point_number) -> int | None:
    """Which crew's number block this point number falls in (1-9), or None.

    Fieldwork Manager's rule: crew N owns N*10^k .. N*10^k+10^k-1 at every magnitude.
    So crew 7 owns 700-799, 7,000-7,999, 70,000-79,999 and so on, while 1-999 stays
    control and is shared by everyone.  This is how a downloaded file identifies its
    own crew without anybody typing a crew number.
    """
    n = None
    try:
        n = int(str(point_number).strip().split("-")[0].split("+")[0])
    except (TypeError, ValueError):
        base = re.sub(r"\d+$", "", str(point_number).strip())
        try:
            n = int(re.sub(r"\D", "", str(point_number)) or -1)
        except ValueError:
            return None
        n = n if base else n
    if n is None or n <= 0:
        return None
    if F.CONTROL_RANGE[0] <= n <= F.CONTROL_RANGE[1]:
        return None                                      # control: shared, no crew
    for crew in range(1, 10):
        if F.is_in_crew_block(str(n), crew):
            return crew
    return None


def crew_for_rows(rows) -> tuple[int | None, Counter]:
    """The crew a file belongs to, plus the vote count behind that answer.

    Returns (crew, votes).  ``crew`` is None when the file has no general points or
    the general points disagree, and the caller should ask rather than assume.
    """
    votes: Counter = Counter()
    for r in rows:
        if not row_is_usable(r):
            continue
        c = crew_of_point(r[PTNUM])
        if c:
            votes[c] += 1
    if not votes:
        return None, votes
    top, count = votes.most_common(1)[0]
    if len(votes) > 1 and count < 0.9 * sum(votes.values()):
        return None, votes                                 # genuinely mixed - do not guess
    return top, votes


def split_by_crew(rows) -> "OrderedDict[int | None, list[list[str]]]":
    """Split working rows into per-crew buckets, preserving order, None key last."""
    out: "OrderedDict[int | None, list[list[str]]]" = OrderedDict()
    for r in rows:
        c = crew_of_point(r[PTNUM]) if row_is_usable(r) else None
        out.setdefault(c, []).append(r)
    return OrderedDict(sorted(out.items(), key=lambda kv: (kv[0] is None, kv[0] or 0)))


def source_files(rows) -> list[str]:
    """Distinct source-file values, in the order they first appear."""
    seen: "OrderedDict[str, None]" = OrderedDict()
    for r in rows:
        s = r[SOURCE].strip() if len(r) > SOURCE else ""
        if s and s not in seen:
            seen[s] = None
    return list(seen)


def source_folder(source: str) -> str:
    """The dated crew folder a source file came from, e.g. '2026-7-22-AE'."""
    s = str(source or "").replace("/", "\\")
    return s.split("\\")[0].strip() if "\\" in s else ""


def folder_crew(rows) -> dict[str, int | None]:
    """crew number per *dated folder* - the unit a crew actually downloads.

    A file can contain nothing but shared control points, in which case the file on
    its own decodes to no crew; its folder-mates settle it.  That is why the crew is
    decided per folder and only then applied to the files inside it.
    """
    by_folder: dict[str, list[list[str]]] = {}
    for r in rows:
        by_folder.setdefault(source_folder(r[SOURCE] if len(r) > SOURCE else ""), []).append(r)
    return {k: crew_for_rows(v)[0] for k, v in by_folder.items()}


def source_file_crew(rows) -> dict[str, int | None]:
    """crew number per source file - what the Sample Real World folders are named from."""
    by_file: dict[str, list[list[str]]] = {}
    for r in rows:
        key = r[SOURCE].strip() if len(r) > SOURCE else ""
        by_file.setdefault(key, []).append(r)
    return {k: crew_for_rows(v)[0] for k, v in by_file.items()}


# --------------------------------------------------------------------------------------------- checks
def run_checks(rows, ne_tol: float | None = None, elev_tol: float | None = None) -> dict:
    """Run the three duplicate detectors.  Returns groups of row *indices*.

    exact  - same point number twice (two crews both claimed number 42)
    similar- numbers that differ by a transposition or a repeated digit (1234 / 1243)
    close  - different numbers, but within a foot or two of each other horizontally
    """
    exact = D.find_exact_duplicate_groups(rows)
    similar = D.find_similar_number_groups(rows)
    close = D.find_close_ne_groups(rows, tol=ne_tol or F.NE_TOLERANCE,
                                   elev_tol=elev_tol or F.ELEV_TOLERANCE)
    return {"exact": exact, "similar": similar, "close": close,
            "flagged_rows": sum(len(g) for g in exact) + sum(len(g) for g in similar),
            "report_rows": IC.build_check_report_rows(rows, exact, similar, close)}


def describe_flags(rows, f2f=None, fieldbook_path=None) -> dict[int, dict]:
    """Parse every description and report the ones with flags, keyed by row OID."""
    out = {}
    for r in rows:
        if not row_is_usable(r):
            continue
        parsed = P.parse_desc_field(r[DESC], f2f or set(), fieldbook_path=fieldbook_path)
        if parsed.get("flags"):
            out[int(r[OID]) if str(r[OID]).strip().isdigit() else r[OID]] = parsed
    return out


def summarise(rows) -> dict:
    """Counts a human wants before deciding whether to import anything."""
    usable = [r for r in rows if row_is_usable(r)]
    bad = [r for r in rows if not row_is_usable(r)]
    nums = []
    for r in usable:
        try:
            nums.append(int(str(r[PTNUM]).strip()))
        except ValueError:
            pass
    crews = Counter(c for c in (crew_of_point(r[PTNUM]) for r in usable) if c)
    files = source_files(rows)
    return {"rows": len(rows), "usable": len(usable), "unusable": len(bad),
            "duplicate_numbers": len(usable) - len({str(r[PTNUM]).strip() for r in usable}),
            "crews": sorted(crews), "files": len(files), "source_files": files,
            "min_number": min(nums) if nums else None, "max_number": max(nums) if nums else None}


# --------------------------------------------------------------------------------------------- feature codes (Seam A)
def feature_codes_from_f2f(f2f_csv_path, existing: FeatureCodeTable | None = None,
                           include_unknown: bool = True) -> tuple[FeatureCodeTable, dict]:
    """Build a Plumbline feature-code table from a Carlson F2F code table.

    The conversion itself now lives in :mod:`plumbline.io.f2f` - Plumbline converts a
    Field-to-Finish table in its own right (*Survey > Convert Field to Finish*), and this is the
    field window's door onto the same code rather than a second implementation of it.  What the
    F2F columns mean is documented there; what this function promises is that the field window
    and the main window convert the same file to the same table.

    ``include_unknown`` is accepted and ignored: an entity type Plumbline does not know is
    always kept as a point and reported in the stats, which is what this door has always done.
    """
    return convert_f2f_file(f2f_csv_path, existing=existing)


def write_fieldbook_from_f2f(f2f_csv_path, dest_fwb, name: str = "", commands=None) -> Path:
    """Convert a Carlson F2F code table into a Fieldwork Manager field book (.fwb).

    The two files carry the same six facts - it is a header change, not a
    conversion - but the .fwb is the one that travels with a job and can hold the
    code commands and correction rules agreed for that job.
    """
    headers, rows, _unknown = IC.read_carlson_fieldbook(Path(f2f_csv_path))
    dest_fwb = Path(dest_fwb)
    dest_fwb.parent.mkdir(parents=True, exist_ok=True)
    ok = IC.write_fwb_file(dest_fwb, headers, rows,
                           commands=commands or ["ST", "PC", "PT", "END", "X", "-", "/"], rules=[])
    if not ok:
        raise IOError(f"could not write {dest_fwb}")
    return dest_fwb


def f2f_code_set(f2f_csv_path) -> set[str]:
    """The set of code strings (casefolded) a description parser validates against.

    Fieldwork Manager's parser wants a path to a .fwb; a Carlson F2F is a CSV with
    different headers, so it is converted through a temporary .fwb rather than
    reimplementing the reader.
    """
    headers, rows, _unknown = IC.read_carlson_fieldbook(Path(f2f_csv_path))
    with tempfile.TemporaryDirectory() as td:
        fwb = Path(td) / "codes.fwb"
        IC.write_fwb_file(fwb, headers, rows)
        return P.build_f2f_set_from_fieldbook(fwb)


# --------------------------------------------------------------------------------------------- Plumbline handoff
def batch_from_rows(rows, crs=None, layer_override: str | None = None,
                    drop_unusable: bool = True, code_table: FeatureCodeTable | None = None):
    """Turn working rows into a Plumbline ImportBatch of points.

    Descriptions are carried through **exactly as the crew wrote them**, because
    Plumbline parses linework flags (B / E / CLS / string numbers) out of the raw
    description at draw time.  A second column keeps the raw text for the check
    report.  Elevations that are blank become NaN, not 0.0 - a point with no
    elevation must not drag a surface to sea level.

    Linework is deliberately *not* built here: ``Project.process_linework()``
    already does it from the code table, and duplicating that logic is how two
    programs start disagreeing about where a line goes.
    """
    from ..core.model import ImportBatch, NAN, SurveyPoint

    batch = ImportBatch()
    stats = {"points": 0, "skipped": 0, "no_elevation": 0, "duplicate_numbers": 0,
             "layer_override": layer_override or ""}
    seen: set[str] = set()
    when = PROV.now()
    for r in rows:
        if not row_is_usable(r):
            if drop_unusable:
                stats["skipped"] += 1
                continue
            continue
        n, e, z = row_xyz(r)
        num = str(r[PTNUM]).strip()
        desc = str(r[DESC]).strip()
        if num in seen:
            stats["duplicate_numbers"] += 1
        seen.add(num)
        if z is None:
            stats["no_elevation"] += 1

        layer = layer_override or "POINTS"
        if code_table is not None and desc:
            fc = code_table.get(desc) if hasattr(code_table, "get") else None
            if fc is not None and getattr(fc, "layer", ""):
                layer = fc.layer
        pt = SurveyPoint(id=0, number=num, x=float(e), y=float(n),
                         z=(NAN if z is None else float(z)), desc=desc, layer=layer)
        pt.attrs["fieldwork_source"] = str(r[SOURCE]).strip() if len(r) > SOURCE else ""
        pt.attrs["fieldwork_oid"] = str(r[OID]).strip()
        pt.attrs["fieldwork_raw_desc"] = desc
        # ... and the provenance the working file has always had (Parent Folder / Source File),
        # in one record the point list, the Properties panel and the check dock can all read.
        PROV.stamp_one(pt, file=str(r[SOURCE]).strip() if len(r) > SOURCE else "",
                       folder=str(r[PARENT]).strip() if len(r) > PARENT else "",
                       set=fieldwork_set(r), when=when)
        batch.points.append(pt)
        stats["points"] += 1
    batch.info["source"] = "fieldwork"
    return batch, stats


def apply_rows_to_project(project, rows, crs=None, code_table=None,
                          dup_policy: str = "renumber", layer_override: str | None = None) -> dict:
    """Import already-cleaned working rows into a live Plumbline project.

    This is the single call the Fieldwork Manager window makes when the user says
    "send this to Plumbline".  It returns a plain dict of counts so both the UI
    and tests can assert on it.
    """
    batch, stats = batch_from_rows(rows, layer_override=layer_override, code_table=code_table)
    if not batch.points:
        return {**stats, "applied": False, "reason": "no points"}
    if code_table is not None and getattr(code_table, "codes", None):
        # Prefer the field code table so the job draws in the office's own layers
        # rather than Plumbline's generic default standard.
        try:
            project.codes = code_table
        except Exception:
            pass
    result = project.apply_batch(batch, dup_policy=dup_policy, layer_override=layer_override)
    try:
        codes = project.apply_codes_to_points()
        stats["coded"] = codes.get("matched", 0) if isinstance(codes, dict) else 0
        unknown = codes.get("unknown", {}) if isinstance(codes, dict) else {}
        stats["unknown_codes"] = dict(sorted(unknown.items(), key=lambda kv: -kv[1])[:20])
        stats["unknown_code_points"] = sum(unknown.values())
    except Exception as exc:                             # a bad description must not lose the import
        stats["coded_error"] = str(exc)
    stats.update({"applied": True, "duplicates": result.get("duplicates", 0),
                  "renumbered": result.get("renumbered", 0), "skipped": result.get("skipped", 0)})
    return stats


#: The description parser's flag names, said the way somebody would say them out loud.  The raw
#: name travels beside it (``flag``), because that is what a fix tool will switch on.
FLAG_TITLES = {
    "UnknownCode": "Unknown code",
    "EmptyDescription": "No description",
    "OrphanCommand": "Orphan command",
    "MisplacedAfterSeparator": "Text before the separator",
    "SeparatorSpacingError": "Spacing at the separator",
    "LineOrderError": "Line command out of order",
}


def fieldwork_set(r) -> str:
    """How to name this import in one line: whose field data it is."""
    crew = crew_of_point(str(r[PTNUM]).strip()) if len(r) > PTNUM else ""
    return f"Cleaned field data (crew {crew})" if crew else "Cleaned field data"


def working_rows_from_project(project) -> tuple[list[list[str]], list[int]]:
    """The project's own field points as working rows, plus the point id behind each row.

    The drawing window's **Check Fieldwork** dock runs the same three detectors and the same
    description parser the field window runs, over the points that are actually in the project -
    so a check can be re-run after an edit without going back to the download.  Reference points
    are somebody else's coordinates and are left out (see :mod:`plumbline.core.reference`).
    """
    rows: list[list[str]] = []
    ids: list[int] = []
    for pid, p in project.points.items():
        if REF.is_reference(p):
            continue
        attrs = p.attrs or {}
        rec = PROV.of(p)
        desc = str(attrs.get("fieldwork_raw_desc") or p.desc or "")
        rows.append(working_row(attrs.get("fieldwork_oid") or pid, p.number, p.y, p.x, p.z,
                                desc, rec["folder"], rec["file"]))
        ids.append(pid)
    return rows, ids


def check_project(project, f2f=None, fieldbook_path=None) -> dict:
    """Run the field-data checks over a project's own points, as findings a dock can show.

    *f2f* is the field book's code set and *fieldbook_path* the file it came from (the parser
    also reads that job's command set and correction rules out of it).  Without a code set the
    description parsing is skipped rather
    than run against an empty vocabulary - every code would come back "UnknownCode", which is a
    hundred false alarms and not a check (the dock says which of the two it did).

    Returns {"rows", "ids", "findings", "stats", "flags", "code_checks"}.  Row indices in a
    finding index into "rows"; ``ids[i]`` is the project point the i-th row came from.
    """
    rows, ids = working_rows_from_project(project)
    out = {"rows": rows, "ids": ids, "findings": [], "stats": summarise(rows) if rows else {},
           "flags": {}, "code_checks": bool(f2f)}
    if not rows:
        out["findings"].append({"level": "info", "check": "no field points", "rows": [],
                                "message": "The project has no field points to check."})
        return out
    found = run_checks(rows)
    flags = describe_flags(rows, f2f, fieldbook_path=fieldbook_path) if f2f else {}
    oid_to_row = {str(r[OID]): i for i, r in enumerate(rows)}

    def rows_of(groups):
        return sorted({i for g in groups for i in g})

    exact, similar, close = found["exact"], found["similar"], found["close"]
    if exact:
        out["findings"].append({
            "level": "error", "check": "duplicate numbers", "rows": rows_of(exact),
            "message": f"{len(exact)} point number(s) are used more than once - "
                       f"{_group_words(rows, exact)}."})
    if similar:
        out["findings"].append({
            "level": "warn", "check": "look-alike numbers", "rows": rows_of(similar),
            "message": f"{len(similar)} group(s) of numbers differ by a transposition or a "
                       f"repeated digit - {_group_words(rows, similar)}."})
    if close:
        out["findings"].append({
            "level": "warn", "check": "points on top of each other", "rows": rows_of(close),
            "message": f"{len(close)} group(s) of different numbers are within the closeness "
                       f"tolerance of each other - {_group_words(rows, close)}."})
    if flags:
        by_flag: dict[str, dict] = {}
        for oid, parsed in flags.items():
            i = oid_to_row.get(str(oid))
            for flag in parsed.get("flags") or ["Description"]:
                name = str(flag).split(":")[0]
                rec = by_flag.setdefault(name, {"rows": set(), "sample": ""})
                if i is not None:
                    rec["rows"].add(i)
                if not rec["sample"]:
                    rec["sample"] = str(parsed.get("raw", "") or "")
        for name, rec in sorted(by_flag.items(), key=lambda kv: (-len(kv[1]["rows"]), kv[0])):
            title = FLAG_TITLES.get(name, name)
            out["findings"].append({
                "level": "warn", "check": title, "flag": name, "rows": sorted(rec["rows"]),
                "message": f"{len(rec['rows'])} description(s) flagged {title.lower()}"
                           + (f" (e.g. {rec['sample']!r})" if rec["sample"] else "") + "."})
    out["flags"] = flags
    if not out["findings"]:
        out["findings"].append({"level": "info", "check": "ok", "rows": [],
                                "message": "No problems found in the field data."})
    return out


def _group_words(rows, groups) -> str:
    """The first few groups, said in point numbers: "2 & 5, 12 & 21, ..."."""
    bits = []
    for g in groups[:3]:
        nums = [str(rows[i][PTNUM]).strip() for i in g if 0 <= i < len(rows)]
        bits.append(" & ".join(nums[:4]))
    if len(groups) > 3:
        bits.append("...")
    return ", ".join(bits)


__all__ = [
    "WORKING_WIDTH", "OID", "PTNUM", "NOR", "EAS", "ELE", "DESC", "PARENT", "SOURCE",
    "ENTITY_TO_KIND", "to_float", "round_half_up",
    "working_row", "row_xyz", "row_is_usable", "pad_row",
    "read_working_file", "write_working_file", "read_point_file",
    "crew_of_point", "crew_for_rows", "split_by_crew", "source_files", "source_file_crew",
    "source_folder", "folder_crew",
    "run_checks", "describe_flags", "summarise",
    "feature_codes_from_f2f", "f2f_code_set", "write_fieldbook_from_f2f",
    "batch_from_rows", "apply_rows_to_project",
    "working_rows_from_project", "check_project", "fieldwork_set",
]
