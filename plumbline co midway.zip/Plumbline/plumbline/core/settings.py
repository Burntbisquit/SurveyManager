"""User settings stored as JSON in ~/.plumbline (override with PLUMBLINE_HOME)."""
from __future__ import annotations

import copy
import json
import os
import threading
from pathlib import Path


def user_dir() -> Path:
    base = os.environ.get("PLUMBLINE_HOME")
    p = Path(base) if base else Path.home() / ".plumbline"
    p.mkdir(parents=True, exist_ok=True)
    return p


DEFAULTS = {
    "theme": "dark",
    "coord_order": "NE",            # order used for typed input: NE (Northing,Easting) or XY
    "angle_format": "quadrant",     # quadrant | azimuth
    "angle_dms": True,
    "angle_decimals": 0,
    "snap_px": 12,
    "point_size_px": 7,
    "label_px": 11,
    "crs_favorites": ["EPSG:2276", "EPSG:6584", "EPSG:32138", "EPSG:6583", "EPSG:4326", "EPSG:4269",
                      "EPSG:6318", "EPSG:26914", "EPSG:6343", "EPSG:32614", "EPSG:3857"],
    "recent_files": [],
    "tile_cache_dir": "",
    "offline_imagery": False,
    "proj_network": False,
    "secondary_readout": "EPSG:4326",
    "custom_tile_sources": [],
    "plugin_dirs": [],
    "point_columns": ["source_file", "source_folder"],   # extra columns in the point list
}


class Settings:
    def __init__(self, path: Path | None = None):
        self.path = Path(path) if path else user_dir() / "settings.json"
        self._lock = threading.Lock()
        self._data: dict = {}
        self.load()

    def load(self):
        try:
            self._data = json.loads(self.path.read_text("utf-8"))
        except Exception:
            self._data = {}

    def get(self, key, default=None):
        """User value, else the built-in default for known keys (a copy), else `default`."""
        if key in self._data:
            return self._data[key]
        if key in DEFAULTS:
            return copy.deepcopy(DEFAULTS[key])
        return default

    def set(self, key, value, save=True):
        self._data[key] = value
        if save:
            self.save()

    def save(self):
        with self._lock:
            try:
                tmp = self.path.with_suffix(".tmp")
                tmp.write_text(json.dumps(self._data, indent=2), "utf-8")
                tmp.replace(self.path)
            except OSError:
                pass

    def add_recent(self, path: str, limit: int = 10):
        rec = [p for p in self.get("recent_files", []) if p != path]
        rec.insert(0, path)
        self.set("recent_files", rec[:limit])

    @property
    def tile_cache_dir(self) -> Path:
        d = self.get("tile_cache_dir")
        p = Path(d) if d else user_dir() / "tiles"
        p.mkdir(parents=True, exist_ok=True)
        return p


_instance: Settings | None = None


def settings() -> Settings:
    global _instance
    if _instance is None:
        _instance = Settings()
    return _instance
