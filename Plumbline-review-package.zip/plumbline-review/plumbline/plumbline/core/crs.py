"""Coordinate-system manager.

* searchable PROJ/EPSG catalogue  (search_crs, resolve_crs, describe_crs)
* datum-transformation control    (list_operations, make_transform, strategies)
* ProjectCRS: the CRS a project lives in, plus optional grid<->ground scaling
* helpers for combined factors, plausibility checks and CRS suggestions

All transforms use x/y (easting/northing, lon/lat) ordering - never lat/lon.
Elevations are never pushed through PROJ (orthometric heights must not receive
ellipsoidal datum shifts); only unit conversion is applied to Z elsewhere.
"""
from __future__ import annotations

import math
import warnings
from dataclasses import dataclass, field

import numpy as np
from pyproj import CRS, Proj, Transformer
from pyproj.database import query_crs_info
from pyproj.enums import PJType, TransformDirection
from pyproj.transformer import TransformerGroup

from . import units as U

WGS84 = CRS.from_epsg(4326)
WEB_MERCATOR = CRS.from_epsg(3857)


# ----------------------------------------------------------------------------- catalogue
@dataclass(frozen=True)
class CrsRecord:
    auth: str
    code: str
    name: str
    kind: str                 # "projected" | "geographic"
    area: str
    method: str
    bounds: tuple | None
    text: str = ""

    @property
    def key(self) -> str:
        return f"{self.auth}:{self.code}"


_RECORDS: list[CrsRecord] | None = None


def all_records() -> list[CrsRecord]:
    global _RECORDS
    if _RECORDS is None:
        infos = query_crs_info(auth_name=None,
                               pj_types=[PJType.PROJECTED_CRS, PJType.GEOGRAPHIC_2D_CRS],
                               allow_deprecated=False)
        recs = []
        for i in infos:
            if i.auth_name not in ("EPSG", "ESRI"):
                continue
            kind = "projected" if i.type == PJType.PROJECTED_CRS else "geographic"
            aou = i.area_of_use
            bounds = (aou.west, aou.south, aou.east, aou.north) if aou else None
            area = aou.name if aou else ""
            method = i.projection_method_name or ""
            text = f"{i.auth_name}:{i.code} {i.code} {i.name} {area} {method}".lower()
            recs.append(CrsRecord(i.auth_name, str(i.code), i.name, kind, area, method, bounds, text))
        _RECORDS = recs
    return _RECORDS


def search_crs(query: str = "", kinds=("projected", "geographic"), limit: int = 400,
               auths=("EPSG", "ESRI")) -> list[CrsRecord]:
    """Case-insensitive AND-search over code, name, area of use and projection method."""
    q = query.strip().lower()
    tokens = q.split()
    scored = []
    for r in all_records():
        if r.kind not in kinds or r.auth not in auths:
            continue
        if tokens and not all(t in r.text for t in tokens):
            continue
        name = r.name.lower()
        if q and (q == r.code or q == r.key.lower()):
            score = 0
        elif q and name.startswith(q):
            score = 1
        elif q and q in name:
            score = 2
        else:
            score = 3
        scored.append((score, r.name, r))
    scored.sort(key=lambda t: (t[0], t[1]))
    return [r for _, _, r in scored[:limit]]


def resolve_crs(spec) -> CRS:
    """Accept CRS, int EPSG, 'EPSG:2276', '2276', WKT, PROJ string or ProjectCRS."""
    if isinstance(spec, ProjectCRS):
        return spec.crs
    if isinstance(spec, CRS):
        return spec
    if isinstance(spec, int):
        return CRS.from_epsg(spec)
    s = str(spec).strip()
    if s.isdigit():
        return CRS.from_epsg(int(s))
    return CRS.from_user_input(s)


def describe_crs(crs: CRS) -> dict:
    """Everything a user wants to see before trusting a CRS."""
    crs = resolve_crs(crs)
    d: dict = {"name": crs.name, "type": "Projected" if crs.is_projected else
               "Geographic" if crs.is_geographic else crs.type_name}
    try:
        a = crs.to_authority()
        d["authority"] = f"{a[0]}:{a[1]}" if a else "(custom)"
    except Exception:
        d["authority"] = "(custom)"
    try:
        ax = crs.axis_info
        d["axes"] = [f"{x.name} ({x.abbrev}) {x.direction}, {x.unit_name}" for x in ax]
        d["unit"] = (U.unit_from_factor(ax[0].unit_conversion_factor, ax[0].unit_name)
                     if (crs.is_projected or crs.is_engineering) else "deg")
        d["unit_name"] = ax[0].unit_name
    except Exception:
        d["axes"], d["unit"], d["unit_name"] = [], "m", "metre"
    d["datum"] = crs.datum.name if crs.datum else ""
    d["geodetic_crs"] = crs.geodetic_crs.name if crs.geodetic_crs else ""
    if crs.ellipsoid:
        d["ellipsoid"] = f"{crs.ellipsoid.name} (a={crs.ellipsoid.semi_major_metre:.3f} m, 1/f={crs.ellipsoid.inverse_flattening:.9f})"
    d["projection"] = crs.coordinate_operation.method_name if crs.is_projected and crs.coordinate_operation else ""
    d["params"] = ([(p.name, p.value, p.unit_name) for p in crs.coordinate_operation.params]
                   if crs.is_projected and crs.coordinate_operation else [])
    aou = crs.area_of_use
    d["area"] = aou.name if aou else ""
    d["bounds"] = tuple(aou.bounds) if aou else None
    d["deprecated"] = bool(getattr(crs, "is_deprecated", False)) if hasattr(crs, "is_deprecated") else False
    try:
        d["wkt"] = crs.to_wkt(pretty=True)
    except Exception:
        d["wkt"] = ""
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            d["proj"] = crs.to_proj4()
    except Exception:
        d["proj"] = ""
    return d


# ----------------------------------------------------------------------------- transformations
@dataclass
class OperationInfo:
    name: str
    accuracy: float | None
    available: bool
    area: str = ""
    grids: list = field(default_factory=list)


def list_operations(src, dst) -> list[OperationInfo]:
    """All candidate datum transformations PROJ knows between two CRSs, with accuracy."""
    src, dst = resolve_crs(src), resolve_crs(dst)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        tg = TransformerGroup(src, dst, always_xy=True)
    ops: list[OperationInfo] = []
    for t in tg.transformers:
        acc = t.accuracy if (t.accuracy is not None and t.accuracy >= 0) else None
        ops.append(OperationInfo(t.description, acc, True, getattr(t.area_of_use, "name", "") or ""))
    for u in tg.unavailable_operations:
        acc = getattr(u, "accuracy", None)
        acc = acc if (acc is not None and acc >= 0) else None
        grids = [g.short_name for g in getattr(u, "grids", []) or []]
        ops.append(OperationInfo(u.name, acc, False, getattr(getattr(u, "area_of_use", None), "name", "") or "", grids))
    return ops


class CoordTransform:
    """(x, y) -> (x', y') callable with an inverse and a human description."""

    def __init__(self, fwd, inv=None, description: str = "", accuracy: float | None = None,
                 identity: bool = False):
        self._fwd, self._inv = fwd, inv
        self.description = description
        self.accuracy = accuracy
        self.identity = identity

    def __call__(self, x, y):
        return self._fwd(x, y)

    def inverse(self) -> "CoordTransform":
        if self._inv is None:
            raise ValueError("transform is not invertible")
        return CoordTransform(self._inv, self._fwd, "inverse of " + self.description,
                              self.accuracy, self.identity)

    def apply(self, xy: np.ndarray) -> np.ndarray:
        xy = np.asarray(xy, float).reshape(-1, 2)
        x, y = self._fwd(xy[:, 0], xy[:, 1])
        return np.column_stack([x, y])


def _identity(x, y):
    return x, y


IDENTITY = CoordTransform(_identity, _identity, "identity", 0.0, identity=True)


def compose(*steps: CoordTransform) -> CoordTransform:
    steps = [s for s in steps if not s.identity]
    if not steps:
        return IDENTITY
    if len(steps) == 1:
        return steps[0]

    def fwd(x, y):
        for s in steps:
            x, y = s(x, y)
        return x, y

    inv_steps = [s.inverse() for s in reversed(steps)]

    def inv(x, y):
        for s in inv_steps:
            x, y = s(x, y)
        return x, y

    acc = [s.accuracy for s in steps if s.accuracy is not None]
    return CoordTransform(fwd, inv, " -> ".join(s.description for s in steps), max(acc) if acc else None)


def _proj_transform(t: Transformer, description: str) -> CoordTransform:
    acc = t.accuracy if (t.accuracy is not None and t.accuracy >= 0) else None

    def fwd(x, y):
        return t.transform(x, y)

    def inv(x, y):
        return t.transform(x, y, direction=TransformDirection.INVERSE)

    return CoordTransform(fwd, inv, description, acc)


def _geo_of(crs: CRS) -> CRS:
    return crs.geodetic_crs if (crs.is_projected and crs.geodetic_crs is not None) else crs


def _null_datum(src: CRS, dst: CRS) -> CoordTransform:
    """Projection maths only - treat source and destination datums as identical."""
    steps = []
    if src.is_projected:
        steps.append(_proj_transform(Transformer.from_crs(src, _geo_of(src), always_xy=True),
                                     f"unproject {src.name}"))
    if dst.is_projected:
        steps.append(_proj_transform(Transformer.from_crs(_geo_of(dst), dst, always_xy=True),
                                     f"project {dst.name}"))
    ct = compose(*steps)
    ct.description = f"{src.name} -> {dst.name} (no datum shift)"
    ct.accuracy = None
    return ct


_CACHE: dict = {}


def clear_transform_cache():
    _CACHE.clear()


def make_transform(src, dst, strategy: str = "auto") -> CoordTransform:
    """Build a transformer.

    strategy: "auto"        PROJ's best available operation (may be a ballpark null shift)
              "none"        no datum shift at all (pure projection maths)
              "op:<name>"   a specific operation, matched on its description
    """
    src, dst = resolve_crs(src), resolve_crs(dst)
    key = (src.srs, dst.srs, strategy)
    if key in _CACHE:
        return _CACHE[key]
    if src == dst:
        ct = IDENTITY
    elif strategy == "none":
        ct = _null_datum(src, dst)
    else:
        t = None
        if strategy.startswith("op:"):
            want = strategy[3:]
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                tg = TransformerGroup(src, dst, always_xy=True)
            for cand in tg.transformers:
                if cand.description == want or cand.description.startswith(want):
                    t = cand
                    break
        if t is None:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                t = Transformer.from_crs(src, dst, always_xy=True)
        ct = _proj_transform(t, t.description)
    _CACHE[key] = ct
    return ct


def set_proj_network(enabled: bool):
    """Allow PROJ to fetch datum-shift grids (NADCON5, GEOID18...) from cdn.proj.org on demand."""
    try:
        import pyproj.network as pn
        pn.set_network_enabled(bool(enabled))
    except Exception:
        pass
    clear_transform_cache()


# ----------------------------------------------------------------------------- ground scaling
@dataclass
class GroundScale:
    """Grid->ground scaling about a base point (ground = base + (grid-base)/factor)."""
    enabled: bool = False
    base_x: float = 0.0
    base_y: float = 0.0
    factor: float = 1.0        # combined factor = grid scale factor x elevation factor
    note: str = ""

    def to_dict(self):
        return {"enabled": self.enabled, "base_x": self.base_x, "base_y": self.base_y,
                "factor": self.factor, "note": self.note}

    @classmethod
    def from_dict(cls, d):
        return cls(bool(d.get("enabled")), float(d.get("base_x", 0)), float(d.get("base_y", 0)),
                   float(d.get("factor", 1.0)), d.get("note", ""))


def combined_factor(crs, lon: float, lat: float, ellipsoid_height_m: float) -> dict:
    """Grid scale factor, elevation factor and combined factor at a location."""
    crs = resolve_crs(crs)
    f = Proj(crs).get_factors(lon, lat)
    k = 0.5 * (f.meridional_scale + f.parallel_scale)
    a = crs.ellipsoid.semi_major_metre
    inv_f = crs.ellipsoid.inverse_flattening
    flat = 1.0 / inv_f if inv_f else 0.0
    e2 = 2 * flat - flat * flat
    s2 = math.sin(math.radians(lat)) ** 2
    R = a * math.sqrt(1 - e2) / (1 - e2 * s2)           # Gaussian mean radius of curvature
    ef = R / (R + ellipsoid_height_m)
    return {"grid_factor": k, "elevation_factor": ef, "combined": k * ef,
            "convergence_deg": f.meridian_convergence, "radius_m": R}


# ----------------------------------------------------------------------------- ProjectCRS
class LocalCRSError(ValueError):
    """Raised when a geodetic operation is asked of a project that uses local (non-geodetic) coordinates."""


_LOCAL_UNITS = {"ftUS": ("US survey foot", 1200 / 3937), "ft": ("foot", 0.3048), "m": ("metre", 1.0)}


class ProjectCRS:
    """The coordinate system a project's x/y live in (+ optional ground scaling)."""

    def __init__(self, crs, ground: GroundScale | None = None, vunit: str | None = None,
                 vdatum: str = "", strategy: str = "auto"):
        self.crs: CRS = resolve_crs(crs)
        self.ground = ground or GroundScale()
        d = describe_crs(self.crs)
        self._unit = d["unit"]
        self.vunit = vunit or self._unit
        self.vdatum = vdatum
        self.strategy = strategy

    # --- construction / persistence
    @classmethod
    def from_epsg(cls, code: int, **kw):
        return cls(CRS.from_epsg(code), **kw)

    @classmethod
    def local(cls, unit: str = "ftUS", **kw):
        """Plain local / assumed coordinates: no datum, no projection, no geodetic position."""
        uname, f = _LOCAL_UNITS.get(unit, _LOCAL_UNITS["ftUS"])
        wkt = ('ENGCRS["Local coordinates (no CRS)",EDATUM["Local engineering datum"],CS[Cartesian,2],'
               f'AXIS["easting (X)",east,ORDER[1],LENGTHUNIT["{uname}",{f!r}]],'
               f'AXIS["northing (Y)",north,ORDER[2],LENGTHUNIT["{uname}",{f!r}]]]')
        return cls(CRS.from_wkt(wkt), **kw)

    @property
    def is_local(self) -> bool:
        return bool(self.crs.is_engineering)

    def _need_geodetic(self, what: str = "this"):
        if self.is_local:
            raise LocalCRSError(f"{what} needs a real coordinate system - this project uses local coordinates. "
                                f"Assign one first (Coordinates > Project Coordinate System).")

    def to_dict(self) -> dict:
        try:
            a = self.crs.to_authority()
            auth = f"{a[0]}:{a[1]}" if a else None
        except Exception:
            auth = None
        return {"auth": auth, "name": self.crs.name, "wkt": self.crs.to_wkt(),
                "ground": self.ground.to_dict(), "vunit": self.vunit, "vdatum": self.vdatum,
                "strategy": self.strategy}

    @classmethod
    def from_dict(cls, d: dict) -> "ProjectCRS":
        crs = None
        if d.get("auth"):
            try:
                c = CRS.from_user_input(d["auth"])
                if not d.get("name") or c.name == d["name"]:
                    crs = c
            except Exception:
                crs = None
        if crs is None:
            crs = CRS.from_wkt(d["wkt"])
        return cls(crs, GroundScale.from_dict(d.get("ground", {})), d.get("vunit"), d.get("vdatum", ""),
                   d.get("strategy", "auto"))

    def copy(self) -> "ProjectCRS":
        return ProjectCRS.from_dict(self.to_dict())

    # --- properties
    @property
    def name(self) -> str:
        return self.crs.name

    @property
    def authority(self) -> str:
        try:
            a = self.crs.to_authority()
            return f"{a[0]}:{a[1]}" if a else "custom"
        except Exception:
            return "custom"

    @property
    def unit(self) -> str:
        return self._unit

    @property
    def unit_factor(self) -> float:
        return U.M_PER_UNIT.get(self._unit, 1.0)

    @property
    def is_projected(self) -> bool:
        return self.crs.is_projected

    @property
    def label(self) -> str:
        if self.is_local:
            return f"{self.name} [{U.LABEL.get(self._unit, self._unit)}]"
        s = f"{self.authority} - {self.name}"
        if self.ground.enabled:
            s += f"  [ground CF {self.ground.factor:.8f}]"
        return s

    @property
    def geographic(self) -> CRS:
        return _geo_of(self.crs)

    # --- ground <-> grid
    def to_grid(self, x, y):
        g = self.ground
        if g.enabled:
            return g.base_x + (np.asarray(x) - g.base_x) * g.factor, g.base_y + (np.asarray(y) - g.base_y) * g.factor
        return x, y

    def from_grid(self, x, y):
        g = self.ground
        if g.enabled:
            return g.base_x + (np.asarray(x) - g.base_x) / g.factor, g.base_y + (np.asarray(y) - g.base_y) / g.factor
        return x, y

    def _ground_step(self, to_grid: bool) -> CoordTransform:
        if not self.ground.enabled:
            return IDENTITY
        a, b = (self.to_grid, self.from_grid) if to_grid else (self.from_grid, self.to_grid)
        return CoordTransform(a, b, "ground->grid" if to_grid else "grid->ground", 0.0)

    # --- transforms
    def transform_to(self, dst, strategy: str | None = None) -> CoordTransform:
        """project coordinates -> dst coordinates."""
        strategy = strategy or self.strategy
        dst_crs = resolve_crs(dst)
        if self.is_local or dst_crs.is_engineering:
            if self.is_local and dst_crs.is_engineering:        # local -> local: only a unit change is possible
                k = self.unit_factor / U.M_PER_UNIT.get(describe_crs(dst_crs)["unit"], 1.0)
                return CoordTransform(lambda x, y: (np.asarray(x) * k, np.asarray(y) * k),
                                      lambda x, y: (np.asarray(x) / k, np.asarray(y) / k), "local unit change", 0.0)
            raise LocalCRSError("Local coordinates cannot be converted to or from a real coordinate system - "
                                "assign a coordinate system to the project instead.")
        steps = [self._ground_step(True), make_transform(self.crs, dst_crs, strategy)]
        if isinstance(dst, ProjectCRS):
            steps.append(dst._ground_step(False))
        return compose(*steps)

    def transform_from(self, src, strategy: str | None = None) -> CoordTransform:
        """src coordinates -> project coordinates."""
        strategy = strategy or self.strategy
        src_crs = resolve_crs(src)
        if self.is_local or src_crs.is_engineering:
            if self.is_local and src_crs.is_engineering:
                return self.transform_to(src, strategy).inverse()
            raise LocalCRSError("Local coordinates cannot be converted to or from a real coordinate system - "
                                "assign a coordinate system to the project instead.")
        steps = []
        if isinstance(src, ProjectCRS):
            steps.append(src._ground_step(True))
        steps.append(make_transform(resolve_crs(src), self.crs, strategy))
        steps.append(self._ground_step(False))
        return compose(*steps)

    def to_lonlat(self, x, y, target=None, strategy: str | None = None):
        """Project coords -> lon/lat. Default target is the project's own datum (no shift)."""
        self._need_geodetic("Longitude / latitude")
        tgt = self.geographic if target is None else resolve_crs(target)
        return self.transform_to(tgt, strategy)(x, y)

    def from_lonlat(self, lon, lat, source=None, strategy: str | None = None):
        self._need_geodetic("Longitude / latitude")
        src = self.geographic if source is None else resolve_crs(source)
        return self.transform_from(src, strategy)(lon, lat)

    def area_of_use_ok(self, x, y) -> tuple[int, int]:
        """(# inside the CRS area of use, total) for arrays of project coordinates."""
        aou = None if self.is_local else self.crs.area_of_use
        x = np.atleast_1d(np.asarray(x, float)); y = np.atleast_1d(np.asarray(y, float))
        if aou is None or len(x) == 0:
            return len(x), len(x)
        lon, lat = self.to_lonlat(x, y)
        lon, lat = np.asarray(lon), np.asarray(lat)
        w, s, e, n = aou.bounds
        ok = (lon >= w - 0.05) & (lon <= e + 0.05) & (lat >= s - 0.05) & (lat <= n + 0.05) & np.isfinite(lon)
        return int(ok.sum()), len(x)

    def convergence_at(self, x: float, y: float) -> float:
        """Meridian convergence (degrees) at a point - grid north vs true north."""
        self._need_geodetic("Grid convergence")
        gx, gy = self.to_grid(x, y)
        lon, lat = make_transform(self.crs, self.geographic, "none")(gx, gy)
        return Proj(self.crs).get_factors(lon, lat).meridian_convergence


# ----------------------------------------------------------------------------- suggestions
def suggest_crs(x: float, y: float, candidate_keys) -> list[tuple[str, str, float, float]]:
    """Which candidate CRSs have an area of use containing the inverse-projected (x, y)?

    Returns [(key, name, lon, lat)] sorted by distance to the area-of-use centre.
    """
    out = []
    for key in candidate_keys:
        try:
            crs = resolve_crs(key)
            if not crs.is_projected or crs.area_of_use is None:
                continue
            t = Transformer.from_crs(crs, _geo_of(crs), always_xy=True)
            lon, lat = t.transform(x, y)
            if not (math.isfinite(lon) and math.isfinite(lat)):
                continue
            w, s, e, n = crs.area_of_use.bounds
            if w <= lon <= e and s <= lat <= n:
                dist = math.hypot(lon - (w + e) / 2, lat - (s + n) / 2)
                out.append((dist, key, crs.name, lon, lat))
        except Exception:
            continue
    out.sort()
    return [(k, n, lo, la) for _, k, n, lo, la in out]


def format_lonlat(lon: float, lat: float, dms: bool = False, decimals: int = 8) -> str:
    if not dms:
        return f"{lat:.{decimals}f}, {lon:.{decimals}f}"

    def one(v, pos, neg):
        h = pos if v >= 0 else neg
        v = abs(v)
        d = int(v); m = int((v - d) * 60); s = (v - d - m / 60) * 3600
        return f"{d}°{m:02d}'{s:07.4f}\"{h}"

    return f"{one(lat, 'N', 'S')} {one(lon, 'E', 'W')}"


def default_favorites_records() -> list[tuple[str, str]]:
    """[(key, name)] for the favourites in settings (skipping unknown codes)."""
    from .settings import settings
    out = []
    for key in settings().get("crs_favorites", []):
        try:
            out.append((key, resolve_crs(key).name))
        except Exception:
            pass
    return out
