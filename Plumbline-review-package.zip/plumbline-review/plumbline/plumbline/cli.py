"""Command line entry points:  python -m plumbline [file]   |   run / info / export-dxf / sample / doctor / --version"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__


def _gui(path: str | None) -> int:
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QApplication

    from .ui.main_window import MainWindow

    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName("Plumbline")
    app.setApplicationVersion(__version__)
    win = MainWindow(open_path=path if (path and path.lower().endswith(".plb")) else None,
                     welcome=path is None)
    win.show()
    if path and not path.lower().endswith(".plb"):
        win.importer.import_path(path)
    return app.exec()


def _load(path: str):
    from .core.project import Project
    return Project.load(path)


COMMANDS = ("run", "info", "export-dxf", "sample", "doctor")


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    # `plumbline job.plb` opens that file. (argparse cannot mix an optional positional with sub-commands, so a leading
    # argument that is neither a command nor an option is taken as the file.)
    file_arg = None
    if argv and argv[0] not in COMMANDS and not argv[0].startswith("-"):
        file_arg, argv = argv[0], argv[1:]
    ap = argparse.ArgumentParser(
        prog="plumbline", usage="plumbline [-h] [--version] [file | command ...]",
        description="Plumbline - planimetric & topographic CAD for survey data",
        epilog="With no command the program opens. Give it a .plb project to open that project, or any CSV / DXF / "
               "LandXML / GIS file to import it.")
    ap.add_argument("--version", action="version", version=f"Plumbline {__version__}")
    sub = ap.add_subparsers(dest="cmd", metavar="command")
    r = sub.add_parser("run", help="run a Python script against a project without the GUI")
    r.add_argument("script")
    r.add_argument("project", nargs="?")
    r.add_argument("--save", help="save the project here afterwards")
    i = sub.add_parser("info", help="print a summary of a project")
    i.add_argument("project")
    d = sub.add_parser("export-dxf", help="export a project to DXF")
    d.add_argument("project")
    d.add_argument("out")
    d.add_argument("--text-height", type=float, default=None)
    s = sub.add_parser("sample", help="write the synthetic sample data (CSV, DXF, LandXML, GeoPackage, KMZ, project) to a folder")
    s.add_argument("folder", nargs="?", default="sample_data")
    sub.add_parser("doctor", help="check that Python and every library Plumbline needs is installed and working")
    a = ap.parse_args(argv)
    if file_arg and a.cmd:
        ap.error(f"unexpected file {file_arg!r} before the {a.cmd!r} command")

    if a.cmd == "info":
        pr = _load(a.project)
        print(f"{pr.name}\n  CRS: {pr.crs.label}")
        for k, v in pr.summary().items():
            print(f"  {k}: {v}")
        ext = pr.extents()
        if ext:
            print(f"  extents: E {ext[0]:,.3f} .. {ext[2]:,.3f}   N {ext[1]:,.3f} .. {ext[3]:,.3f}")
        return 0
    if a.cmd == "run":
        from .core.project import Project
        from . import plugins
        pr = _load(a.project) if a.project else Project("Script")
        err = plugins.run_script(a.script, pr, None, log=print)
        if err:
            print(err, file=sys.stderr)
            return 1
        if a.save:
            pr.save(a.save)
            print(f"saved {a.save}")
        return 0
    if a.cmd == "export-dxf":
        from .io import dxf_io
        pr = _load(a.project)
        o = dxf_io.DxfOptions(text_height=a.text_height or float(pr.settings.get("text_height", 2.0)))
        st = dxf_io.write_dxf(a.out, pr, o)
        print(f"wrote {a.out}: {st}")
        return 0
    if a.cmd == "doctor":
        from . import doctor
        return doctor.run()
    if a.cmd == "sample":
        from .sample import write_sample_files
        out = write_sample_files(Path(a.folder))
        for k, v in out.items():
            print(f"  {k:8} {v}")
        return 0
    return _gui(file_arg)
