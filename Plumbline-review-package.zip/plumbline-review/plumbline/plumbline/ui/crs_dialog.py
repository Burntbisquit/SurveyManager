"""Coordinate-system manager UI: CRS picker, project CRS dialog (assign / reproject / datum / ground), new-project dialog."""
from __future__ import annotations

import html
import math

import numpy as np
from PySide6.QtCore import QTimer, Qt, Signal
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout,
                               QGridLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
                               QPlainTextEdit, QPushButton, QRadioButton, QSplitter, QTableWidget, QTableWidgetItem,
                               QTabWidget, QTextBrowser, QVBoxLayout, QWidget)

from ..core import crs as C
from ..core import units as U
from ..core.settings import settings
from .widgets import Banner, Hint, dspin, error_box, run_blocking


def _html_details(key: str) -> str:
    try:
        d = C.describe_crs(key)
    except Exception as ex:
        return f"<p>Cannot read this coordinate system: {html.escape(str(ex))}</p>"
    e = html.escape
    rows = [("Identifier", d["authority"]), ("Type", d["type"]), ("Units", f"{d['unit_name']} ({d['unit']})"),
            ("Projection", d.get("projection") or "-"), ("Datum", d["datum"] or "-"),
            ("Ellipsoid", d.get("ellipsoid", "-")), ("Area of use", d["area"] or "-"),
            ("Axes", "; ".join(d["axes"]))]
    h = [f"<h3 style='margin-bottom:2px'>{e(d['name'])}</h3><table cellpadding='2'>"]
    for k, v in rows:
        h.append(f"<tr><td><b>{e(k)}</b></td><td>{e(str(v))}</td></tr>")
    h.append("</table>")
    if d["params"]:
        h.append("<p><b>Projection parameters</b></p><table cellpadding='2'>")
        for n, v, u in d["params"]:
            try:
                vv = f"{float(v):.10g}"
            except (TypeError, ValueError):
                vv = str(v)
            h.append(f"<tr><td>{e(str(n))}</td><td align='right'>{vv}</td><td>{e(str(u))}</td></tr>")
        h.append("</table>")
    if d.get("deprecated"):
        h.append("<p><b>Deprecated</b> - prefer a current realisation.</p>")
    return "".join(h)


# ----------------------------------------------------------------------------- picker
class CRSPicker(QWidget):
    """Search + favourites + details for choosing a coordinate system."""
    changed = Signal(str)             # key such as "EPSG:2276"

    def __init__(self, parent=None, kinds=("projected",), allow_kind_toggle: bool = False):
        super().__init__(parent)
        self.kinds = tuple(kinds)
        self.suggestions: list = []
        self._key = ""
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        row = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search by name or code:  texas north central  |  2276  |  UTM 14N  |  state plane ...")
        self.search.setClearButtonEnabled(True)
        row.addWidget(self.search, 1)
        self.chk_geo = QCheckBox("Include geographic (lat/lon)")
        self.chk_geo.setVisible(allow_kind_toggle)
        row.addWidget(self.chk_geo)
        self.star = QPushButton("☆ Favorite")
        self.star.setEnabled(False)
        row.addWidget(self.star)
        lay.addLayout(row)
        split = QSplitter(Qt.Horizontal)
        self.list = QListWidget()
        self.list.setUniformItemSizes(True)
        split.addWidget(self.list)
        self.detail = QTextBrowser()
        self.detail.setOpenLinks(False)
        split.addWidget(self.detail)
        split.setSizes([360, 340])
        lay.addWidget(split, 1)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.refresh)
        self.search.textChanged.connect(lambda: self._timer.start(180))
        self.chk_geo.toggled.connect(self.refresh)
        self.list.currentItemChanged.connect(self._on_current)
        self.star.clicked.connect(self._toggle_fav)
        self.refresh()

    # -- data
    def set_suggestions(self, items):
        self.suggestions = list(items)
        self.refresh()

    def _kinds(self):
        return self.kinds + (("geographic",) if self.chk_geo.isChecked() and "geographic" not in self.kinds else ())

    def refresh(self):
        q = self.search.text().strip()
        self.list.blockSignals(True)
        self.list.clear()
        favs = set(settings().get("crs_favorites") or [])

        def header(text):
            it = QListWidgetItem(text)
            it.setFlags(Qt.NoItemFlags)
            f = it.font()
            f.setBold(True)
            it.setFont(f)
            self.list.addItem(it)

        def add(key, name, extra=""):
            star = "★ " if key in favs else ""
            it = QListWidgetItem(f"{star}{key}   {name}{extra}")
            it.setData(Qt.UserRole, key)
            self.list.addItem(it)

        if not q:
            if self.suggestions:
                header("Suggested for your data")
                for key, name in self.suggestions:
                    add(key, name)
            header("Favorites")
            for key, name in C.default_favorites_records():
                try:
                    kind = "geographic" if C.resolve_crs(key).is_geographic else "projected"
                except Exception:
                    continue
                if kind in self._kinds():
                    add(key, name)
            header("Type to search the full EPSG / ESRI catalogue")
        else:
            res = C.search_crs(q, kinds=self._kinds(), limit=300)
            for r in res:
                add(r.key, r.name, f"   - {r.area}" if r.area else "")
            if not res:
                header("No matches")
        self.list.blockSignals(False)
        # keep the selection if still present
        for i in range(self.list.count()):
            if self.list.item(i).data(Qt.UserRole) == self._key:
                self.list.setCurrentRow(i)
                break

    def _on_current(self, cur, _prev):
        key = cur.data(Qt.UserRole) if cur else None
        if not key:
            return
        self._key = key
        self.detail.setHtml(_html_details(key))
        favs = set(settings().get("crs_favorites") or [])
        self.star.setEnabled(True)
        self.star.setText("★ Remove favorite" if key in favs else "☆ Add favorite")
        self.changed.emit(key)

    def _toggle_fav(self):
        if not self._key:
            return
        favs = list(settings().get("crs_favorites") or [])
        if self._key in favs:
            favs.remove(self._key)
        else:
            favs.append(self._key)
        settings().set("crs_favorites", favs)
        cur = self._key
        self.refresh()
        self.star.setText("★ Remove favorite" if cur in favs else "☆ Add favorite")

    def current_key(self) -> str:
        return self._key

    def select_key(self, key: str):
        self._key = key
        self.search.setText(key.split(":")[-1])
        self.refresh()
        for i in range(self.list.count()):
            if self.list.item(i).data(Qt.UserRole) == key:
                self.list.setCurrentRow(i)
                return


# ----------------------------------------------------------------------------- project CRS dialog
class CRSDialog(QDialog):
    """Assign / reproject / datum strategy / vertical / ground scale / calculator."""

    def __init__(self, state, parent=None):
        super().__init__(parent)
        self.state = state
        self.project = state.project
        self.setWindowTitle("Project Coordinate System")
        self.resize(980, 720)
        self.result_crs: C.ProjectCRS | None = None
        self.result_mode = "assign"
        cur = self.project.crs
        self._cur = cur
        root = QVBoxLayout(self)
        self.banner_current = Banner(f"Current: {cur.label}", "info")
        root.addWidget(self.banner_current)
        self.tabs = QTabWidget()
        root.addWidget(self.tabs, 1)

        # ---- tab 1: coordinate system
        t1 = QWidget()
        l1 = QVBoxLayout(t1)
        self.picker = CRSPicker(kinds=("projected",))
        l1.addWidget(self.picker, 1)
        self.fit = Banner("", "info")
        l1.addWidget(self.fit)
        modes = QGroupBox("What should happen to the coordinates in this project?")
        ml = QVBoxLayout(modes)
        self.r_assign = QRadioButton("Assign - my numbers ALREADY are in this system; just label them (nothing moves)")
        self.r_reproj = QRadioButton("Reproject - convert my coordinates from the current system into this one")
        ml.addWidget(self.r_assign)
        ml.addWidget(self.r_reproj)
        l1.addWidget(modes)
        self.tabs.addTab(t1, "Coordinate system")

        # ---- tab 2: vertical
        t2 = QWidget()
        f2 = QFormLayout(t2)
        self.cmb_v = QComboBox()
        for u in U.LINEAR_CHOICES:
            self.cmb_v.addItem(U.LABEL[u], u)
        self.cmb_v.setCurrentIndex(max(0, self.cmb_v.findData(cur.vunit)))
        self.ed_vdatum = QLineEdit(cur.vdatum)
        self.ed_vdatum.setPlaceholderText("e.g. NAVD88 (GEOID18), NGVD29, assumed local")
        f2.addRow("Elevation unit:", self.cmb_v)
        f2.addRow("Vertical datum (label):", self.ed_vdatum)
        f2.addRow(Hint("Elevations are never pushed through horizontal datum shifts. Changing the elevation unit here only relabels; "
                       "Reproject converts elevations when the horizontal unit changes (e.g. US ft to metres)."))
        self.tabs.addTab(t2, "Vertical")

        # ---- tab 3: datum transformation
        t3 = QWidget()
        l3 = QVBoxLayout(t3)
        l3.addWidget(Hint("Used when your coordinates meet lat/lon-based data (imagery, KML, GIS in another datum). "
                          "Without shift grids PROJ can only offer crude operations - the stated accuracy is shown, so you can judge."))
        self.cmb_strategy = QComboBox()
        self.cmb_strategy.addItem("Automatic - PROJ's best available operation", "auto")
        self.cmb_strategy.addItem("None - treat NAD83 / WGS84 lat-lon as the same (no datum shift)", "none")
        l3.addWidget(self.cmb_strategy)
        self.ops = QTableWidget(0, 4)
        self.ops.setHorizontalHeaderLabels(["Operation (project datum to WGS 84)", "Stated accuracy (m)", "Available", "Needs grid / note"])
        self.ops.horizontalHeader().setStretchLastSection(True)
        self.ops.setColumnWidth(0, 420)
        self.ops.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.ops.setEditTriggers(QAbstractItemView.NoEditTriggers)
        l3.addWidget(self.ops, 1)
        self.chk_net = QCheckBox("Allow PROJ to download datum-shift grids (NADCON5, GEOID...) from cdn.proj.org when needed")
        self.chk_net.setChecked(bool(settings().get("proj_network")))
        l3.addWidget(self.chk_net)
        self.lbl_strategy = QLabel("")
        l3.addWidget(self.lbl_strategy)
        self.tabs.addTab(t3, "Datum transformation")

        # ---- tab 4: ground scale
        t4 = QWidget()
        l4 = QVBoxLayout(t4)
        g = self.project.crs.ground
        self.chk_ground = QCheckBox("Use ground coordinates (scale grid distances to ground distances about a base point)")
        self.chk_ground.setChecked(g.enabled)
        l4.addWidget(self.chk_ground)
        gl = QFormLayout()
        self.sp_bx = dspin(g.base_x, -1e12, 1e12, 3)
        self.sp_by = dspin(g.base_y, -1e12, 1e12, 3)
        self.sp_cf = dspin(g.factor if g.factor else 1.0, 0.5, 1.5, 8, 0.00001)
        gl.addRow("Base easting:", self.sp_bx)
        gl.addRow("Base northing:", self.sp_by)
        gl.addRow("Combined factor (grid / ground):", self.sp_cf)
        l4.addLayout(gl)
        calc = QGroupBox("Compute the combined factor from location and height")
        cl = QGridLayout(calc)
        self.sp_h = dspin(0.0, -1000, 100000, 3)
        self.cmb_hu = QComboBox()
        for u in U.LINEAR_CHOICES:
            self.cmb_hu.addItem(U.LABEL[u], u)
        self.cmb_hu.setCurrentIndex(max(0, self.cmb_hu.findData(cur.vunit)))
        self.btn_center = QPushButton("Use centre of data as base point")
        self.btn_calc = QPushButton("Compute factor")
        cl.addWidget(QLabel("Average ellipsoid height:"), 0, 0)
        cl.addWidget(self.sp_h, 0, 1)
        cl.addWidget(self.cmb_hu, 0, 2)
        cl.addWidget(self.btn_center, 1, 0, 1, 2)
        cl.addWidget(self.btn_calc, 1, 2)
        self.lbl_cf = QLabel("")
        self.lbl_cf.setWordWrap(True)
        cl.addWidget(self.lbl_cf, 2, 0, 1, 3)
        l4.addWidget(calc)
        l4.addWidget(Hint("Ellipsoid height = orthometric (elevation) + geoid height. Using the orthometric elevation is a common approximation "
                          "(error is usually well under 1 ppm in Texas). Reproject converts existing coordinates between grid and ground; "
                          "Assign only relabels."))
        l4.addStretch(1)
        self.tabs.addTab(t4, "Ground scale")

        # ---- tab 5: calculator
        t5 = QWidget()
        l5 = QVBoxLayout(t5)
        row = QHBoxLayout()
        self.ed_e = QLineEdit()
        self.ed_n = QLineEdit()
        self.ed_e.setPlaceholderText("Easting / X")
        self.ed_n.setPlaceholderText("Northing / Y")
        b1 = QPushButton("Project coords to lat/lon")
        row.addWidget(self.ed_e)
        row.addWidget(self.ed_n)
        row.addWidget(b1)
        l5.addLayout(row)
        row2 = QHBoxLayout()
        self.ed_lat = QLineEdit()
        self.ed_lon = QLineEdit()
        self.ed_lat.setPlaceholderText("Latitude (decimal)")
        self.ed_lon.setPlaceholderText("Longitude (decimal)")
        b2 = QPushButton("Lat/lon to project coords")
        row2.addWidget(self.ed_lat)
        row2.addWidget(self.ed_lon)
        row2.addWidget(b2)
        l5.addLayout(row2)
        self.out = QPlainTextEdit()
        self.out.setReadOnly(True)
        l5.addWidget(self.out, 1)
        row3 = QHBoxLayout()
        self.btn_copy = QPushButton("Copy 'lat, lon' (paste into Google Earth / Maps search)")
        row3.addWidget(self.btn_copy)
        row3.addStretch(1)
        l5.addLayout(row3)
        self.tabs.addTab(t5, "Coordinate calculator")

        # ---- buttons
        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.button(QDialogButtonBox.Ok).setText("Apply")
        self.buttons.accepted.connect(self._accept)
        self.buttons.rejected.connect(self.reject)
        root.addWidget(self.buttons)

        # ---- wiring
        self.picker.changed.connect(self._candidate_changed)
        self.r_assign.toggled.connect(self._mode_changed)
        self.cmb_strategy.currentIndexChanged.connect(self._strategy_changed)
        self.ops.cellClicked.connect(self._op_clicked)
        self.chk_net.toggled.connect(self._net_toggled)
        self.btn_center.clicked.connect(self._use_center)
        self.btn_calc.clicked.connect(self._compute_cf)
        b1.clicked.connect(self._calc_to_ll)
        b2.clicked.connect(self._calc_from_ll)
        self.btn_copy.clicked.connect(self._copy_ll)
        self._last_ll = None
        self._strategy = cur.strategy
        self._init_done = False
        self._v_touched = False
        self.cmb_v.activated.connect(lambda _i: setattr(self, "_v_touched", True))
        self._init_state()
        self.cmb_v.setCurrentIndex(max(0, self.cmb_v.findData(cur.vunit)))
        self._init_done = True

    # ------------------------------------------------------------------ setup
    def _init_state(self):
        pr = self.project
        cur = pr.crs
        ext = pr.extents()
        sug = []
        if ext:
            cx, cy = (ext[0] + ext[2]) / 2, (ext[1] + ext[3]) / 2
            if cur.is_local:
                favs = [k for k, _ in C.default_favorites_records()]
                try:
                    sug = [(k, n) for k, n, _, _ in C.suggest_crs(cx, cy, favs)]
                except Exception:
                    sug = []
        self.picker.set_suggestions(sug)
        if not cur.is_local and cur.authority.startswith(("EPSG", "ESRI")):
            self.picker.select_key(cur.authority)
        if cur.is_local:
            self.r_assign.setChecked(True)
            self.r_reproj.setEnabled(False)
            self.r_reproj.setToolTip("A local project has no position on the earth, so there is nothing to convert from. Assign a CRS instead.")
            self.fit.set("This project uses local coordinates. Pick the coordinate system your numbers are really in and choose Assign.", "info")
        else:
            self.r_assign.setChecked(True)
        if not cur.is_local:
            self._fill_ops()
        else:
            self.lbl_strategy.setText("Datum transformations need a real coordinate system.")
            self.cmb_strategy.setEnabled(False)
            self.ops.setEnabled(False)
            self.tabs.setTabEnabled(3, False)
            self.tabs.setTabEnabled(4, False)
        sidx = self.cmb_strategy.findData(cur.strategy)
        self._strategy = cur.strategy
        if sidx >= 0:
            self.cmb_strategy.setCurrentIndex(sidx)
        self._strategy_changed()

    def _fill_ops(self):
        try:
            ops = C.list_operations(self.project.crs, 4326)
        except Exception as ex:
            ops = []
            self.lbl_strategy.setText(f"Could not list operations: {ex}")
        self.ops.setRowCount(len(ops))
        for i, o in enumerate(ops):
            self.ops.setItem(i, 0, QTableWidgetItem(o.name))
            self.ops.setItem(i, 1, QTableWidgetItem("unknown" if o.accuracy is None else f"{o.accuracy:g}"))
            self.ops.setItem(i, 2, QTableWidgetItem("yes" if o.available else "NO - grid missing"))
            self.ops.setItem(i, 3, QTableWidgetItem(", ".join(o.grids) if o.grids else (o.area or "")))
            if not o.available:
                for c in range(4):
                    self.ops.item(i, c).setForeground(Qt.gray)
        if self._cur.strategy.startswith("op:"):
            name = self._cur.strategy[3:]
            self.cmb_strategy.addItem(f"Specific: {name}", self._cur.strategy)

    # ------------------------------------------------------------------ reactions
    def _candidate(self) -> C.ProjectCRS | None:
        key = self.picker.current_key()
        if not key:
            return None
        return C.ProjectCRS.from_epsg(int(key.split(":")[1])) if key.startswith("EPSG:") else C.ProjectCRS(key)

    def _candidate_changed(self, key: str):
        # unless the user chose an elevation unit themselves, elevations follow the new system's unit
        if self._init_done and not self._v_touched:
            try:
                i = self.cmb_v.findData(C.describe_crs(key)["unit"])
                if i >= 0:
                    self.cmb_v.setCurrentIndex(i)
            except Exception:
                pass
        self._update_fit()

    def _mode_changed(self):
        self._update_fit()

    def _update_fit(self):
        cand = self._candidate()
        if cand is None:
            return
        pr = self.project
        if not pr.points:
            self.fit.set("", "info")
            return
        pts = list(pr.points.values())
        step = max(1, len(pts) // 400)
        x = np.array([p.x for p in pts[::step]])
        y = np.array([p.y for p in pts[::step]])
        try:
            if self.r_assign.isChecked():
                ok, tot = cand.area_of_use_ok(x, y)
                if ok == tot:
                    self.fit.set(f"All {tot} sampled points fall inside the area of use of this coordinate system - plausible.", "info")
                elif ok == 0:
                    self.fit.set(f"None of {tot} sampled points fall inside this coordinate system's area of use - probably the wrong system "
                                 f"(or wrong units / swapped N-E).", "bad")
                else:
                    self.fit.set(f"Only {ok} of {tot} sampled points fall inside this coordinate system's area of use.", "warn")
            else:
                self.fit.set("Coordinates will be converted using the datum strategy chosen on the Datum tab.", "info")
        except Exception as ex:
            self.fit.set(f"Could not test the fit: {ex}", "warn")

    def _strategy_changed(self):
        self._strategy = self.cmb_strategy.currentData() or "auto"
        txt = {"auto": "PROJ picks the most accurate operation it can run. If shift grids are missing it falls back to a "
                       "ballpark (often zero) shift - see the table for stated accuracies.",
               "none": "No datum shift is applied: NAD83 / WGS84 positions are treated as identical. This is the usual practical "
                       "choice when the imagery or KML itself is only good to a few metres."}.get(self._strategy, f"Using {self._strategy}")
        self.lbl_strategy.setText(txt)

    def _op_clicked(self, row, col):
        name = self.ops.item(row, 0).text()
        avail = self.ops.item(row, 2).text().startswith("yes")
        if not avail:
            self.lbl_strategy.setText("That operation needs shift grids that are not installed. Enable the network option below, "
                                      "or install the grids, then it can be used.")
            return
        data = "op:" + name
        idx = self.cmb_strategy.findData(data)
        if idx < 0:
            self.cmb_strategy.addItem(f"Specific: {name}", data)
            idx = self.cmb_strategy.count() - 1
        self.cmb_strategy.setCurrentIndex(idx)

    def _net_toggled(self, on):
        settings().set("proj_network", bool(on))
        C.set_proj_network(bool(on))
        self._fill_ops()

    def _use_center(self):
        ext = self.project.extents()
        if ext:
            self.sp_bx.setValue((ext[0] + ext[2]) / 2)
            self.sp_by.setValue((ext[1] + ext[3]) / 2)
            self.chk_ground.setChecked(True)

    def _compute_cf(self):
        cand = self._candidate() or self.project.crs
        base = C.ProjectCRS(cand.crs) if isinstance(cand, C.ProjectCRS) else cand
        try:
            lon, lat = base.to_lonlat(self.sp_bx.value(), self.sp_by.value())
            h_m = self.sp_h.value() * U.M_PER_UNIT[self.cmb_hu.currentData()]
            f = C.combined_factor(base.crs, float(lon), float(lat), h_m)
        except Exception as ex:
            error_box(self, "Combined factor", f"Could not compute: {ex}")
            return
        self.sp_cf.setValue(f["combined"])
        self.chk_ground.setChecked(True)
        self.lbl_cf.setText(f"Grid scale factor {f['grid_factor']:.8f}  x  elevation factor {f['elevation_factor']:.8f}  =  "
                            f"combined {f['combined']:.8f}.   1000 ground units = {1000 * f['combined']:.4f} grid units.")

    def _calc_crs(self):
        cand = self._candidate()
        return cand if (cand is not None and not self.project.crs.is_local and False) else (cand or self.project.crs)

    def _calc_to_ll(self):
        try:
            crs = self.project.crs
            if crs.is_local:
                crs = self._candidate()
                if crs is None:
                    raise ValueError("Pick a coordinate system on the first tab first.")
            lon, lat = crs.to_lonlat(float(self.ed_e.text().replace(",", "")), float(self.ed_n.text().replace(",", "")))
            self._show_ll(crs, float(lon), float(lat), float(self.ed_e.text().replace(",", "")), float(self.ed_n.text().replace(",", "")))
        except Exception as ex:
            self.out.setPlainText(f"Error: {ex}")

    def _calc_from_ll(self):
        try:
            crs = self.project.crs if not self.project.crs.is_local else self._candidate()
            if crs is None:
                raise ValueError("Pick a coordinate system on the first tab first.")
            lon, lat = float(self.ed_lon.text()), float(self.ed_lat.text())
            x, y = crs.from_lonlat(lon, lat)
            self._show_ll(crs, lon, lat, float(x), float(y))
            self.ed_e.setText(f"{float(x):.4f}")
            self.ed_n.setText(f"{float(y):.4f}")
        except Exception as ex:
            self.out.setPlainText(f"Error: {ex}")

    def _show_ll(self, crs, lon, lat, x, y):
        self._last_ll = (lat, lon)
        u = U.LABEL.get(crs.unit, crs.unit)
        lines = [f"Project coordinates:  E {x:,.4f}   N {y:,.4f}  ({u})",
                 f"Latitude / longitude: {lat:.9f}, {lon:.9f}",
                 f"                      {C.format_lonlat(lon, lat, dms=True)}"]
        try:
            lines.append(f"Grid convergence:     {crs.convergence_at(x, y):.5f} deg")
            f = C.combined_factor(crs.crs, lon, lat, 0.0)
            lines.append(f"Grid scale factor:    {f['grid_factor']:.8f}   (elevation factor at height 0: {f['elevation_factor']:.8f})")
        except Exception:
            pass
        lines.append(f"Google Maps:          https://www.google.com/maps?q={lat:.7f},{lon:.7f}")
        self.out.setPlainText("\n".join(lines))

    def _copy_ll(self):
        if self._last_ll:
            QGuiApplication.clipboard().setText(f"{self._last_ll[0]:.8f}, {self._last_ll[1]:.8f}")

    # ------------------------------------------------------------------ accept
    def _build_result(self) -> C.ProjectCRS | None:
        cur = self.project.crs
        key = self.picker.current_key()
        if key:
            base = C.ProjectCRS.from_epsg(int(key.split(":")[1])) if key.startswith("EPSG:") else C.ProjectCRS(key)
            crs = base.crs
        elif not cur.is_local:
            crs = cur.crs
        else:
            return None
        ground = C.GroundScale(self.chk_ground.isChecked(), self.sp_bx.value(), self.sp_by.value(), self.sp_cf.value()) \
            if self.chk_ground.isEnabled() else C.GroundScale()
        return C.ProjectCRS(crs, ground, self.cmb_v.currentData(), self.ed_vdatum.text().strip(), self._strategy)

    def _accept(self):
        new = self._build_result()
        if new is None:
            error_box(self, "Coordinate system", "Choose a coordinate system from the list first.")
            self.tabs.setCurrentIndex(0)
            return
        cur = self.project.crs
        same_crs = (not cur.is_local) and new.crs == cur.crs
        mode = "assign" if self.r_assign.isChecked() else "reproject"
        if cur.is_local:
            mode = "assign"
        if same_crs:
            if self.chk_ground.isChecked() != cur.ground.enabled or abs(self.sp_cf.value() - cur.ground.factor) > 1e-12 \
                    or (self.chk_ground.isChecked() and (abs(self.sp_bx.value() - cur.ground.base_x) > 1e-9 or abs(self.sp_by.value() - cur.ground.base_y) > 1e-9)):
                pass          # mode chosen by the user decides: relabel or convert grid<->ground
            else:
                mode = "assign"
        self.result_crs, self.result_mode = new, mode
        self.accept()
