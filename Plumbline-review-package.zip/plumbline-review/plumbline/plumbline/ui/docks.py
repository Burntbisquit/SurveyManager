"""Dock widgets: Layers, Points table, Properties, Surfaces, Messages, Python console."""
from __future__ import annotations

import code
import contextlib
import html
import io
import math
import re
import time

import numpy as np
from PySide6.QtCore import (QAbstractTableModel, QItemSelection, QItemSelectionModel, QModelIndex, QSortFilterProxyModel,
                            Qt, QTimer, Signal)
from PySide6.QtGui import QColor, QTextCursor
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QColorDialog, QComboBox, QFormLayout, QHBoxLayout, QHeaderView,
                               QInputDialog, QLabel, QLineEdit, QListWidget, QListWidgetItem, QPlainTextEdit, QPushButton,
                               QSlider, QTableView, QTableWidget, QTableWidgetItem, QTextBrowser, QVBoxLayout, QWidget)

from ..core import geometry as G
from ..core import units as U
from ..core.model import Polyline, TextEntity
from ..core.settings import settings
from ..core.surface import is_stale
from . import theme
from .widgets import Hint, confirm, dspin, error_box


# ----------------------------------------------------------------------------- layers
class LayersDock(QWidget):
    current_changed = Signal(str)

    def __init__(self, state, parent=None):
        super().__init__(parent)
        self.state = state
        self.current = "0"
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        self.tbl = QTableWidget(0, 5)
        self.tbl.setHorizontalHeaderLabels(["", "", "", "Layer", "Objects"])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setShowGrid(False)
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        h = self.tbl.horizontalHeader()
        h.setSectionResizeMode(0, QHeaderView.Fixed)
        h.setSectionResizeMode(1, QHeaderView.Fixed)
        h.setSectionResizeMode(2, QHeaderView.Fixed)
        h.setSectionResizeMode(3, QHeaderView.Stretch)
        for c in (0, 1, 2):
            self.tbl.setColumnWidth(c, 28)
        self.tbl.setColumnWidth(4, 64)
        lay.addWidget(self.tbl, 1)
        row = QHBoxLayout()
        self.b_new = QPushButton("New")
        self.b_all = QPushButton("Show all")
        self.b_iso = QPushButton("Isolate")
        self.b_purge = QPushButton("Purge empty")
        for b in (self.b_new, self.b_all, self.b_iso, self.b_purge):
            row.addWidget(b)
        lay.addLayout(row)
        lay.addWidget(Hint("Click the eye / lock / swatch to change; double-click a name to make it the current layer for drawing."))
        self.tbl.cellClicked.connect(self._clicked)
        self.tbl.cellDoubleClicked.connect(self._dbl)
        self.b_new.clicked.connect(self._new)
        self.b_all.clicked.connect(self._show_all)
        self.b_iso.clicked.connect(self._isolate)
        self.b_purge.clicked.connect(self._purge)
        state.changed.connect(lambda k: self.refresh())
        state.project_replaced.connect(self.refresh)
        state.selection_changed.connect(lambda: None)
        self.refresh()

    def _counts(self):
        pr = self.state.project
        c: dict[str, int] = {}
        for p in pr.points.values():
            c[p.layer] = c.get(p.layer, 0) + 1
        for e in pr.entities.values():
            c[e.layer] = c.get(e.layer, 0) + 1
        return c

    def refresh(self):
        from .icons import icon
        pr = self.state.project
        counts = self._counts()
        names = sorted(pr.layers, key=lambda n: (n != "0", n))
        self.tbl.blockSignals(True)
        self.tbl.setRowCount(len(names))
        for r, n in enumerate(names):
            lay = pr.layers[n]
            eye = QTableWidgetItem()
            eye.setIcon(icon("eye" if lay.visible else "eye_off"))
            lk = QTableWidgetItem()
            lk.setIcon(icon("lock" if lay.locked else "unlock"))
            sw = QTableWidgetItem()
            sw.setBackground(QColor(*theme.display_color(lay.color)))
            nm = QTableWidgetItem(n)
            f = nm.font()
            f.setBold(n == self.current)
            nm.setFont(f)
            if not lay.visible:
                nm.setForeground(QColor(theme.colors()["dim"]))
            ct = QTableWidgetItem(str(counts.get(n, 0)))
            ct.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            for c, it in enumerate((eye, lk, sw, nm, ct)):
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self.tbl.setItem(r, c, it)
        self.tbl.blockSignals(False)

    def _name(self, row):
        return self.tbl.item(row, 3).text()

    def _clicked(self, row, col):
        n = self._name(row)
        lay = self.state.project.layers[n]
        if col == 0:
            lay.visible = not lay.visible
            self.state.refresh(("layers",))
        elif col == 1:
            lay.locked = not lay.locked
            self.state.refresh(("layers",))
        elif col == 2:
            c = QColorDialog.getColor(QColor(*lay.color), self, f"Colour of {n}")
            if c.isValid():
                with self.state.edit("Layer colour", kinds=("layers",)):
                    self.state.project.layers[n].color = (c.red(), c.green(), c.blue())

    def _dbl(self, row, col):
        if col == 3:
            self.set_current(self._name(row))

    def set_current(self, name: str):
        self.current = name
        self.current_changed.emit(name)
        self.refresh()

    def _new(self):
        name, ok = QInputDialog.getText(self, "New layer", "Layer name:")
        name = name.strip()
        if ok and name:
            with self.state.edit("New layer", kinds=("layers",)):
                self.state.project.ensure_layer(name)
            self.set_current(name)

    def _show_all(self):
        for l in self.state.project.layers.values():
            l.visible = True
        self.state.refresh(("layers",))

    def _isolate(self):
        r = self.tbl.currentRow()
        if r < 0:
            return
        keep = self._name(r)
        for n, l in self.state.project.layers.items():
            l.visible = (n == keep)
        self.state.refresh(("layers",))

    def _purge(self):
        counts = self._counts()
        dead = [n for n in self.state.project.layers if counts.get(n, 0) == 0 and n not in ("0", "POINTS", self.current)]
        if not dead:
            self.state.log("No empty layers to purge.", "info")
            return
        if confirm(self, "Purge layers", f"Remove {len(dead)} empty layer(s)?", "Purge"):
            with self.state.edit("Purge layers", kinds=("layers",)):
                for n in dead:
                    del self.state.project.layers[n]


# ----------------------------------------------------------------------------- points table
class PointsModel(QAbstractTableModel):
    def __init__(self, state):
        super().__init__()
        self.state = state
        self.ids: list[int] = []
        self.ne = True

    def headers(self):
        return ["Pt", "Northing" if self.ne else "Easting", "Easting" if self.ne else "Northing", "Elev", "Description", "Layer"]

    def reload(self):
        self.beginResetModel()
        self.ne = settings().get("coord_order") == "NE"
        self.ids = list(self.state.project.points.keys())
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.ids)

    def columnCount(self, parent=QModelIndex()):
        return 6

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return self.headers()[section]
        return None

    def _cols(self, p):
        a, b = (p.y, p.x) if self.ne else (p.x, p.y)
        return [p.number, a, b, p.z, p.desc, p.layer]

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        p = self.state.project.points.get(self.ids[index.row()])
        if p is None:
            return None
        v = self._cols(p)[index.column()]
        c = index.column()
        if role == Qt.DisplayRole:
            if c in (1, 2):
                return f"{v:,.3f}"
            if c == 3:
                return "" if math.isnan(v) else f"{v:,.3f}"
            return v
        if role == Qt.EditRole:
            if c in (1, 2, 3):
                return "" if (isinstance(v, float) and math.isnan(v)) else f"{v:.6f}".rstrip("0").rstrip(".")
            return v
        if role == Qt.TextAlignmentRole and c in (1, 2, 3):
            return int(Qt.AlignRight | Qt.AlignVCenter)
        if role == Qt.UserRole:                            # sort key
            if c == 0:
                try:
                    return (0, float(v), v)
                except ValueError:
                    return (1, 0.0, v)
            if c in (1, 2, 3):
                return -1e300 if (isinstance(v, float) and math.isnan(v)) else v
            return str(v).lower()
        if role == Qt.UserRole + 1:
            return p.id
        return None

    def flags(self, index):
        return Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable

    def setData(self, index, value, role=Qt.EditRole):
        if role != Qt.EditRole:
            return False
        pid = self.ids[index.row()]
        p = self.state.project.points.get(pid)
        if p is None:
            return False
        c = index.column()
        text = str(value).strip()
        try:
            with self.state.edit("Edit point"):
                p = self.state.project.points[pid]
                if c == 0:
                    if not text:
                        raise ValueError("A point needs a number.")
                    p.number = text
                elif c in (1, 2):
                    v = float(text.replace(",", ""))
                    if (c == 1) == self.ne:
                        p.y = v
                    else:
                        p.x = v
                elif c == 3:
                    p.z = math.nan if text == "" else float(text.replace(",", ""))
                elif c == 4:
                    p.desc = text
                elif c == 5:
                    if not text:
                        raise ValueError("A layer name is needed.")
                    self.state.project.ensure_layer(text)
                    p.layer = text
        except ValueError as ex:
            self.state.log(f"Edit rejected: {ex}", "warn")
            return False
        return True


class _Proxy(QSortFilterProxyModel):
    def lessThan(self, a, b):
        return (a.data(Qt.UserRole) or 0) < (b.data(Qt.UserRole) or 0)


class PointsDock(QWidget):
    def __init__(self, state, parent=None):
        super().__init__(parent)
        self.state = state
        self._sync = False
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        row = QHBoxLayout()
        self.ed = QLineEdit()
        self.ed.setPlaceholderText("Filter by number, description, layer ...")
        self.ed.setClearButtonEnabled(True)
        self.lbl = QLabel("")
        row.addWidget(self.ed, 1)
        row.addWidget(self.lbl)
        lay.addLayout(row)
        self.model = PointsModel(state)
        self.proxy = _Proxy()
        self.proxy.setSourceModel(self.model)
        self.proxy.setFilterCaseSensitivity(Qt.CaseInsensitive)
        self.proxy.setFilterKeyColumn(-1)
        self.view = QTableView()
        self.view.setModel(self.proxy)
        self.view.setSortingEnabled(True)
        self.view.sortByColumn(0, Qt.AscendingOrder)
        self.view.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.view.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.view.setAlternatingRowColors(True)
        self.view.verticalHeader().setVisible(False)
        self.view.verticalHeader().setDefaultSectionSize(22)
        self.view.horizontalHeader().setStretchLastSection(True)
        self.view.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed)
        lay.addWidget(self.view, 1)
        self.ed.textChanged.connect(self._filter)
        self.view.selectionModel().selectionChanged.connect(self._view_selection)
        self.view.clicked.connect(lambda i: None)
        self.view.activated.connect(self._zoom)
        state.changed.connect(self._changed)
        state.project_replaced.connect(self.reload)
        state.selection_changed.connect(self._state_selection)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.reload)
        self.reload()

    def _changed(self, kinds):
        self._timer.start(30)

    def reload(self):
        self._sync = True
        self.model.reload()
        self._sync = False
        self.view.resizeColumnsToContents()
        self.view.horizontalHeader().setStretchLastSection(True)
        self.lbl.setText(f"{len(self.model.ids):,} points")
        self._state_selection()

    def _filter(self, text):
        rx = re.escape(text.strip())
        self.proxy.setFilterRegularExpression(rx)
        self.lbl.setText(f"{self.proxy.rowCount():,} of {len(self.model.ids):,}" if text.strip() else f"{len(self.model.ids):,} points")

    def _view_selection(self, *a):
        if self._sync:
            return
        ids = [self.proxy.data(i, Qt.UserRole + 1) for i in self.view.selectionModel().selectedRows()]
        self._sync = True
        self.state.select(points=ids)
        self._sync = False

    def _state_selection(self):
        if self._sync:
            return
        self._sync = True
        sel = self.state.sel_points
        sm = self.view.selectionModel()
        sm.clearSelection()
        if sel and len(sel) <= 20000:
            rows = []
            pos = {pid: r for r, pid in enumerate(self.model.ids)}
            for pid in sel:
                r = pos.get(pid)
                if r is not None:
                    pi = self.proxy.mapFromSource(self.model.index(r, 0)).row()
                    if pi >= 0:
                        rows.append(pi)
            rows.sort()
            isel = QItemSelection()
            start = prev = None
            for r in rows:
                if start is None:
                    start = prev = r
                elif r == prev + 1:
                    prev = r
                else:
                    isel.select(self.proxy.index(start, 0), self.proxy.index(prev, 5))
                    start = prev = r
            if start is not None:
                isel.select(self.proxy.index(start, 0), self.proxy.index(prev, 5))
            sm.select(isel, QItemSelectionModel.Select)
            if rows:
                self.view.scrollTo(self.proxy.index(rows[0], 0))
        self._sync = False

    def _zoom(self, idx):
        pid = self.proxy.data(idx, Qt.UserRole + 1)
        p = self.state.project.points.get(pid)
        if p:
            self.state.center_on(p.x, p.y)


# ----------------------------------------------------------------------------- properties
class PropertiesDock(QWidget):
    def __init__(self, state, parent=None):
        super().__init__(parent)
        self.state = state
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(8, 8, 8, 8)
        self.body = QWidget()
        self.lay.addWidget(self.body)
        self.lay.addStretch(1)
        state.selection_changed.connect(self.refresh)
        state.changed.connect(lambda k: self.refresh())
        state.project_replaced.connect(self.refresh)
        self.refresh()

    def _rebuild(self):
        self.lay.removeWidget(self.body)
        self.body.deleteLater()
        self.body = QWidget()
        self.lay.insertWidget(0, self.body)
        return QFormLayout(self.body)

    def refresh(self):
        st = self.state
        pr = st.project
        f = self._rebuild()
        f.setLabelAlignment(Qt.AlignRight)
        pts = [pr.points[i] for i in st.sel_points if i in pr.points]
        ents = [pr.entities[i] for i in st.sel_entities if i in pr.entities]
        if not pts and not ents:
            s = pr.summary()
            f.addRow(QLabel(f"<b>{html.escape(pr.name)}</b>"))
            f.addRow("Points:", QLabel(f"{s['points']:,}"))
            f.addRow("Polylines:", QLabel(f"{s['polylines']:,}"))
            f.addRow("Texts:", QLabel(f"{s['texts']:,}"))
            f.addRow("Surfaces:", QLabel(f"{s['surfaces']}"))
            f.addRow("Imagery checks:", QLabel(f"{s['checks']}"))
            ext = pr.extents()
            if ext:
                f.addRow("Extents N:", QLabel(f"{ext[1]:,.2f} to {ext[3]:,.2f}"))
                f.addRow("Extents E:", QLabel(f"{ext[0]:,.2f} to {ext[2]:,.2f}"))
            lbl = QLabel(pr.crs.label)
            lbl.setWordWrap(True)
            f.addRow("Coordinates:", lbl)
            return
        if len(pts) == 1 and not ents:
            self._point_form(f, pts[0])
        elif len(ents) == 1 and not pts:
            self._entity_form(f, ents[0])
        else:
            f.addRow(QLabel(f"<b>{len(pts)} point(s), {len(ents)} object(s) selected</b>"))
            cmb = QComboBox()
            cmb.setEditable(True)
            cmb.addItems(sorted(pr.layers))
            cmb.setCurrentText("")
            b = QPushButton("Move to layer")
            b.clicked.connect(lambda: self._move_layer(cmb.currentText().strip()))
            f.addRow("Layer:", cmb)
            f.addRow("", b)
            zs = [p.z for p in pts if not math.isnan(p.z)]
            if zs:
                f.addRow("Elevation:", QLabel(f"{min(zs):,.3f} to {max(zs):,.3f}"))

    def _move_layer(self, name):
        if not name:
            return
        st = self.state
        with st.edit("Move to layer"):
            st.project.ensure_layer(name)
            for i in st.sel_points:
                if i in st.project.points:
                    st.project.points[i].layer = name
            for i in st.sel_entities:
                if i in st.project.entities:
                    st.project.entities[i].layer = name

    def _point_form(self, f, p):
        pr = self.state.project
        ne = settings().get("coord_order") == "NE"
        e_num, e_n, e_e = QLineEdit(p.number), QLineEdit(f"{p.y:.4f}"), QLineEdit(f"{p.x:.4f}")
        e_z = QLineEdit("" if math.isnan(p.z) else f"{p.z:.4f}")
        e_d = QLineEdit(p.desc)
        c_l = QComboBox()
        c_l.setEditable(True)
        c_l.addItems(sorted(pr.layers))
        c_l.setCurrentText(p.layer)
        f.addRow(QLabel(f"<b>Point {html.escape(p.number)}</b>"))
        f.addRow("Number:", e_num)
        if ne:
            f.addRow("Northing:", e_n)
            f.addRow("Easting:", e_e)
        else:
            f.addRow("Easting:", e_e)
            f.addRow("Northing:", e_n)
        f.addRow("Elevation:", e_z)
        f.addRow("Description:", e_d)
        f.addRow("Layer:", c_l)
        b = QPushButton("Apply changes")
        f.addRow("", b)

        def apply():
            try:
                x, y = float(e_e.text().replace(",", "")), float(e_n.text().replace(",", ""))
                z = math.nan if not e_z.text().strip() else float(e_z.text().replace(",", ""))
            except ValueError:
                error_box(self, "Point", "Coordinates and elevation must be numbers.")
                return
            with self.state.edit("Edit point"):
                q = self.state.project.points[p.id]
                q.number, q.x, q.y, q.z, q.desc = e_num.text().strip() or q.number, x, y, z, e_d.text().strip()
                ln = c_l.currentText().strip()
                if ln:
                    self.state.project.ensure_layer(ln)
                    q.layer = ln

        b.clicked.connect(apply)

    def _entity_form(self, f, e):
        pr = self.state.project
        c_l = QComboBox()
        c_l.setEditable(True)
        c_l.addItems(sorted(pr.layers))
        c_l.setCurrentText(e.layer)
        if isinstance(e, Polyline):
            u = pr.h_unit
            f.addRow(QLabel(f"<b>Polyline {e.id}</b>"))
            f.addRow("Kind:", QLabel(e.kind + (f"  (generated: {e.derived})" if e.derived else "")))
            f.addRow("Vertices:", QLabel(str(len(e.verts))))
            f.addRow("Length:", QLabel(f"{G.polyline_length(e.verts, e.bulges, e.closed):,.3f} {u}"))
            if e.closed:
                a = G.polygon_area(e.verts, e.bulges)
                f.addRow("Area:", QLabel(f"{a:,.2f} sq {u}  ({U.area_to_acres(a, u):,.4f} ac)"))
            zs = e.verts[:, 2][np.isfinite(e.verts[:, 2])]
            if len(zs):
                f.addRow("Elevation:", QLabel(f"{zs.min():,.3f} to {zs.max():,.3f}"))
            chk = QCheckBox("Closed")
            chk.setChecked(e.closed)
            f.addRow("", chk)
            f.addRow("Layer:", c_l)
            b = QPushButton("Apply changes")
            f.addRow("", b)

            def apply():
                with self.state.edit("Edit polyline"):
                    q = self.state.project.entities[e.id]
                    q.closed = chk.isChecked() and len(q.verts) >= 3
                    ln = c_l.currentText().strip()
                    if ln:
                        self.state.project.ensure_layer(ln)
                        q.layer = ln
            b.clicked.connect(apply)
        elif isinstance(e, TextEntity):
            et = QLineEdit(e.text)
            eh = dspin(e.height, 0.001, 1e6, 3)
            er = dspin(e.rotation, -360, 360, 2)
            f.addRow(QLabel(f"<b>Text {e.id}</b>"))
            f.addRow("Text:", et)
            f.addRow("Height:", eh)
            f.addRow("Rotation:", er)
            f.addRow("Layer:", c_l)
            b = QPushButton("Apply changes")
            f.addRow("", b)

            def apply():
                with self.state.edit("Edit text"):
                    q = self.state.project.entities[e.id]
                    q.text, q.height, q.rotation = et.text(), eh.value(), er.value()
                    ln = c_l.currentText().strip()
                    if ln:
                        self.state.project.ensure_layer(ln)
                        q.layer = ln
            b.clicked.connect(apply)


# ----------------------------------------------------------------------------- surfaces
class SurfacesDock(QWidget):
    new_requested = Signal()
    edit_requested = Signal(int)
    contours_requested = Signal(int)
    volumes_requested = Signal()
    profile_requested = Signal(int)
    report_requested = Signal(int)
    delete_requested = Signal(int)

    def __init__(self, state, parent=None):
        super().__init__(parent)
        self.state = state
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        self.lst = QListWidget()
        lay.addWidget(self.lst, 1)
        self.lbl = QLabel("")
        self.lbl.setWordWrap(True)
        lay.addWidget(self.lbl)
        r1 = QHBoxLayout()
        self.b_new = QPushButton("New...")
        self.b_edit = QPushButton("Edit / Rebuild")
        self.b_del = QPushButton("Delete")
        for b in (self.b_new, self.b_edit, self.b_del):
            r1.addWidget(b)
        lay.addLayout(r1)
        r2 = QHBoxLayout()
        self.b_ctr = QPushButton("Contours...")
        self.b_vol = QPushButton("Volumes...")
        self.b_prof = QPushButton("Profile...")
        self.b_rep = QPushButton("Report...")
        for b in (self.b_ctr, self.b_vol, self.b_prof, self.b_rep):
            r2.addWidget(b)
        lay.addLayout(r2)
        form = QFormLayout()
        self.cmb_mode = QComboBox()
        for lbl, v in [("Elevation tint + shading", "elevation"), ("Hillshade only", "hillshade"), ("Slope classes", "slope"), ("Off", "off")]:
            self.cmb_mode.addItem(lbl, v)
        self.chk_edges = QCheckBox("Show TIN edges")
        self.sl_op = QSlider(Qt.Horizontal)
        self.sl_op.setRange(10, 100)
        form.addRow("Display:", self.cmb_mode)
        form.addRow("", self.chk_edges)
        form.addRow("Opacity:", self.sl_op)
        lay.addLayout(form)
        self.b_new.clicked.connect(self.new_requested.emit)
        self.b_edit.clicked.connect(lambda: self._emit(self.edit_requested))
        self.b_del.clicked.connect(lambda: self._emit(self.delete_requested))
        self.b_ctr.clicked.connect(lambda: self._emit(self.contours_requested))
        self.b_vol.clicked.connect(self.volumes_requested.emit)
        self.b_prof.clicked.connect(lambda: self._emit(self.profile_requested))
        self.b_rep.clicked.connect(lambda: self._emit(self.report_requested))
        self.lst.currentRowChanged.connect(self._selected)
        self.cmb_mode.currentIndexChanged.connect(self._style)
        self.chk_edges.toggled.connect(self._style)
        self.sl_op.valueChanged.connect(self._style)
        self._busy = False
        self._stale: dict = {}
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._compute_stale)
        state.changed.connect(self._changed)
        state.project_replaced.connect(self.refresh)
        self.refresh()

    def _emit(self, sig):
        s = self.current()
        if s is not None:
            sig.emit(s.id)

    def current(self):
        r = self.lst.currentRow()
        if r < 0:
            return None
        return self.state.project.surfaces.get(self.lst.item(r).data(Qt.UserRole))

    def _changed(self, kinds):
        if self._busy:
            return
        self.refresh(keep=True)
        self._timer.start(500)

    def refresh(self, keep=False):
        pr = self.state.project
        cur = self.current().id if (keep and self.current() is not None) else self.state.active_surface_id
        self._busy = True
        self.lst.clear()
        for s in pr.surfaces.values():
            mark = "  ⚠ out of date" if self._stale.get(s.id) else ""
            it = QListWidgetItem(f"{s.name}   ({s.tin().n_tris:,} triangles){mark}")
            it.setData(Qt.UserRole, s.id)
            self.lst.addItem(it)
            if s.id == cur:
                self.lst.setCurrentItem(it)
        if self.lst.count() and self.lst.currentRow() < 0:
            self.lst.setCurrentRow(0)
        self._busy = False
        self._selected(self.lst.currentRow())
        en = self.lst.count() > 0
        for b in (self.b_edit, self.b_del, self.b_ctr, self.b_prof, self.b_rep, self.b_vol, self.cmb_mode, self.chk_edges, self.sl_op):
            b.setEnabled(en)

    def _compute_stale(self):
        pr = self.state.project
        changed = False
        for s in pr.surfaces.values():
            try:
                v = is_stale(pr, s)
            except Exception:
                v = False
            if self._stale.get(s.id) != v:
                self._stale[s.id] = v
                changed = True
        if changed:
            self.refresh(keep=True)

    def _selected(self, row):
        s = self.current()
        if s is None:
            self.lbl.setText("No surfaces yet. Use New... to build one from your ground shots.")
            return
        self.state.active_surface_id = s.id
        st = s.style or {}
        self._busy = True
        mode = st.get("mode") or "elevation"
        self.cmb_mode.setCurrentIndex(max(0, self.cmb_mode.findData(mode)))
        self.chk_edges.setChecked(bool(st.get("edges", False)))
        self.sl_op.setValue(int(100 * float(st.get("opacity", 0.85))))
        self._busy = False
        a = s.tin().summary()
        u = self.state.project.h_unit
        txt = (f"{a['points']:,} points, {a['triangles']:,} triangles - {a['area2d']:,.0f} sq {u} ({U.area_to_acres(a['area2d'], u):,.2f} ac)\n"
               f"Elevation {a['zmin']:,.2f} to {a['zmax']:,.2f} - mean slope {a['mean_slope_pct']:.1f}%")
        if self._stale.get(s.id):
            txt += "\nThe points or breaklines changed since this surface was built - use Edit / Rebuild."
        self.lbl.setText(txt)

    def _style(self):
        if self._busy:
            return
        s = self.current()
        if s is None:
            return
        s.style = {**(s.style or {}), "mode": self.cmb_mode.currentData(), "edges": self.chk_edges.isChecked(),
                   "opacity": self.sl_op.value() / 100.0}
        self._busy = True
        self.state.refresh(("surfaces",))
        self._busy = False


# ----------------------------------------------------------------------------- messages
class MessagesDock(QWidget):
    def __init__(self, state, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        self.view = QTextBrowser()
        self.view.setOpenLinks(False)
        lay.addWidget(self.view)
        state.message.connect(self.add)
        self._n = 0

    def add(self, level: str, text: str):
        col = {"info": theme.colors()["dim"], "ok": theme.colors()["good"], "warn": theme.colors()["warn"],
               "error": theme.colors()["bad"]}.get(level, theme.colors()["text"])
        t = time.strftime("%H:%M:%S")
        self.view.append(f"<span style='color:{theme.colors()['dim']}'>{t}</span> <span style='color:{col}'>{html.escape(text)}</span>")
        self._n += 1
        if self._n > 600:
            self.view.clear()
            self._n = 0


# ----------------------------------------------------------------------------- python console
class ConsoleDock(QWidget):
    def __init__(self, state, canvas, parent=None):
        super().__init__(parent)
        self.state = state
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        self.out = QPlainTextEdit()
        self.out.setReadOnly(True)
        from .theme import mono_font
        f = mono_font(9.5)
        self.out.setFont(f)
        self.out.setMaximumBlockCount(3000)
        self.inp = QLineEdit()
        self.inp.setFont(f)
        self.inp.setPlaceholderText("Python - e.g.  len(project.points)   |   api.edit('x')   |   help(api)")
        lay.addWidget(self.out, 1)
        lay.addWidget(self.inp)
        self.history: list[str] = []
        self.hpos = 0
        self.buffer: list[str] = []
        from ..plugins import PluginAPI
        import math as _m
        import numpy as _np
        from ..core import cogo, geometry, units
        self.api = PluginAPI(state.project, state, log=lambda s: self.write(s + "\n"))
        self.ns = {"np": _np, "math": _m, "G": geometry, "cogo": cogo, "U": units, "state": state, "canvas": canvas,
                   "api": self.api, "project": state.project, "refresh": state.refresh}
        self.interp = code.InteractiveInterpreter(self.ns)
        self.write("Plumbline console - 'project' is the open project, 'api' the plugin API, 'refresh()' repaints.\n"
                   "Use  with api.edit('label'):  for undoable changes.\n")
        self.inp.returnPressed.connect(self.run_line)
        self.inp.installEventFilter(self)
        state.project_replaced.connect(self._project_replaced)

    def _project_replaced(self):
        self.api.project = self.state.project
        self.ns["project"] = self.state.project

    def write(self, s: str):
        self.out.moveCursor(QTextCursor.End)
        self.out.insertPlainText(s)
        self.out.moveCursor(QTextCursor.End)

    def eventFilter(self, obj, ev):
        from PySide6.QtCore import QEvent
        if obj is self.inp and ev.type() == QEvent.KeyPress:
            if ev.key() == Qt.Key_Up and self.history:
                self.hpos = max(0, self.hpos - 1)
                self.inp.setText(self.history[self.hpos])
                return True
            if ev.key() == Qt.Key_Down and self.history:
                self.hpos = min(len(self.history), self.hpos + 1)
                self.inp.setText(self.history[self.hpos] if self.hpos < len(self.history) else "")
                return True
        return super().eventFilter(obj, ev)

    def run_line(self):
        line = self.inp.text()
        self.inp.clear()
        if line.strip():
            self.history.append(line)
        self.hpos = len(self.history)
        self.write((">>> " if not self.buffer else "... ") + line + "\n")
        self.buffer.append(line)
        src = "\n".join(self.buffer)
        buf = io.StringIO()
        try:
            with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
                more = self.interp.runsource(src, "<console>")
        except SystemExit:
            more = False
        if buf.getvalue():
            self.write(buf.getvalue())
        if not more:
            self.buffer = []
