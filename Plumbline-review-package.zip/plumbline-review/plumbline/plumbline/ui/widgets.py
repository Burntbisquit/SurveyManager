"""Small reusable widgets and helpers."""
from __future__ import annotations

import math
import threading
import traceback

from PySide6.QtCore import QEventLoop, QObject, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QIcon, QPixmap
from PySide6.QtWidgets import (QApplication, QCheckBox, QColorDialog, QComboBox, QDialog, QDialogButtonBox,
                               QDoubleSpinBox, QFormLayout, QFrame, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                               QProgressDialog, QPushButton, QSizePolicy, QSpinBox, QToolButton, QVBoxLayout, QWidget)

from . import icons


# ----------------------------------------------------------------------------- background work
class _Result(QObject):
    done = Signal(object, object)       # (result, error_traceback)


def run_blocking(parent, text: str, fn, *args, cancellable: bool = False, **kw):
    """Run fn(*args) on a worker thread while showing a busy dialog; the UI keeps repainting.

    Returns fn's result, or raises RuntimeError(traceback text) if it failed.
    """
    holder = {}
    res = _Result()
    loop = QEventLoop()

    def target():
        try:
            holder["r"] = fn(*args, **kw)
            err = None
        except BaseException:
            err = traceback.format_exc()
        res.done.emit(holder.get("r"), err)

    res.done.connect(lambda r, e: (holder.update(err=e), loop.quit()), Qt.QueuedConnection)
    dlg = QProgressDialog(text, None, 0, 0, parent)
    dlg.setWindowTitle("Working...")
    dlg.setWindowModality(Qt.WindowModal)
    dlg.setMinimumDuration(400)
    dlg.setCancelButton(None)
    t = threading.Thread(target=target, daemon=True)
    t.start()
    QApplication.setOverrideCursor(Qt.BusyCursor)
    try:
        loop.exec()
    finally:
        QApplication.restoreOverrideCursor()
        dlg.close()
    t.join()
    if holder.get("err"):
        raise RuntimeError(holder["err"])
    return holder.get("r")


def error_box(parent, title: str, text: str, detail: str | None = None):
    m = QMessageBox(parent)
    m.setIcon(QMessageBox.Warning)
    m.setWindowTitle(title)
    m.setText(text)
    if detail:
        m.setDetailedText(detail)
    m.exec()


def info_box(parent, title: str, text: str):
    m = QMessageBox(parent)
    m.setIcon(QMessageBox.Information)
    m.setWindowTitle(title)
    m.setText(text)
    m.exec()


def confirm(parent, title: str, text: str, yes: str = "Yes") -> bool:
    m = QMessageBox(parent)
    m.setIcon(QMessageBox.Question)
    m.setWindowTitle(title)
    m.setText(text)
    b = m.addButton(yes, QMessageBox.AcceptRole)
    m.addButton("Cancel", QMessageBox.RejectRole)
    m.exec()
    return m.clickedButton() is b


# ----------------------------------------------------------------------------- widgets
class ColorButton(QPushButton):
    colorChanged = Signal(tuple)

    def __init__(self, rgb=(255, 255, 255), parent=None):
        super().__init__(parent)
        self._rgb = tuple(rgb)
        self.setFixedSize(34, 22)
        self.clicked.connect(self._pick)
        self._paint()

    def rgb(self):
        return self._rgb

    def setRgb(self, rgb):
        self._rgb = tuple(int(c) for c in rgb)
        self._paint()

    def _paint(self):
        r, g, b = self._rgb
        self.setStyleSheet(f"QPushButton {{ background: rgb({r},{g},{b}); border: 1px solid #667; border-radius: 4px; padding:0; }}")

    def _pick(self):
        c = QColorDialog.getColor(QColor(*self._rgb), self, "Layer colour")
        if c.isValid():
            self.setRgb((c.red(), c.green(), c.blue()))
            self.colorChanged.emit(self._rgb)


class Hint(QLabel):
    def __init__(self, text: str = "", parent=None):
        super().__init__(text, parent)
        self.setWordWrap(True)
        self.setProperty("hint", True)


class Banner(QLabel):
    """Coloured message strip: kind = info | warn | bad."""

    def __init__(self, text: str = "", kind: str = "info", parent=None):
        super().__init__(text, parent)
        self.setWordWrap(True)
        self.setProperty("banner", kind)
        self.setTextInteractionFlags(Qt.TextSelectableByMouse)

    def set(self, text: str, kind: str = "info"):
        self.setText(text)
        self.setProperty("banner", kind)
        self.style().unpolish(self)
        self.style().polish(self)
        self.setVisible(bool(text))


def hline() -> QFrame:
    f = QFrame()
    f.setFrameShape(QFrame.HLine)
    f.setFrameShadow(QFrame.Sunken)
    return f


def tool_button(icon_name: str, tip: str, checkable: bool = False, parent=None) -> QToolButton:
    b = QToolButton(parent)
    b.setIcon(icons.icon(icon_name))
    b.setToolTip(tip)
    b.setCheckable(checkable)
    b.setAutoRaise(True)
    b.setIconSize(QSize(20, 20))
    return b


def dspin(value=0.0, lo=-1e12, hi=1e12, dec=3, step=1.0, suffix="") -> QDoubleSpinBox:
    s = QDoubleSpinBox()
    s.setDecimals(dec)
    s.setRange(lo, hi)
    s.setSingleStep(step)
    s.setValue(value)
    s.setGroupSeparatorShown(False)
    s.setKeyboardTracking(False)
    if suffix:
        s.setSuffix(suffix)
    s.setAlignment(Qt.AlignRight)
    return s


def ispin(value=0, lo=-10 ** 9, hi=10 ** 9) -> QSpinBox:
    s = QSpinBox()
    s.setRange(lo, hi)
    s.setValue(value)
    s.setKeyboardTracking(False)
    return s


class FormDialog(QDialog):
    """Base dialog: title, optional intro, a QFormLayout body and OK/Cancel."""

    def __init__(self, parent=None, title: str = "", intro: str = "", ok_text: str = "OK", min_width: int = 460):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(min_width)
        self.root = QVBoxLayout(self)
        self.root.setSpacing(10)
        if intro:
            self.root.addWidget(Hint(intro))
        self.form = QFormLayout()
        self.form.setLabelAlignment(Qt.AlignRight)
        self.form.setSpacing(8)
        self.root.addLayout(self.form)
        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.button(QDialogButtonBox.Ok).setText(ok_text)
        self.buttons.accepted.connect(self._try_accept)
        self.buttons.rejected.connect(self.reject)
        self.root.addWidget(self.buttons)

    def _try_accept(self):
        err = self.validate()
        if err:
            error_box(self, self.windowTitle(), err)
            return
        self.accept()

    def validate(self) -> str | None:
        return None


def fmt_coord(v: float, decimals: int = 3) -> str:
    return "" if (v is None or (isinstance(v, float) and not math.isfinite(v))) else f"{v:,.{decimals}f}"
