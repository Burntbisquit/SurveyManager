"""Imagery UI: add-imagery dialog and the Imagery dock (layers, source accuracy, checks, statistics)."""
from __future__ import annotations

import csv
import math
import re
from datetime import datetime
from pathlib import Path

import numpy as np
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog,
                               QFormLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
                               QPushButton, QRadioButton, QScrollArea, QSlider, QSpinBox, QTableWidget,
                               QTableWidgetItem, QTextBrowser, QVBoxLayout, QWidget)

from ..core import crs as C
from ..core import imagery as IM
from ..core import units as U
from ..core.model import ImageryCheck, ImageryLayer
from ..core.settings import settings
from ..core.tiles import PRESETS, TileSource, fetch_esri_metadata
from .widgets import Banner, Hint, dspin, error_box, info_box, run_blocking


# ----------------------------------------------------------------------------- add imagery
class AddImageryDialog(QDialog):
    def __init__(self, state, parent=None):
        super().__init__(parent)
        self.state = state
        self.setWindowTitle("Add Imagery")
        self.setMinimumWidth(620)
        self.layer_spec: dict | None = None
        root = QVBoxLayout(self)
        if state.project.crs.is_local:
            root.addWidget(Banner("This project uses local coordinates, so online imagery cannot be placed. Assign a coordinate system first "
                                  "(Coordinates menu). A georeferenced image file in your own coordinates still works.", "warn"))
        # --- tiles
        self.r_tiles = QRadioButton("Online satellite / map tiles")
        self.r_tiles.setChecked(not state.project.crs.is_local)
        root.addWidget(self.r_tiles)
        self.cmb = QComboBox()
        custom = [TileSource.from_dict(d) for d in (settings().get("custom_tile_sources") or [])]
        self.sources = list(PRESETS) + custom
        for s in self.sources:
            self.cmb.addItem(s.name)
        root.addWidget(self.cmb)
        self.note = Hint("")
        root.addWidget(self.note)
        # --- custom xyz
        self.r_xyz = QRadioButton("Custom tile URL  (XYZ / slippy-map - e.g. a county orthophoto service)")
        root.addWidget(self.r_xyz)
        f = QFormLayout()
        self.ed_name = QLineEdit()
        self.ed_url = QLineEdit()
        self.ed_url.setPlaceholderText("https://server/path/{z}/{x}/{y}.jpg")
        self.sp_zoom = QSpinBox()
        self.sp_zoom.setRange(1, 24)
        self.sp_zoom.setValue(19)
        self.ed_attr = QLineEdit()
        f.addRow("Name:", self.ed_name)
        f.addRow("URL template:", self.ed_url)
        f.addRow("Max zoom:", self.sp_zoom)
        f.addRow("Attribution:", self.ed_attr)
        self.xyz_box = QWidget()
        self.xyz_box.setLayout(f)
        root.addWidget(self.xyz_box)
        # --- file
        self.r_file = QRadioButton("Georeferenced image file  (GeoTIFF, or PNG / JPG with a world file)")
        root.addWidget(self.r_file)
        col = QVBoxLayout()
        col.setContentsMargins(0, 0, 0, 0)
        row = QHBoxLayout()
        self.ed_file = QLineEdit()
        self.btn_file = QPushButton("Browse...")
        row.addWidget(self.ed_file, 1)
        row.addWidget(self.btn_file)
        col.addLayout(row)
        col.addWidget(Hint("Use this for survey-grade orthophotos from your county or state (and for plans you have georeferenced). "
                           "A world-file image is assumed to be in the project's coordinate system."))
        self.file_box = QWidget()
        self.file_box.setLayout(col)
        root.addWidget(self.file_box)
        self.bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.bb.button(QDialogButtonBox.Ok).setText("Add")
        self.bb.accepted.connect(self._ok)
        self.bb.rejected.connect(self.reject)
        root.addWidget(self.bb)
        self.cmb.currentIndexChanged.connect(self._src)
        self.btn_file.clicked.connect(self._browse)
        for r in (self.r_tiles, self.r_xyz, self.r_file):
            r.toggled.connect(self._mode)
        if state.project.crs.is_local:
            self.r_file.setChecked(True)
            self.r_tiles.setEnabled(False)
            self.r_xyz.setEnabled(False)
        self._src()
        self._mode()

    def _mode(self):
        self.cmb.setEnabled(self.r_tiles.isChecked())
        self.xyz_box.setEnabled(self.r_xyz.isChecked())
        self.file_box.setEnabled(self.r_file.isChecked())

    def _src(self):
        s = self.sources[self.cmb.currentIndex()]
        txt = f"Max zoom {s.max_zoom}.  {s.attribution}"
        if "Esri" in s.name:
            txt += ("\n\nEsri's service is free to view but governed by Esri's terms of use - keep the attribution, and check your licence before "
                    "putting screenshots in deliverables. Its published horizontal accuracy varies by place (often several metres): look it up with "
                    "'Source accuracy' in the Imagery panel.")
        elif "USGS" in s.name:
            txt += "\n\nUSGS orthoimagery is public domain; zoom is limited (about 0.3 m pixels at best, depends on the area)."
        elif "OpenStreetMap" in s.name:
            txt += "\n\nStreet map for context only - not imagery. Please respect the OSM tile usage policy (no bulk downloading)."
        self.note.setText(txt)

    def _browse(self):
        p, _ = QFileDialog.getOpenFileName(self, "Georeferenced image", "", "Images (*.tif *.tiff *.png *.jpg *.jpeg);;All files (*)")
        if p:
            self.ed_file.setText(p)

    def _ok(self):
        if self.r_tiles.isChecked():
            s = self.sources[self.cmb.currentIndex()]
            self.layer_spec = {"kind": "tiles", "name": s.name, "source": s.to_dict()}
        elif self.r_xyz.isChecked():
            url = self.ed_url.text().strip()
            if not all(k in url for k in ("{z}", "{x}", "{y}")):
                error_box(self, "Custom tiles", "The URL template must contain {z}, {x} and {y}.")
                return
            name = self.ed_name.text().strip() or "Custom tiles"
            src = TileSource(name, url, self.sp_zoom.value(), 0, self.ed_attr.text().strip())
            custom = list(settings().get("custom_tile_sources") or [])
            custom = [d for d in custom if d["url"] != url] + [src.to_dict()]
            settings().set("custom_tile_sources", custom)
            self.layer_spec = {"kind": "tiles", "name": name, "source": src.to_dict()}
        else:
            path = self.ed_file.text().strip()
            if not path or not Path(path).exists():
                error_box(self, "Image file", "Choose an image file.")
                return
            try:
                r = run_blocking(self, "Reading image ...", IM.read_georeferenced_image, path)
            except RuntimeError as ex:
                msg = str(ex).strip().splitlines()[-1]
                error_box(self, "Image file", msg, str(ex))
                return
            crs = r["crs"]
            if crs is None:
                crs = None           # world file: assumed to be in the project coordinate system
            self.layer_spec = {"kind": "file", "name": Path(path).stem,
                               "source": {"path": path, "corners": [list(c) for c in r["corners"]], "crs": crs,
                                          "attribution": ""}}
        self.accept()


# ----------------------------------------------------------------------------- dock
def _acc_text(meta: dict, unit: str) -> str:
    if not meta:
        return ""
    a = meta.get("accuracy_m")
    bits = []
    if meta.get("source") or meta.get("product"):
        bits.append(f"{meta.get('source', '')} {meta.get('product', '')} {meta.get('sensor', '')}".strip())
    if meta.get("date"):
        bits.append(f"captured {meta['date']}")
    if meta.get("resolution_m"):
        bits.append(f"{meta['resolution_m']:g} m pixels")
    if a:
        bits.append(f"stated accuracy {a:g} m ({a / U.M_PER_UNIT.get(unit, 0.3048):,.1f} {unit})")
    return ", ".join(bits)


class ImageryDock(QWidget):
    start_requested = Signal(list, str, float)       # point ids, layer name, metres per pixel
    stop_requested = Signal()
    report_requested = Signal(str, float)
    add_requested = Signal()
    ge_import_requested = Signal()
    ge_export_requested = Signal()

    def __init__(self, state, canvas, parent=None):
        super().__init__(parent)
        self.state = state
        self.canvas = canvas
        self._busy = False
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        outer.addWidget(scroll)
        body = QWidget()
        scroll.setWidget(body)
        lay = QVBoxLayout(body)
        lay.setSpacing(8)

        # ---- layers
        g1 = QGroupBox("Imagery layers")
        l1 = QVBoxLayout(g1)
        self.lst = QListWidget()
        self.lst.setMaximumHeight(90)
        l1.addWidget(self.lst)
        row = QHBoxLayout()
        self.btn_add = QPushButton("Add...")
        self.btn_rm = QPushButton("Remove")
        row.addWidget(self.btn_add)
        row.addWidget(self.btn_rm)
        l1.addLayout(row)
        form = QFormLayout()
        self.sl_op = QSlider(Qt.Horizontal)
        self.sl_op.setRange(5, 100)
        self.sl_op.setValue(100)
        self.sp_de = dspin(0, -1e6, 1e6, 3, 0.5)
        self.sp_dn = dspin(0, -1e6, 1e6, 3, 0.5)
        form.addRow("Opacity:", self.sl_op)
        form.addRow("Nudge east:", self.sp_de)
        form.addRow("Nudge north:", self.sp_dn)
        l1.addLayout(form)
        self.lbl_layer = Hint("")
        l1.addWidget(self.lbl_layer)
        row = QHBoxLayout()
        self.chk_off = QCheckBox("Offline (cache only)")
        self.chk_off.setChecked(bool(settings().get("offline_imagery")))
        self.btn_cache = QPushButton("Clear tile cache")
        row.addWidget(self.chk_off)
        row.addWidget(self.btn_cache)
        l1.addLayout(row)
        lay.addWidget(g1)

        # ---- source accuracy
        g2 = QGroupBox("Source accuracy")
        l2 = QVBoxLayout(g2)
        self.btn_meta = QPushButton("Look up imagery source at the view centre")
        self.lbl_meta = Banner("", "info")
        self.lbl_meta.setVisible(False)
        l2.addWidget(self.btn_meta)
        l2.addWidget(self.lbl_meta)
        lay.addWidget(g2)

        # ---- checks
        g3 = QGroupBox("Checks against survey points")
        l3 = QVBoxLayout(g3)
        f3 = QFormLayout()
        self.cmb_which = QComboBox()
        for lbl, v in [("Selected points", "sel"), ("Points in the current view", "view"), ("All points", "all")]:
            self.cmb_which.addItem(lbl, v)
        self.ed_filter = QLineEdit()
        self.ed_filter.setPlaceholderText("only descriptions matching e.g.  BLDG|MH|SW  (hard, visible features)")
        self.sp_mpp = dspin(0.15, 0.01, 10, 2, 0.05)
        self.sp_tol = dspin(2.0, 0.0, 1e6, 2, 0.5)
        self.lbl_tol = QLabel("")
        f3.addRow("Check:", self.cmb_which)
        f3.addRow("Filter:", self.ed_filter)
        f3.addRow("Picking scale (m / pixel):", self.sp_mpp)
        f3.addRow("Tolerance:", self.sp_tol)
        l3.addLayout(f3)
        row = QHBoxLayout()
        self.btn_start = QPushButton("Start checking")
        self.btn_start.setProperty("accent", True)
        self.btn_stop = QPushButton("Stop")
        row.addWidget(self.btn_start, 1)
        row.addWidget(self.btn_stop)
        l3.addLayout(row)
        l3.addWidget(Hint("For each point the view centres on it at a fixed scale: click the SAME feature in the imagery (a building corner, "
                          "manhole, paint stripe end). Space skips, Backspace goes back, Esc stops. Only pick things that are truly the same feature."))
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Use", "Pt", "dE", "dN", "Offset"])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setMinimumHeight(150)
        l3.addWidget(self.table)
        self.stats = QTextBrowser()
        self.stats.setMaximumHeight(210)
        self.stats.setOpenLinks(False)
        l3.addWidget(self.stats)
        r1 = QHBoxLayout()
        self.btn_nudge = QPushButton("Apply suggested nudge")
        self.btn_del = QPushButton("Delete selected")
        r1.addWidget(self.btn_nudge)
        r1.addWidget(self.btn_del)
        l3.addLayout(r1)
        r2 = QHBoxLayout()
        self.btn_report = QPushButton("Report...")
        self.btn_csv = QPushButton("Export CSV...")
        r2.addWidget(self.btn_report)
        r2.addWidget(self.btn_csv)
        l3.addLayout(r2)
        lay.addWidget(g3)

        # ---- Google Earth round trip
        g4 = QGroupBox("Google Earth round trip")
        l4 = QVBoxLayout(g4)
        l4.addWidget(Hint("1) Export your points to KMZ and open it in Google Earth.  2) Drop a pin on the same feature for each point and give it the "
                          "point's NUMBER as its name.  3) Save the pins as KML/KMZ and import them here to get offsets and statistics."))
        r3 = QHBoxLayout()
        self.btn_ge_out = QPushButton("Export KMZ...")
        self.btn_ge_in = QPushButton("Import pins...")
        r3.addWidget(self.btn_ge_out)
        r3.addWidget(self.btn_ge_in)
        l4.addLayout(r3)
        lay.addWidget(g4)
        lay.addStretch(1)

        # wiring
        self.btn_add.clicked.connect(self.add_requested.emit)
        self.btn_rm.clicked.connect(self._remove)
        self.lst.currentRowChanged.connect(self._layer_selected)
        self.lst.itemChanged.connect(self._item_changed)
        self.sl_op.valueChanged.connect(self._opacity)
        self.sp_de.valueChanged.connect(self._nudge_changed)
        self.sp_dn.valueChanged.connect(self._nudge_changed)
        self.chk_off.toggled.connect(self._offline)
        self.btn_cache.clicked.connect(self._clear_cache)
        self.btn_meta.clicked.connect(self._lookup)
        self.btn_start.clicked.connect(self._start)
        self.btn_stop.clicked.connect(self.stop_requested.emit)
        self.btn_nudge.clicked.connect(self._apply_nudge)
        self.btn_del.clicked.connect(self._delete_checks)
        self.btn_report.clicked.connect(lambda: self.report_requested.emit(self.current_layer_name(), self.tol()))
        self.btn_csv.clicked.connect(self._export_csv)
        self.btn_ge_out.clicked.connect(self.ge_export_requested.emit)
        self.btn_ge_in.clicked.connect(self.ge_import_requested.emit)
        self.table.cellDoubleClicked.connect(self._row_double)
        self.table.itemChanged.connect(self._table_item_changed)
        self.sp_tol.valueChanged.connect(self.refresh_stats)
        state.changed.connect(self._state_changed)
        state.project_replaced.connect(self.refresh)
        self.refresh()

    # ------------------------------------------------------------------ helpers
    def _unit(self):
        return self.state.project.h_unit

    def tol(self) -> float:
        return self.sp_tol.value()

    def current_layer(self):
        i = self.lst.currentRow()
        if i < 0:
            return None
        return self.state.project.imagery.get(self.lst.item(i).data(Qt.UserRole))

    def current_layer_name(self) -> str:
        lay = self.current_layer()
        if lay:
            return lay.name
        names = sorted({c.layer_name for c in self.state.project.checks.values()})
        return names[0] if names else ""

    def _state_changed(self, kinds):
        if self._busy:
            return
        self.refresh(keep_selection=True)

    # ------------------------------------------------------------------ refresh
    def refresh(self, keep_selection: bool = False):
        self._busy = True
        pr = self.state.project
        cur_id = None
        if keep_selection and self.lst.currentRow() >= 0:
            cur_id = self.lst.item(self.lst.currentRow()).data(Qt.UserRole)
        self.lst.clear()
        for lay in pr.imagery.values():
            it = QListWidgetItem(lay.name)
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if lay.visible else Qt.Unchecked)
            it.setData(Qt.UserRole, lay.id)
            self.lst.addItem(it)
        if self.lst.count():
            row = 0
            if cur_id is not None:
                for i in range(self.lst.count()):
                    if self.lst.item(i).data(Qt.UserRole) == cur_id:
                        row = i
            self.lst.setCurrentRow(row)
        u = U.LABEL.get(self._unit(), self._unit())
        self.sp_tol.setSuffix(f" {u}")
        if self.sp_tol.value() == 2.0 and self._unit() != "m":
            self.sp_tol.setValue(round(2.0 / U.M_PER_UNIT[self._unit()], 1))
        self._busy = False
        self._layer_selected(self.lst.currentRow())
        self.refresh_checks()

    def _layer_selected(self, row):
        lay = self.current_layer()
        enabled = lay is not None
        for w in (self.sl_op, self.sp_de, self.sp_dn, self.btn_rm):
            w.setEnabled(enabled)
        if lay is None:
            self.lbl_layer.setText("No imagery loaded. Use Add...")
            return
        self._busy = True
        self.sl_op.setValue(int(lay.opacity * 100))
        self.sp_de.setValue(lay.nudge[0])
        self.sp_dn.setValue(lay.nudge[1])
        self._busy = False
        meta = lay.source.get("meta")
        txt = lay.source.get("attribution", "") or ("Georeferenced image file" if lay.kind == "file" else "")
        self.lbl_layer.setText(txt)
        if meta:
            self._show_meta(meta)
        else:
            self.lbl_meta.setVisible(False)

    def _item_changed(self, it):
        if self._busy:
            return
        lay = self.state.project.imagery.get(it.data(Qt.UserRole))
        if lay is not None:
            lay.visible = it.checkState() == Qt.Checked
            self._busy = True
            self.state.refresh(("imagery",))
            self._busy = False

    def _opacity(self, v):
        lay = self.current_layer()
        if lay is None or self._busy:
            return
        lay.opacity = v / 100.0
        self._busy = True
        self.state.refresh(("imagery",))
        self._busy = False

    def _nudge_changed(self):
        lay = self.current_layer()
        if lay is None or self._busy:
            return
        lay.nudge = (self.sp_de.value(), self.sp_dn.value())
        self._busy = True
        self.state.refresh(("imagery",))
        self._busy = False

    def _offline(self, on):
        settings().set("offline_imagery", bool(on))
        self.state.tiles.offline = bool(on)
        self.state.tiles.clear_failed()
        self.canvas.invalidate()

    def _clear_cache(self):
        import shutil
        d = settings().tile_cache_dir
        mb = self.state.tiles.cache_size_mb()
        shutil.rmtree(d, ignore_errors=True)
        d.mkdir(parents=True, exist_ok=True)
        self.canvas.imagery.clear()
        self.canvas.invalidate()
        self.state.log(f"Tile cache cleared ({mb:,.0f} MB).", "ok")

    def _remove(self):
        lay = self.current_layer()
        if lay is None:
            return
        with self.state.edit("Remove imagery", kinds=("imagery",)):
            del self.state.project.imagery[lay.id]

    # ------------------------------------------------------------------ source accuracy
    def _show_meta(self, meta: dict):
        txt = _acc_text(meta, self._unit())
        a = meta.get("accuracy_m")
        kind = "info"
        extra = ""
        if a:
            tol_m = self.tol() * U.M_PER_UNIT[self._unit()]
            if a > tol_m:
                kind = "warn"
                extra = (f"\nThe imagery's own stated accuracy ({a:g} m) is larger than your tolerance ({tol_m:.2f} m): offsets smaller than "
                         f"that cannot be blamed on the survey. Use a higher-accuracy orthophoto (Add > Georeferenced image) for a precise check.")
        self.lbl_meta.set(txt + extra, kind)

    def _lookup(self):
        pr = self.state.project
        lay = self.current_layer()
        if pr.crs.is_local:
            error_box(self, "Source accuracy", "Assign a project coordinate system first.")
            return
        if lay is None or lay.kind != "tiles" or "Esri" not in lay.name:
            info_box(self, "Source accuracy", "The lookup is available for Esri World Imagery. For other imagery, check the provider's documentation "
                                              "or the orthophoto's metadata.")
            return
        v = self.canvas.view
        try:
            lon, lat = pr.crs.to_lonlat(v.cx, v.cy, target=4326)
            meta = run_blocking(self, "Asking Esri about the imagery here ...", fetch_esri_metadata, float(lon), float(lat))
        except RuntimeError as ex:
            error_box(self, "Source accuracy", "Could not reach the service (offline?).", str(ex))
            return
        lay.source["meta"] = meta
        self._busy = True
        self.state.refresh(("imagery",))
        self._busy = False
        self._show_meta(meta)

    # ------------------------------------------------------------------ checks
    def _point_ids(self) -> list[int]:
        pr = self.state.project
        which = self.cmb_which.currentData()
        if which == "sel":
            ids = [i for i in self.state.sel_points if i in pr.points]
        elif which == "view":
            x0, y0, x1, y1 = self.canvas.view.bounds()
            ids = [p.id for p in pr.points.values() if x0 <= p.x <= x1 and y0 <= p.y <= y1]
        else:
            ids = list(pr.points)
        flt = self.ed_filter.text().strip()
        if flt:
            try:
                rx = re.compile(flt, re.I)
                ids = [i for i in ids if rx.search(pr.points[i].desc or "")]
            except re.error:
                error_box(self, "Filter", "That filter is not a valid pattern.")
                return []
        ids.sort(key=lambda i: (len(pr.points[i].number), pr.points[i].number))
        return ids

    def _start(self):
        pr = self.state.project
        lay = self.current_layer()
        if lay is None:
            error_box(self, "Imagery check", "Add an imagery layer first.")
            return
        if pr.crs.is_local:
            error_box(self, "Imagery check", "Assign a project coordinate system first.")
            return
        ids = self._point_ids()
        if not ids:
            error_box(self, "Imagery check", "No points to check - select some points, change 'Check:' or loosen the filter.")
            return
        if len(ids) > 200:
            from .widgets import confirm
            if not confirm(self, "Imagery check", f"That is {len(ids)} points. Continue?", "Start"):
                return
        self.start_requested.emit(ids, lay.name, self.sp_mpp.value())

    def refresh_checks(self):
        pr = self.state.project
        name = self.current_layer_name()
        rows = [c for c in pr.checks.values() if not name or c.layer_name == name]
        rows.sort(key=lambda c: (len(c.number), c.number))
        self._busy = True
        self.table.setRowCount(len(rows))
        tol = self.tol()
        for r, c in enumerate(rows):
            dx, dy = c.image_xy[0] - c.survey_xy[0], c.image_xy[1] - c.survey_xy[1]
            d = math.hypot(dx, dy)
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            chk.setCheckState(Qt.Checked if c.include else Qt.Unchecked)
            chk.setData(Qt.UserRole, c.id)
            self.table.setItem(r, 0, chk)
            for col, txt in ((1, c.number), (2, f"{dx:+.3f}"), (3, f"{dy:+.3f}"), (4, f"{d:.3f}")):
                it = QTableWidgetItem(txt)
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                it.setData(Qt.UserRole, c.id)
                if col > 1:
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                if col == 4 and tol and d > tol:
                    it.setForeground(QColor(255, 110, 110))
                self.table.setItem(r, col, it)
        self.table.resizeColumnsToContents()
        self._busy = False
        self.refresh_stats()

    def refresh_stats(self):
        pr = self.state.project
        name = self.current_layer_name()
        cs = [c for c in pr.checks.values() if c.include and (not name or c.layer_name == name)]
        u = U.LABEL.get(self._unit(), self._unit())
        if not cs:
            self.stats.setHtml("<p style='color:gray'>No checks recorded for this layer yet.</p>")
            self.btn_nudge.setEnabled(False)
            return
        dx = np.array([c.image_xy[0] - c.survey_xy[0] for c in cs])
        dy = np.array([c.image_xy[1] - c.survey_xy[1] for c in cs])
        st = IM.compute_check_stats(dx, dy, self.tol() or None, [c.image_xy for c in cs], [c.survey_xy for c in cs])
        lay = self.current_layer()
        nudge = lay.nudge if lay else (0, 0)
        rows = [("Checks", f"{st.n}"), ("Mean offset (image - survey)", f"dE {st.mean_dx:+.3f}  dN {st.mean_dy:+.3f} {u}"),
                ("Mean / max radial", f"{st.mean_d:.3f} / {st.max_d:.3f} {u}"), ("RMSE radial", f"{st.rmse_r:.3f} {u}"),
                ("Scatter after removing the shift", f"{st.rmse_r_after_shift:.3f} {u}"), ("NSSDA 95%", f"{st.nssda_95:.3f} {u}")]
        if st.n_within_tol is not None:
            rows.append((f"Within {self.tol():g} {u}", f"{st.n_within_tol} of {st.n}  ({100 * st.n_within_tol / st.n:.0f}%)"))
        rows.append(("Suggested nudge", f"dE {st.shift_dx:+.3f}  dN {st.shift_dy:+.3f} {u}"))
        h = "<table cellpadding='2' width='100%'>" + "".join(f"<tr><td><b>{a}</b></td><td align='right'>{b}</td></tr>" for a, b in rows) + "</table>"
        for w in st.warnings:
            h += f"<p style='color:#e0a030'>{w}</p>"
        meta = lay.source.get("meta") if lay else None
        if meta and meta.get("accuracy_m"):
            a_u = meta["accuracy_m"] / U.M_PER_UNIT[self._unit()]
            h += f"<p><i>Imagery stated accuracy: {meta['accuracy_m']:g} m ({a_u:,.1f} {u}). " + \
                 ("Your measured scatter is within that - differences this small say little about the survey." if st.rmse_r < a_u else
                  "Your measured offsets exceed the imagery's stated accuracy.") + "</i></p>"
        self.stats.setHtml(h)
        self.btn_nudge.setEnabled(lay is not None and lay.kind in ("tiles", "file"))

    def _apply_nudge(self):
        lay = self.current_layer()
        pr = self.state.project
        if lay is None:
            return
        cs = [c for c in pr.checks.values() if c.include and c.layer_name == lay.name]
        if not cs:
            return
        mdx = float(np.mean([c.image_xy[0] - c.survey_xy[0] for c in cs]))
        mdy = float(np.mean([c.image_xy[1] - c.survey_xy[1] for c in cs]))
        with self.state.edit("Apply imagery nudge", kinds=("imagery",)):
            lay.nudge = (-mdx, -mdy)
        self.state.log(f"Imagery '{lay.name}' shifted by dE {-mdx:+.3f}, dN {-mdy:+.3f} to line up with the survey (display only - the survey is untouched).", "ok")

    def _delete_checks(self):
        rows = sorted({i.row() for i in self.table.selectedIndexes()})
        ids = [self.table.item(r, 1).data(Qt.UserRole) for r in rows if self.table.item(r, 1)]
        if not ids:
            return
        with self.state.edit("Delete imagery checks", kinds=("checks",)):
            for i in ids:
                self.state.project.checks.pop(i, None)

    def _table_item_changed(self, it):
        if self._busy or it.column() != 0:
            return
        c = self.state.project.checks.get(it.data(Qt.UserRole))
        if c is not None:
            c.include = it.checkState() == Qt.Checked
            self._busy = True
            self.state.refresh(("checks",))
            self._busy = False
            self.refresh_stats()

    def _row_double(self, row, col):
        c = self.state.project.checks.get(self.table.item(row, 1).data(Qt.UserRole))
        if c is not None:
            self.state.center_on(c.survey_xy[0], c.survey_xy[1], self.canvas.view.scale if self.canvas.view.scale > 1 else None)

    def _export_csv(self):
        pr = self.state.project
        name = self.current_layer_name()
        cs = [c for c in pr.checks.values() if not name or c.layer_name == name]
        if not cs:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export checks", "imagery_checks.csv", "CSV (*.csv)")
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:      # BOM so Excel on Windows reads accents and symbols correctly
            w = csv.writer(f)
            w.writerow(["Point", "Survey N", "Survey E", "Image N", "Image E", "dN", "dE", "Offset", "Layer", "Included", "Note", "Time"])
            for c in sorted(cs, key=lambda c: (len(c.number), c.number)):
                dx, dy = c.image_xy[0] - c.survey_xy[0], c.image_xy[1] - c.survey_xy[1]
                w.writerow([c.number, f"{c.survey_xy[1]:.4f}", f"{c.survey_xy[0]:.4f}", f"{c.image_xy[1]:.4f}", f"{c.image_xy[0]:.4f}",
                            f"{dy:.4f}", f"{dx:.4f}", f"{math.hypot(dx, dy):.4f}", c.layer_name, "yes" if c.include else "no", c.note, c.stamp])
        self.state.log(f"Imagery checks written to {path}", "ok")
