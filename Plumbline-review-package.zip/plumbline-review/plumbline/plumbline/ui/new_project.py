"""New-project dialog: name + coordinate system (or plain local coordinates). Never assumes a CRS for you."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QComboBox, QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
                               QRadioButton, QVBoxLayout, QWidget)

from ..core import crs as C
from ..core import units as U
from .crs_dialog import CRSPicker
from .widgets import Hint, error_box


class NewProjectDialog(QDialog):
    def __init__(self, parent=None, name: str = "Untitled"):
        super().__init__(parent)
        self.setWindowTitle("New Project")
        self.resize(860, 640)
        root = QVBoxLayout(self)
        form = QFormLayout()
        self.ed_name = QLineEdit(name)
        form.addRow("Project name:", self.ed_name)
        root.addLayout(form)
        self.r_crs = QRadioButton("Use a coordinate system  (needed for imagery, KML, GIS and datum work)")
        self.r_local = QRadioButton("Local / assumed coordinates  (no coordinate system - you can assign one later)")
        self.r_crs.setChecked(True)
        root.addWidget(self.r_crs)
        self.picker = CRSPicker(kinds=("projected",))
        root.addWidget(self.picker, 1)
        row = QHBoxLayout()
        row.addWidget(self.r_local)
        self.cmb_unit = QComboBox()
        for u in U.LINEAR_CHOICES:
            self.cmb_unit.addItem(U.LABEL[u], u)
        row.addWidget(QLabel("units:"))
        row.addWidget(self.cmb_unit)
        row.addStretch(1)
        root.addLayout(row)
        root.addWidget(Hint("Tip: surveyors in Texas typically use a State Plane zone (e.g. NAD83 / Texas North Central ftUS = EPSG:2276), "
                            "but nothing is assumed - pick what your job's control uses."))
        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self._accept)
        self.buttons.rejected.connect(self.reject)
        root.addWidget(self.buttons)
        self.r_local.toggled.connect(lambda on: self.picker.setEnabled(not on))
        self.crs: C.ProjectCRS | None = None

    def _accept(self):
        if self.r_local.isChecked():
            self.crs = C.ProjectCRS.local(self.cmb_unit.currentData())
        else:
            key = self.picker.current_key()
            if not key:
                error_box(self, "New Project", "Pick a coordinate system from the list, or choose local coordinates.")
                return
            self.crs = C.ProjectCRS.from_epsg(int(key.split(":")[1])) if key.startswith("EPSG:") else C.ProjectCRS(key)
        self.accept()

    @property
    def project_name(self) -> str:
        return self.ed_name.text().strip() or "Untitled"
