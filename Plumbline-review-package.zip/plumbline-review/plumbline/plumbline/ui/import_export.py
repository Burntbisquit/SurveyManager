"""Import pipeline: options panel, per-format dialogs and the dispatcher used by the main window."""
from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout,
                               QGroupBox, QHBoxLayout, QLabel, QLineEdit, QPushButton, QRadioButton, QSpinBox,
                               QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from ..core import crs as C
from ..core import units as U
from ..core.model import ImageryLayer, ImportBatch
from ..core.settings import settings
from ..io import csv_points as CSV
from . import theme
from .crs_dialog import CRSPicker
from .widgets import Banner, Hint, error_box, info_box, run_blocking

CSV_EXT = {".csv", ".txt", ".pnt", ".pts", ".asc", ".dat", ".xyz_"}
LANDXML_EXT = {".xml", ".landxml"}
GIS_EXT = {".shp", ".gpkg", ".geojson", ".json"}
KML_EXT = {".kml", ".kmz"}
IMAGE_EXT = {".tif", ".tiff", ".png", ".jpg", ".jpeg"}

IMPORT_FILTER = ("All supported (*.csv *.txt *.pnt *.pts *.asc *.dat *.xml *.landxml *.dxf *.shp *.gpkg *.geojson *.json "
                 "*.kml *.kmz *.plb);;Point files (*.csv *.txt *.pnt *.pts *.asc *.dat);;LandXML (*.xml *.landxml);;DXF (*.dxf);;"
                 "GIS (*.shp *.gpkg *.geojson *.json);;Google Earth (*.kml *.kmz);;Plumbline project (*.plb);;All files (*)")


# ----------------------------------------------------------------------------- plan
@dataclass
class ImportPlan:
    src_crs: object | None = None          # pyproj CRS; None => numbers already in project coordinates
    geographic: bool = False               # batch holds lon / lat
    assign_crs: C.ProjectCRS | None = None  # give a local project this CRS first
    swap_xy: bool = False
    scale_xy: float = 1.0
    z_scale: float = 1.0
    dup_policy: str = "renumber"
    layer_override: str | None = None
    process_linework: bool = False


def file_crs_from_info(info: dict):
    try:
        if info.get("epsg"):
            return C.CRS.from_epsg(int(info["epsg"]))
        if info.get("crs"):
            return C.CRS.from_user_input(info["crs"])
        if info.get("wkt"):
            return C.CRS.from_wkt(info["wkt"])
    except Exception:
        return None
    return None


def make_batch_transform(project, plan: ImportPlan):
    """-> fn(x, y) -> (x', y') that takes the batch's coordinates into project coordinates."""
    pc = plan.assign_crs or project.crs
    if plan.geographic:
        src = plan.src_crs if plan.src_crs is not None else 4326
        return lambda x, y: pc.from_lonlat(x, y, source=src)
    if plan.src_crs is not None and not pc.is_local:
        return pc.transform_from(plan.src_crs)
    k = plan.scale_xy
    return lambda x, y: (np.asarray(x, float) * k, np.asarray(y, float) * k)


def apply_import(state, batch: ImportBatch, plan: ImportPlan, label: str) -> dict:
    pr = state.project
    with state.edit(f"Import {label}"):
        if plan.assign_crs is not None:
            pr.assign_crs(plan.assign_crs)
        if plan.swap_xy:
            batch.transform_xy(lambda x, y: (np.asarray(y, float), np.asarray(x, float)))
        fn = make_batch_transform(pr, plan)
        batch.transform_xy(fn, plan.z_scale)
        stats = pr.apply_batch(batch, plan.dup_policy, plan.layer_override)
        if plan.process_linework:
            stats["linework"] = pr.process_linework()["strings"]
    return stats


# ----------------------------------------------------------------------------- small CRS chooser
class CRSChooser(QDialog):
    def __init__(self, parent=None, title="Choose coordinate system", allow_geographic=False, suggestions=()):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(900, 560)
        lay = QVBoxLayout(self)
        self.picker = CRSPicker(kinds=("projected", "geographic") if allow_geographic else ("projected",))
        self.picker.set_suggestions(suggestions)
        lay.addWidget(self.picker, 1)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self._ok)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _ok(self):
        if not self.picker.current_key():
            error_box(self, "Coordinate system", "Pick one from the list.")
            return
        self.accept()

    def key(self) -> str:
        return self.picker.current_key()


# ----------------------------------------------------------------------------- options panel
UNIT_CHOICES = [("Same as the project", None), ("US survey feet", "ftUS"), ("International feet", "ft"), ("Metres", "m")]


class ImportOptionsPanel(QWidget):
    """Where the numbers live (CRS / units), plausibility check, duplicates, layers."""

    def __init__(self, state, geographic: bool = False, file_crs=None, file_unit: str | None = None,
                 default_geo_crs: int = 4326, parent=None):
        super().__init__(parent)
        self.state = state
        self.project = state.project
        self.geographic = geographic
        self.file_crs = file_crs
        self.file_unit = file_unit
        self.batch: ImportBatch | None = None
        self._chosen = None                  # CRS the user picked via "Choose..."
        self._assign = None                  # ProjectCRS to assign (local projects)
        pc = self.project.crs
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)

        g = QGroupBox("Where are these coordinates?")
        gl = QVBoxLayout(g)
        self.r_proj = QRadioButton()
        self.r_other = QRadioButton("A different coordinate system:")
        self.r_assign = QRadioButton()
        row = QHBoxLayout()
        row.addWidget(self.r_other)
        self.lbl_other = QLabel("(none chosen)")
        self.btn_other = QPushButton("Choose...")
        row.addWidget(self.lbl_other, 1)
        row.addWidget(self.btn_other)
        if geographic:
            self.r_proj.setVisible(False)
            self.r_other.setText("Longitude / latitude in:")
        if pc.is_local and not geographic:
            self.r_proj.setText("Local coordinates - keep this project local (use the numbers as they are)")
            self.r_assign.setText("")
        else:
            self.r_proj.setText(f"The project's system  ({pc.label})")
        gl.addWidget(self.r_proj)
        self.r_assign_row = QHBoxLayout()
        self.r_assign_row.addWidget(self.r_assign)
        self.lbl_assign = QLabel("")
        self.lbl_assign.setWordWrap(True)
        self.r_assign_row.addWidget(self.lbl_assign, 1)
        self.btn_assign = QPushButton("Pick...")
        self.r_assign_row.addWidget(self.btn_assign)
        self.r_assign.setVisible(pc.is_local and not geographic)
        self.lbl_assign.setVisible(pc.is_local and not geographic)
        self.btn_assign.setVisible(pc.is_local and not geographic)
        gl.addLayout(self.r_assign_row)
        gl.addLayout(row)
        form = QFormLayout()
        self.cmb_units = QComboBox()
        for lbl, v in UNIT_CHOICES:
            self.cmb_units.addItem(lbl, v)
        self.cmb_zunits = QComboBox()
        for lbl, v in [("Same as horizontal", "same"), ("Metres", "m"), ("US survey feet", "ftUS"), ("International feet", "ft"),
                       ("Same as the project's elevation unit", None)]:
            self.cmb_zunits.addItem(lbl, v)
        self.chk_swap = QCheckBox("Swap the two coordinate columns (northing and easting are the wrong way round)")
        self.chk_swap.setVisible(not geographic)
        form.addRow("Horizontal units in file:", self.cmb_units)
        form.addRow("Elevation units in file:", self.cmb_zunits)
        gl.addLayout(form)
        gl.addWidget(self.chk_swap)
        lay.addWidget(g)
        self.fit = Banner("", "info")
        self.fit.setVisible(False)
        lay.addWidget(self.fit)

        o = QGroupBox("Options")
        of = QFormLayout(o)
        self.cmb_dup = QComboBox()
        for lbl, v in [("Renumber the new ones (keep both)", "renumber"), ("Skip the new ones", "skip"),
                       ("Overwrite the existing ones", "overwrite"), ("Keep both with the same number", "keep")]:
            self.cmb_dup.addItem(lbl, v)
        self.ed_layer = QLineEdit()
        self.ed_layer.setPlaceholderText("(blank = keep layers from the file / feature codes)")
        self.chk_lw = QCheckBox("Build linework from feature codes after import")
        of.addRow("If a point number already exists:", self.cmb_dup)
        of.addRow("Put everything on layer:", self.ed_layer)
        of.addRow("", self.chk_lw)
        lay.addWidget(o)

        self.btn_other.clicked.connect(self._choose_other)
        self.btn_assign.clicked.connect(self._choose_assign)
        for w in (self.r_proj, self.r_other, self.r_assign):
            w.toggled.connect(self._refresh)
        self.cmb_units.currentIndexChanged.connect(self._refresh)
        self.cmb_zunits.currentIndexChanged.connect(self._refresh)
        self.chk_swap.toggled.connect(self._refresh)
        self._init_defaults(default_geo_crs)

    # -- defaults
    def _init_defaults(self, geo_default: int):
        pc = self.project.crs
        if self.geographic:
            self._chosen = C.CRS.from_epsg(geo_default)
            self.lbl_other.setText(self._chosen.name)
            self.r_other.setChecked(True)
            self.cmb_zunits.setCurrentIndex(self.cmb_zunits.findData("m"))
            return
        if self.file_unit:
            i = self.cmb_units.findData(self.file_unit)
            if i >= 0 and self.file_unit != pc.unit:
                self.cmb_units.setCurrentIndex(i)
        if pc.is_local:
            if self.file_crs is not None and not self.file_crs.is_geographic:
                try:
                    self._assign = C.ProjectCRS(self.file_crs)
                    self.lbl_assign.setText(f"Assign the file's system to the project: {self._assign.label}")
                    self.r_assign.setChecked(True)
                except Exception:
                    self.r_proj.setChecked(True)
            else:
                self.lbl_assign.setText("Assign a coordinate system to this project (the numbers are already in it)")
                self.r_proj.setChecked(True)
        else:
            if self.file_crs is not None and self.file_crs != pc.crs:
                self._chosen = self.file_crs
                self.lbl_other.setText(f"{self.file_crs.name}   (from the file)")
                self.r_other.setChecked(True)
            else:
                self.r_proj.setChecked(True)

    def _choose_other(self):
        dlg = CRSChooser(self, "Coordinate system of the file", allow_geographic=True)
        if dlg.exec():
            k = dlg.key()
            self._chosen = C.resolve_crs(k)
            self.lbl_other.setText(f"{k}   {self._chosen.name}")
            self.r_other.setChecked(True)
            self._refresh()

    def _choose_assign(self):
        sug = []
        if self.batch is not None and not self.batch.is_empty():
            xy = self.batch.sample_xy(50)
            if len(xy):
                favs = [k for k, _ in C.default_favorites_records()]
                sug = [(k, n) for k, n, _, _ in C.suggest_crs(float(np.median(xy[:, 0])), float(np.median(xy[:, 1])), favs)]
        dlg = CRSChooser(self, "Coordinate system to assign to the project", suggestions=sug)
        if dlg.exec():
            k = dlg.key()
            self._assign = C.ProjectCRS.from_epsg(int(k.split(":")[1])) if k.startswith("EPSG:") else C.ProjectCRS(k)
            self.lbl_assign.setText(f"Assign to the project: {self._assign.label}")
            self.r_assign.setChecked(True)
            self._refresh()

    # -- batch & plausibility
    def set_batch(self, batch: ImportBatch):
        self.batch = batch
        self._refresh()

    def plan(self) -> ImportPlan:
        pc = self.project.crs
        p = ImportPlan(geographic=self.geographic, dup_policy=self.cmb_dup.currentData(),
                       layer_override=self.ed_layer.text().strip() or None, process_linework=self.chk_lw.isChecked(),
                       swap_xy=self.chk_swap.isChecked() and not self.geographic)
        eff = self._assign if (self.r_assign.isChecked() and self._assign is not None) else pc
        if self.r_other.isChecked() and self._chosen is not None:
            p.src_crs = self._chosen
        if self.r_assign.isChecked() and self._assign is not None:
            p.assign_crs = self._assign
        # horizontal scale when there is no CRS conversion doing it for us
        hu = self.cmb_units.currentData()
        if hu and p.src_crs is None and not self.geographic:
            p.scale_xy = U.M_PER_UNIT[hu] / U.M_PER_UNIT[eff.unit]
        # elevation scale
        zu = self.cmb_zunits.currentData()
        if zu == "same":
            src_u = hu or (C.describe_crs(p.src_crs)["unit"] if (p.src_crs is not None and not p.src_crs.is_geographic) else eff.unit)
        elif zu is None:
            src_u = eff.vunit
        else:
            src_u = zu
        p.z_scale = U.M_PER_UNIT.get(src_u, 1.0) / U.M_PER_UNIT.get(eff.vunit, 1.0)
        return p

    def _refresh(self):
        pc = self.project.crs
        self.btn_other.setEnabled(True)
        if self.batch is None or self.batch.is_empty():
            return
        try:
            plan = self.plan()
            xy = self.batch.sample_xy(300)
            if plan.swap_xy:
                xy = xy[:, ::-1]
            fn = make_batch_transform(self.project, plan)
            x, y = fn(xy[:, 0], xy[:, 1])
            eff = plan.assign_crs or pc
            ok, tot = eff.area_of_use_ok(np.asarray(x), np.asarray(y))
            if eff.is_local:
                self.fit.setVisible(False)
                return
            self.fit.setVisible(True)
            if ok == tot:
                self.fit.set(f"Looks right: all {tot} sampled coordinates fall inside the area of use of {eff.authority}.", "info")
            elif ok == 0:
                self.fit.set(f"Probably wrong: none of {tot} sampled coordinates land inside the area of use of {eff.authority} after "
                             f"conversion. Check the coordinate system, the units, or swap northing/easting.", "bad")
            else:
                self.fit.set(f"Only {ok} of {tot} sampled coordinates land inside the area of use of {eff.authority}.", "warn")
        except C.LocalCRSError:
            self.fit.setVisible(True)
            self.fit.set("This project is local - assign a coordinate system to convert from lat/lon or another system.", "warn")
        except Exception as ex:
            self.fit.setVisible(True)
            self.fit.set(f"Could not test the coordinates: {ex}", "warn")

    def validate(self) -> str | None:
        if self.r_other.isChecked() and self._chosen is None:
            return "Choose the coordinate system the file uses."
        if self.r_assign.isChecked() and self._assign is None:
            return "Pick the coordinate system to assign to the project."
        if self.project.crs.is_local and self.r_other.isChecked() and not self.geographic:
            return ("This project uses local coordinates, so a file in another system cannot be converted. "
                    "Either assign a coordinate system to the project, or import the numbers as local coordinates.")
        if self.geographic and self.project.crs.is_local:
            return "Longitude/latitude data needs a project coordinate system. Assign one first (Coordinates menu)."
        return None


class _ImportDialog(QDialog):
    """Dialog shell: header text + panel + OK/Cancel (used by every format except CSV)."""

    def __init__(self, parent, title, summary, panel: ImportOptionsPanel, messages=()):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(560)
        lay = QVBoxLayout(self)
        lay.addWidget(Banner(summary, "info"))
        for m in list(messages)[:4]:
            lay.addWidget(Banner(m, "warn"))
        self.panel = panel
        lay.addWidget(panel)
        self.bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.bb.button(QDialogButtonBox.Ok).setText("Import")
        self.bb.accepted.connect(self._ok)
        self.bb.rejected.connect(self.reject)
        lay.addWidget(self.bb)

    def _ok(self):
        err = self.panel.validate()
        if err:
            error_box(self, "Import", err)
            return
        self.accept()


# ----------------------------------------------------------------------------- CSV dialog
class CsvImportDialog(QDialog):
    MAXPREV = 40

    def __init__(self, state, path, parent=None):
        super().__init__(parent)
        self.state = state
        self.path = Path(path)
        self.setWindowTitle(f"Import points - {self.path.name}")
        self.resize(980, 780)
        self.sniff = CSV.sniff(path)
        root = QVBoxLayout(self)
        top = QHBoxLayout()
        top.addWidget(QLabel("Delimiter:"))
        self.cmb_delim = QComboBox()
        for lbl, d in [("Comma", ","), ("Tab", "\t"), ("Semicolon", ";"), ("Space", " "), ("Pipe", "|")]:
            self.cmb_delim.addItem(lbl, d)
        self.cmb_delim.setCurrentIndex(max(0, self.cmb_delim.findData(self.sniff.delimiter)))
        top.addWidget(self.cmb_delim)
        top.addWidget(QLabel("Skip first"))
        self.sp_skip = QSpinBox()
        self.sp_skip.setRange(0, 1000)
        self.sp_skip.setValue(1 if self.sniff.has_header else 0)
        top.addWidget(self.sp_skip)
        top.addWidget(QLabel("line(s) (headers)"))
        top.addSpacing(16)
        top.addWidget(QLabel("Format:"))
        self.cmb_fmt = QComboBox()
        self.cmb_fmt.addItem("Custom - set the column roles below", None)
        for k, v in CSV.PRESETS.items():
            self.cmb_fmt.addItem(k, v)
        top.addWidget(self.cmb_fmt, 1)
        root.addLayout(top)
        self.tbl = QTableWidget()
        self.tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.horizontalHeader().setVisible(False)
        self.tbl.setAlternatingRowColors(True)
        root.addWidget(self.tbl, 1)
        self.status = Banner("", "info")
        root.addWidget(self.status)
        self.panel = ImportOptionsPanel(state, geographic=False)
        root.addWidget(self.panel)
        self.bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.bb.button(QDialogButtonBox.Ok).setText("Import points")
        self.bb.accepted.connect(self._ok)
        self.bb.rejected.connect(self.reject)
        root.addWidget(self.bb)
        self.roles_cb: list[QComboBox] = []
        self._building = False
        self.cmb_delim.currentIndexChanged.connect(self._delimiter_changed)
        self.sp_skip.valueChanged.connect(lambda: self._rebuild(keep_roles=True))
        self.cmb_fmt.currentIndexChanged.connect(self._preset)
        self._rebuild(keep_roles=False)

    # -- table
    def _load_rows(self):
        text, _ = CSV.read_text(self.path)
        lines = [l for l in text.splitlines() if l.strip() and not l.lstrip().startswith(("#", "//"))]
        d = self.cmb_delim.currentData()
        rows = [[c.strip() for c in CSV._split(l, d)] for l in lines[:self.MAXPREV + self.sp_skip.value()]]
        return rows

    def _delimiter_changed(self):
        self._rebuild(keep_roles=False)

    def _rebuild(self, keep_roles: bool):
        self._building = True
        old_roles = [cb.currentData() for cb in self.roles_cb] if keep_roles else None
        rows = self._load_rows()
        skip = self.sp_skip.value()
        data = rows[skip:]
        header = rows[skip - 1] if skip >= 1 and skip - 1 < len(rows) else None
        n = max((len(r) for r in data), default=0)
        n = max(n, len(old_roles or []))
        if old_roles is None:
            roles = CSV.guess_roles(header if (skip and header) else None, data)
            roles += ["ignore"] * (n - len(roles))
        else:
            roles = (old_roles + ["ignore"] * n)[:n]
        self.tbl.clear()
        self.tbl.setRowCount(len(data) + 1)
        self.tbl.setColumnCount(n)
        self.roles_cb = []
        for c in range(n):
            cb = QComboBox()
            for r in CSV.ROLES:
                cb.addItem(CSV.ROLE_LABELS[r], r)
            cb.setCurrentIndex(max(0, cb.findData(roles[c] if c < len(roles) else "ignore")))
            cb.currentIndexChanged.connect(lambda _i, col=c: self._role_changed(col))
            self.tbl.setCellWidget(0, c, cb)
            self.roles_cb.append(cb)
        for r, row in enumerate(data, start=1):
            for c in range(n):
                self.tbl.setItem(r, c, QTableWidgetItem(row[c] if c < len(row) else ""))
        self.tbl.setRowHeight(0, 30)
        self.tbl.resizeColumnsToContents()
        for c in range(n):
            self.tbl.setColumnWidth(c, max(self.tbl.columnWidth(c), 130))
        self._building = False
        self._geo_changed()
        self._update_preview()

    def _role_changed(self, col):
        if self._building:
            return
        role = self.roles_cb[col].currentData()
        if role not in ("ignore", "attr"):
            self._building = True
            for c, cb in enumerate(self.roles_cb):
                if c != col and cb.currentData() == role:
                    cb.setCurrentIndex(cb.findData("ignore"))
            self._building = False
        self.cmb_fmt.blockSignals(True)
        self.cmb_fmt.setCurrentIndex(0)
        self.cmb_fmt.blockSignals(False)
        self._geo_changed()
        self._update_preview()

    def _preset(self):
        roles = self.cmb_fmt.currentData()
        if not roles:
            return
        self._building = True
        for c, cb in enumerate(self.roles_cb):
            cb.setCurrentIndex(cb.findData(roles[c] if c < len(roles) else "ignore"))
        self._building = False
        self._geo_changed()
        self._update_preview()

    def roles(self):
        return [cb.currentData() for cb in self.roles_cb]

    def _geo_changed(self):
        """Swap the options panel when the mapping says lat/lon."""
        geo = "latitude" in self.roles() and "longitude" in self.roles()
        if geo != self.panel.geographic:
            lay = self.layout()
            i = lay.indexOf(self.panel)
            self.panel.setParent(None)
            self.panel.deleteLater()
            self.panel = ImportOptionsPanel(self.state, geographic=geo)
            lay.insertWidget(i, self.panel)

    def _mapping(self) -> CSV.CsvMapping:
        return CSV.CsvMapping(self.cmb_delim.currentData(), self.sp_skip.value(), self.roles())

    def _update_preview(self):
        if self._building:
            return
        try:
            b = CSV.read_points(self.path, self._mapping(), limit=600)
        except ValueError as ex:
            self.status.set(str(ex), "warn")
            return
        extra = f" ({b.info.get('skipped', 0)} unreadable line(s) in the preview)" if b.info.get("skipped") else ""
        self.status.set(f"Preview: {len(b.points)} point(s) read from the first lines{extra}.", "info" if b.points else "warn")
        self.panel.set_batch(b)

    def _ok(self):
        try:
            self.batch = CSV.read_points(self.path, self._mapping())
        except ValueError as ex:
            error_box(self, "Import points", str(ex))
            return
        if not self.batch.points:
            error_box(self, "Import points", "No readable points - check the delimiter, header lines and column roles.")
            return
        err = self.panel.validate()
        if err:
            error_box(self, "Import points", err)
            return
        self.plan = self.panel.plan()
        self.accept()


# ----------------------------------------------------------------------------- GIS layer dialog
class GisLayerDialog(QDialog):
    def __init__(self, state, path, parent=None):
        super().__init__(parent)
        from pyogrio import read_info
        from ..io import gis_io
        self.path = str(path)
        self.state = state
        self.setWindowTitle(f"Import GIS data - {Path(path).name}")
        self.setMinimumWidth(640)
        lay = QVBoxLayout(self)
        layers = gis_io.list_gis_layers(path)
        form = QFormLayout()
        self.cmb_layer = QComboBox()
        for n, g in layers:
            self.cmb_layer.addItem(f"{n}   [{g}]", n)
        form.addRow("Layer:", self.cmb_layer)
        self.chk_all = QCheckBox(f"Import all {len(layers)} layers of this file (point number / description / elevation fields are guessed)")
        self.chk_all.setVisible(len(layers) > 1)
        self.chk_all.setChecked(len(layers) > 1)
        self.layer_names = [n for n, _ in layers]
        form.addRow("", self.chk_all)
        self.cmb_num = QComboBox()
        self.cmb_desc = QComboBox()
        self.cmb_z = QComboBox()
        form.addRow("Point number field:", self.cmb_num)
        form.addRow("Description / code field:", self.cmb_desc)
        form.addRow("Elevation field:", self.cmb_z)
        lay.addLayout(form)
        self.info_lbl = Banner("", "info")
        lay.addWidget(self.info_lbl)
        self.panel_holder = QVBoxLayout()
        lay.addLayout(self.panel_holder)
        self.panel: ImportOptionsPanel | None = None
        self.bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.bb.button(QDialogButtonBox.Ok).setText("Import")
        self.bb.accepted.connect(self._ok)
        self.bb.rejected.connect(self.reject)
        lay.addWidget(self.bb)
        self._read_info = read_info
        self._gis = gis_io
        self.cmb_layer.currentIndexChanged.connect(self._layer_changed)
        self.chk_all.toggled.connect(self._all_toggled)
        self._layer_changed()
        self._all_toggled(self.chk_all.isChecked())

    def _all_toggled(self, on):
        for w in (self.cmb_layer, self.cmb_num, self.cmb_desc, self.cmb_z):
            w.setEnabled(not on)

    def _layer_changed(self):
        name = self.cmb_layer.currentData()
        info = self._read_info(self.path, layer=name)
        fields = [str(f) for f in info["fields"]]
        guess = self._gis.guess_fields(fields)
        for cmb, role in ((self.cmb_num, "number"), (self.cmb_desc, "description"), (self.cmb_z, "elevation")):
            cmb.clear()
            cmb.addItem("(none)", None)
            for f in fields:
                cmb.addItem(f, f)
            cmb.setCurrentIndex(max(0, cmb.findData(guess.get(role))))
        crs = None
        try:
            crs = C.CRS.from_user_input(info["crs"]) if info.get("crs") else None
        except Exception:
            crs = None
        geographic = bool(crs is not None and crs.is_geographic)
        self.info_lbl.set(f"{info.get('features', '?'):,} feature(s), {info.get('geometry_type', '')}.  "
                          f"File coordinate system: {crs.name if crs else 'NOT STATED - you must say which one it is'}", "info" if crs else "warn")
        if self.panel is not None:
            self.panel.setParent(None)
            self.panel.deleteLater()
        unit = C.describe_crs(crs)["unit"] if crs is not None and not geographic else None
        self.panel = ImportOptionsPanel(self.state, geographic=geographic, file_crs=crs, file_unit=unit)
        self.panel_holder.addWidget(self.panel)

    def _ok(self):
        err = self.panel.validate()
        if err:
            error_box(self, "Import", err)
            return
        self.all_layers = self.chk_all.isChecked() and self.chk_all.isVisible()
        self.layer = self.cmb_layer.currentData()
        self.fields = {k: v for k, v in (("number", self.cmb_num.currentData()), ("description", self.cmb_desc.currentData()),
                                         ("elevation", self.cmb_z.currentData())) if v}
        self.plan = self.panel.plan()
        self.accept()


# ----------------------------------------------------------------------------- dispatcher
class Importer:
    def __init__(self, window):
        self.w = window
        self.state = window.state

    def import_path(self, path) -> bool:
        p = Path(path)
        ext = p.suffix.lower()
        try:
            if ext == ".plb":
                self.w.open_project_path(str(p))
                return True
            if ext in LANDXML_EXT:
                return self._landxml(p)
            if ext == ".dxf":
                return self._dxf(p)
            if ext in GIS_EXT:
                return self._gis(p)
            if ext in KML_EXT:
                return self._kml(p)
            from .. import plugins
            for spec in plugins.registry.importers:
                if ext in spec.extensions:
                    return self._plugin(p, spec)
            if ext in IMAGE_EXT:
                return self.w.add_imagery_file(str(p))
            if ext in CSV_EXT or True:
                return self._csv(p)
        except Exception as ex:
            import traceback
            error_box(self.w, "Import failed", f"{p.name} could not be imported:\n{ex}", traceback.format_exc())
            self.state.log(f"Import of {p.name} failed: {ex}", "error")
        return False

    # -- shared tail
    def _finish(self, batch: ImportBatch, plan: ImportPlan, label: str, path: Path):
        first = not self.state.project.points and not self.state.project.entities
        stats = apply_import(self.state, batch, plan, label)
        bits = [f"{stats['points']:,} points"] if stats["points"] else []
        for k, lab in (("polylines", "polylines"), ("texts", "texts"), ("surfaces", "surfaces")):
            if stats.get(k):
                bits.append(f"{stats[k]:,} {lab}")
        msg = f"Imported {', '.join(bits) or 'nothing'} from {path.name}."
        if stats.get("renumbered"):
            msg += f" {stats['renumbered']} point number(s) already existed and were renumbered."
        if stats.get("skipped"):
            msg += f" {stats['skipped']} duplicate(s) skipped."
        self.state.log(msg, "ok")
        for m in batch.messages:
            self.state.log(f"{path.name}: {m}", "warn")
        self.state.zoom_extents()
        return True

    def _csv(self, p: Path) -> bool:
        dlg = CsvImportDialog(self.state, p, self.w)
        if not dlg.exec():
            return False
        return self._finish(dlg.batch, dlg.plan, f"points ({p.name})", p)

    def _generic(self, p: Path, batch: ImportBatch, title: str, geographic=False, file_crs=None, unit=None, label="") -> bool:
        if batch.is_empty():
            error_box(self.w, title, "\n".join(batch.messages) or "Nothing importable was found in this file.")
            return False
        panel = ImportOptionsPanel(self.state, geographic=geographic, file_crs=file_crs, file_unit=unit)
        panel.set_batch(batch)
        dlg = _ImportDialog(self.w, title, f"{p.name}: {batch.summary()}", panel, batch.messages)
        if not dlg.exec():
            return False
        return self._finish(batch, panel.plan(), label or p.name, p)

    def _landxml(self, p: Path) -> bool:
        from ..io import landxml
        batch = run_blocking(self.w, f"Reading {p.name} ...", landxml.read_landxml, str(p))
        return self._generic(p, batch, "Import LandXML", file_crs=file_crs_from_info(batch.info), unit=batch.info.get("units"),
                             label=f"LandXML ({p.name})")

    def _dxf(self, p: Path) -> bool:
        from ..io import dxf_io
        batch = run_blocking(self.w, f"Reading {p.name} ...", dxf_io.read_dxf, str(p))
        return self._generic(p, batch, "Import DXF", unit=batch.info.get("units"), label=f"DXF ({p.name})")

    def _gis(self, p: Path) -> bool:
        from ..io import gis_io
        dlg = GisLayerDialog(self.state, p, self.w)
        if not dlg.exec():
            return False
        if dlg.all_layers:
            batch = ImportBatch()
            for name in dlg.layer_names:
                b = run_blocking(self.w, f"Reading {p.name} / {name} ...", gis_io.read_gis, str(p), name, None)
                batch.points += b.points
                batch.polylines += b.polylines
                batch.texts += b.texts
                batch.messages += [f"{name}: {m}" for m in b.messages]
                batch.info = batch.info or b.info
        else:
            batch = run_blocking(self.w, f"Reading {p.name} ...", gis_io.read_gis, str(p), dlg.layer, dlg.fields)
        if batch.is_empty():
            error_box(self.w, "Import GIS", "The layer has no usable geometry.")
            return False
        return self._finish(batch, dlg.plan, f"GIS ({p.name})", p)

    def _kml(self, p: Path) -> bool:
        from ..io import kml_io
        from ..core.settings import user_dir
        batch = kml_io.read_kml(str(p), cache_dir=user_dir())
        ov = batch.info.get("overlays", [])
        added = 0
        if ov:
            for o in ov:
                if o.get("file") and self.w.add_kml_overlay(o):
                    added += 1
        if batch.is_empty():
            if added:
                self.state.log(f"Added {added} image overlay(s) from {p.name}.", "ok")
                return True
            error_box(self.w, "Import KML/KMZ", "\n".join(batch.messages) or "Nothing importable was found.")
            return False
        ok = self._generic(p, batch, "Import KML / KMZ", geographic=True, label=f"KML ({p.name})")
        if added:
            self.state.log(f"Added {added} image overlay(s) from {p.name}.", "ok")
        return ok

    def _plugin(self, p: Path, spec) -> bool:
        from ..plugins import PluginAPI
        api = PluginAPI(self.state.project, self.state, log=lambda s: self.state.log(s))
        batch = spec.func(str(p), api)
        return self._generic(p, batch, f"Import - {spec.name}", label=f"{spec.name} ({p.name})")
