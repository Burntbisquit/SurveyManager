"""Smoke / behaviour tests for the dialogs and menu actions that the bigger UI tests don't reach."""
import math

import pytest
from PySide6.QtWidgets import QFileDialog, QInputDialog, QTableWidgetItem

from plumbline.core import crs as C
from plumbline.core.settings import settings
from test_ui import app, auto, pump, win  # noqa: F401  (fixtures)


def test_settings_dialog_applies_theme_and_values(win, app, auto):
    from plumbline.ui import theme
    from plumbline.ui.dialogs import SettingsDialog
    win.settings_dialog()                                             # accepted unchanged: nothing breaks
    d = SettingsDialog(win)
    d.cmb_theme.setCurrentIndex(d.cmb_theme.findData("light"))
    d.cmb_order.setCurrentIndex(d.cmb_order.findData("XY"))
    d.sp_snap.setValue(20)
    d.apply()
    s = settings()
    assert s.get("theme") == "light" and s.get("coord_order") == "XY" and s.get("snap_px") == 20
    win._apply_theme()
    assert theme.current() == "light"
    win.points.reload()
    assert win.points.model.headers()[1] == "Easting"                  # typed / displayed order follows the setting
    win.canvas.render_image(300)
    s.set("coord_order", "NE")
    win.toggle_theme()                                                # back to dark


def test_feature_code_editor_changes_codes_and_layers(win, app, auto):
    from plumbline.ui.dialogs import FeatureCodesDialog
    pr = win.state.project
    d = FeatureCodesDialog(win.state, win)
    codes = [d.tbl.item(r, 0).text() for r in range(d.tbl.rowCount())]
    assert "EP" in codes and "BLDG" in codes
    r = codes.index("EP")
    d.tbl.item(r, 3).setText("PAVEMENT-EDGE")
    d._add_row(__import__("plumbline.core.featurecodes", fromlist=["FeatureCode"]).FeatureCode("CB", "Catch basin", "point", "UTIL-CB"))
    d._ok()
    assert pr.codes.get("EP").layer == "PAVEMENT-EDGE" and pr.codes.get("CB") is not None
    assert "PAVEMENT-EDGE" in pr.layers and "UTIL-CB" in pr.layers
    assert all(p.layer == "PAVEMENT-EDGE" for p in pr.points.values() if p.desc.startswith("EP"))   # re-applied
    win.undo()
    assert win.state.project.codes.get("EP").layer == "ROAD-EP"
    # duplicate codes are refused
    d2 = FeatureCodesDialog(win.state, win)
    d2._add_row(__import__("plumbline.core.featurecodes", fromlist=["FeatureCode"]).FeatureCode("GS", "dup", "point", "X"))
    n = len(win.state.undo_stack)
    d2._ok()
    assert len(win.state.undo_stack) == n and any("same code" in b for b in auto["boxes"])


def test_welcome_help_about_plugins_dialogs_open(win, app, auto):
    from plumbline.ui.dialogs import AboutDialog, HelpDialog, PluginsDialog, WelcomeDialog
    for cls in (HelpDialog, AboutDialog):
        d = cls(win)
        d.show()
        pump(app)
        d.close()
    reloaded = []
    pdlg = PluginsDialog(win, on_reload=lambda: reloaded.append(1))
    pdlg._reload()
    assert reloaded and "Plugin folder" in pdlg.view.toPlainText()
    w = WelcomeDialog(win)
    w._pick("sample")
    assert w.choice == "sample"
    win.show_welcome()                                                 # exec auto-accepts, choice "none"


def test_new_project_dialog_local_and_crs(win, app, auto):
    from plumbline.ui.new_project import NewProjectDialog
    d = NewProjectDialog(win)
    d.ed_name.setText("Job 42")
    d.r_local.setChecked(True)
    d.cmb_unit.setCurrentIndex(d.cmb_unit.findData("m"))
    d._accept()
    assert d.crs.is_local and d.crs.unit == "m" and d.project_name == "Job 42"
    d2 = NewProjectDialog(win)
    d2.picker.select_key("EPSG:6584")
    d2._accept()
    assert d2.crs.authority == "EPSG:6584"
    win.new_project()                                                  # nothing chosen -> friendly error, project unchanged
    assert win.state.project.name.startswith("Sample")


def test_find_select_all_zoom_and_layer_creation(win, app, auto, monkeypatch):
    st = win.state
    monkeypatch.setattr(QInputDialog, "getText", staticmethod(lambda *a, **k: ("20", True)))
    win.find_point()
    p20 = st.project.point_by_number("20")
    assert st.sel_points == {p20.id}
    monkeypatch.setattr(QInputDialog, "getText", staticmethod(lambda *a, **k: ("BLDG", True)))
    win.find_point()
    assert len(st.sel_points) == 4
    win.zoom_selection()
    x0, y0, x1, y1 = win.canvas.view.bounds()
    assert all(x0 <= p.x <= x1 and y0 <= p.y <= y1 for p in st.project.points.values() if p.id in st.sel_points)
    win.select_all()
    assert len(st.sel_points) == len(st.project.points)
    monkeypatch.setattr(QInputDialog, "getText", staticmethod(lambda *a, **k: ("MY-NEW-LAYER", True)))
    win.layers._new()
    assert "MY-NEW-LAYER" in st.project.layers and win.canvas.current_layer == "MY-NEW-LAYER"
    assert win.cmb_layer.currentText() == "MY-NEW-LAYER"


def test_png_export_and_reports_open(win, app, auto, monkeypatch, tmp_path):
    out = tmp_path / "view.png"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", staticmethod(lambda *a, **k: (str(out), "")))
    win.export_png()
    assert out.exists() and out.stat().st_size > 5000
    from plumbline.ui import dialogs
    shown = []
    monkeypatch.setattr(dialogs.ReportViewer, "exec", lambda self: shown.append(self.report.title))
    win.report_points()
    win.report_qa()
    win.report_crs()
    win.report_surface_active()
    pr = win.state.project
    e = next(e for e in pr.polylines() if e.closed)
    win.state.select(entities=[e.id])
    win.report_polylines()
    assert len(shown) == 5 and "Line" in shown[-1]
    win.state.clear_selection()
    win.report_polylines()                                            # nothing selected -> message, not a crash
    assert len(shown) == 5


def test_imagery_check_start_from_dock_with_filter(win, app, auto):
    st, pr = win.state, win.state.project
    win.create_imagery_layer({"kind": "tiles", "name": "Dummy", "source": {
        "name": "Dummy", "url": "http://127.0.0.1:9/{z}/{x}/{y}.jpg", "max_zoom": 19, "min_zoom": 0, "attribution": "",
        "tile_size": 256, "subdomains": "", "ext": "jpg", "headers": {}}})
    win.state.tiles.offline = True                                    # never touch the network here
    win.imagery.lst.setCurrentRow(0)
    win.imagery.cmb_which.setCurrentIndex(win.imagery.cmb_which.findData("all"))
    win.imagery.ed_filter.setText("^(BLDG|MH|SSMH)$")
    ids = win.imagery._point_ids()
    assert len(ids) == 4 + 1 + 1 and all(pr.points[i].desc in ("BLDG", "MH", "SSMH") for i in ids)
    win.imagery.ed_filter.setText("([unclosed")
    assert win.imagery._point_ids() == []                             # bad pattern -> message, empty list
    win.imagery.ed_filter.setText("^BLDG$")
    st.select(points=ids[:2])
    win.imagery.cmb_which.setCurrentIndex(win.imagery.cmb_which.findData("sel"))
    win.imagery.ed_filter.setText("")
    win.imagery._start()
    tool = win.tools["imagery_check"]
    assert win.canvas.tool is tool and len(tool.queue) == 2 and tool.target_id == ids[0]
    tool.skip()
    tool.back()
    assert tool.pos == 0
    tool.stop()
    assert tool.target_id is None and win.canvas.tool is win.tools["select"]
    # local (no CRS) projects refuse politely
    st.new_project("loc", C.ProjectCRS.local("ftUS"))
    st.project.add_point(1, 1, 1)
    win.imagery.refresh()
    win.imagery._start()
    assert any("coordinate system" in b.lower() or "imagery layer" in b.lower() for b in auto["boxes"])


def test_layer_lock_makes_objects_unpickable_and_hidden_unselectable(win, app):
    pr = win.state.project
    p = pr.point_by_number("20")
    pr.layers[p.layer].locked = True
    pr.touch()
    assert win.state.spatial_index().pick(p.x, p.y, 2.0) != ("pt", p.id)
    pr.layers[p.layer].locked = False
    pr.layers[p.layer].visible = False
    pr.touch()
    assert win.state.spatial_index().pick(p.x, p.y, 2.0) != ("pt", p.id)
