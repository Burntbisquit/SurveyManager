"""Regenerate the documentation screenshots:  QT_QPA_PLATFORM=offscreen python tools/make_screenshots.py
(only the 3D / depth view shots, no internet needed:  python tools/make_screenshots.py views)

The imagery shots use live Esri tiles (needs internet) laid under the SYNTHETIC sample site - the survey points do not
correspond to the real features in the picture; the shots only illustrate the panels and reports.
"""
import math
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("PLUMBLINE_HOME", "/tmp/plumbline_shots_home")

import numpy as np
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

from plumbline.core.model import ImageryCheck
from plumbline.core.surface import apply_contours, compute_contour_data
from plumbline.core.tiles import PRESETS
from plumbline.io import reports
from plumbline.sample import make_sample_project, write_sample_files
from plumbline.ui import theme
from plumbline.ui.crs_dialog import CRSDialog
from plumbline.ui.dialogs import ReportViewer
from plumbline.ui.import_export import CsvImportDialog
from plumbline.ui.main_window import MainWindow

ONLY = set(sys.argv[1:])
OUT = Path(__file__).resolve().parent.parent / "docs" / "img"
OUT.mkdir(parents=True, exist_ok=True)
app = QApplication([])


def pump(sec=0.3):
    t = time.time()
    while time.time() - t < sec:
        app.processEvents()
        QTest.qWait(20)


def project_with_contours():
    pr = make_sample_project()
    sf = next(iter(pr.surfaces.values()))
    apply_contours(pr, sf, compute_contour_data(sf, 0.5), 0.5, 5, 0.0, True, 3.0)
    return pr


# ---- main window, dark and light
for name in ("dark", "light"):
    from plumbline.core.settings import settings
    settings().set("theme", name)
    w = MainWindow(project=project_with_contours())
    w.resize(1500, 920)
    w.show()
    pump()
    w.canvas.opts.show_numbers = False
    w.canvas.opts.show_elev = False
    w.view_toggles["show_numbers"].setChecked(False)
    w.view_toggles["show_elev"].setChecked(False)
    w.canvas.zoom_extents()
    w.canvas.invalidate()
    pump()
    w.grab().save(str(OUT / f"main_{name}.png"))
    w.state.tiles.shutdown()
    w.close()

from plumbline.core.settings import settings
settings().set("theme", "dark")
theme.apply_theme(app, "dark")

# ---- 3D view and depth view (the depth view looks across a diagonal line, not just from the front)
if not ONLY or "views" in ONLY:
    w = MainWindow(project=project_with_contours())
    w.resize(1500, 920)
    w.show()
    pump()
    w.view_toggles["show_numbers"].setChecked(False)
    w.view_toggles["show_elev"].setChecked(False)
    w.canvas.zoom_extents()
    w.a_3d.setChecked(True)
    pump(0.6)
    v3 = w.view3d.view
    v3.cam.set_view(32.0, 40.0)
    v3.fit()
    pump()
    v3.grab().save(str(OUT / "view3d.png"))
    w.a_depth.setChecked(True)
    pump(0.6)
    x0, y0, x1, y1 = w.state.project.extents()
    w.depth.view.set_line((x0 + 40, y0 + 70), (x1 - 60, y1 - 30))
    pump(0.6)
    w.depth.view.grab().save(str(OUT / "depthview.png"))
    w.grab().save(str(OUT / "main_depth.png"))
    w.state.tiles.shutdown()
    w.close()
if ONLY == {"views"}:
    sys.exit(0)

files = write_sample_files("/tmp/plumbline_shots_samples")

# ---- CRS manager and CSV import
w = MainWindow(project=make_sample_project())
w.show()
pump()
d = CRSDialog(w.state, w)
d.show()
d.picker.select_key("EPSG:2276")
d.tabs.setCurrentIndex(0)
pump()
d.grab().save(str(OUT / "crs_manager.png"))
d.tabs.setCurrentIndex(3)
d.sp_bx.setValue(2552700)
d.sp_by.setValue(6967100)
d.sp_h.setValue(500)
d.cmb_hu.setCurrentIndex(d.cmb_hu.findData("ftUS"))
d._compute_cf()
pump()
d.grab().save(str(OUT / "crs_ground_scale.png"))
d.close()
from plumbline.core import crs as C
from plumbline.ui.app_state import AppState
from plumbline.core.project import Project
st = AppState(Project("shot", C.ProjectCRS.from_epsg(2276)))
cd = CsvImportDialog(st, files["tsv"])
cd.show()
pump()
cd.grab().save(str(OUT / "csv_import.png"))
cd.close()

# ---- imagery: real Esri tiles + the panel + a check report with simulated offsets
w.state.set_project(make_sample_project())
esri = PRESETS[0]
w.create_imagery_layer({"kind": "tiles", "name": esri.name, "source": esri.to_dict()})
w.resize(1500, 920)
pr = w.state.project
x, y = pr.crs.from_lonlat(-96.5992, 32.7668)
w.state.center_on(float(x), float(y), pr.crs.unit_factor / 0.45)
w.canvas.opts.show_numbers = False
w.canvas.opts.show_elev = False
t0 = time.time()
while time.time() - t0 < 25:
    pump(0.3)
    if w.canvas.imagery.pending == 0 and len(w.canvas.imagery._pix) > 8 and time.time() - t0 > 4:
        break
w.d_img.show()
w.d_img.raise_()
w.imagery.lst.setCurrentRow(0)
try:
    w.imagery._lookup()
except Exception as ex:
    print("metadata lookup skipped:", ex)
rng = np.random.default_rng(4)
pts = [p for p in pr.points.values() if p.desc.startswith(("SW", "LP", "FH", "SIGN", "MH", "BLDG"))][:14]
lay = next(iter(pr.imagery.values()))
for i, p in enumerate(pts, start=1):
    dx, dy = 2.4 + rng.normal(0, 0.9), -1.1 + rng.normal(0, 0.9)           # SIMULATED picks
    thumb = w.canvas.grab_region(p.x, p.y, 220, pr.crs.unit_factor / 0.25,
                                 marks=[(p.x, p.y, "cross", (0, 230, 255)), (p.x + dx, p.y + dy, "ring", (255, 150, 0))])
    from plumbline.ui.tools import qimage_png_b64
    pr.checks[1000 + i] = ImageryCheck(1000 + i, p.id, p.number, (p.x, p.y), (p.x + dx, p.y + dy), lay.name, "", "simulated", qimage_png_b64(thumb), True)
w.state.refresh(("checks",))
w.imagery.refresh()
w.canvas.invalidate()
pump(0.5)
w.grab().save(str(OUT / "imagery_panel.png"))
note = f"{lay.name} - {esri.attribution}. SIMULATED picks for illustration."
rep = reports.imagery_check_report(pr, lay.name, 2.0 / 0.3048006, note, True, w._datum_note())
rv = ReportViewer(w, rep)
rv.resize(980, 820)
rv.show()
pump(0.4)
rv.grab().save(str(OUT / "report_imagery.png"))
rv.write_pdf(str(OUT / "report_imagery_example.pdf"))
rv.close()
w.state.tiles.shutdown()
print("wrote:", sorted(p.name for p in OUT.iterdir()))
