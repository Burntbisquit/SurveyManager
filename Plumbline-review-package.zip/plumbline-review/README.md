# Plumbline — review package

**Project:** Plumbline (SurveyManager) v0.1 → review fixes applied
**Packaged:** 2026-10-03

This package contains the **reviewed and fixed source**, the review itself, and the independent
test harnesses used to check it. Everything here has been run against the packaged source.

---

## Start here

| If you want to… | Open |
|---|---|
| Know what was wrong and why | `docs/CODE_REVIEW.md` |
| Know what was changed | `docs/FIXES_APPLIED.md` |
| Apply the changes to your own checkout | `plumbline-review-fixes.patch` |
| Just run the fixed program | `plumbline/` |
| Re-run or extend the verification | `verification/` |

---

## Contents

```
plumbline-review/
├── README.md                          <- this file
├── plumbline-review-fixes.patch       25 files, +401 / -73, applies to the shipped zip
├── docs/
│   ├── CODE_REVIEW.md                 full review: findings, evidence, what to leave alone
│   └── FIXES_APPLIED.md               each finding -> the fix -> the test that pins it
├── plumbline/                         THE FIXED SOURCE (drop-in replacement)
└── verification/
    ├── check_surface_math.py          volume integration, contour geometry
    ├── property_tests.py              CRS / save / transforms / CSV / DXF / GIS round trips
    ├── property_tests2.py             feature codes, linework, TIN breaklines, NSSDA
    ├── property_tests3.py             reprojection units, breakline enforcement, acre/cy
    └── bench.py                       README performance claims at 100k points
```

## Status of the source in this package

```
$ cd plumbline
$ QT_QPA_PLATFORM=offscreen python3 -m pytest -q
193 passed
```

- **193 tests pass** (was 181). On Python 3.13 the suite went from *6 failed / 175 passed* to all green.
- Works on **Python 3.13 and 3.14**. 3.14 remains the version it is built and tested against and the
  one the Windows installer prefers; 3.13 is now supported too.
- 12 regression tests were added, one per fix.
- No performance regression: 100k points — TIN 0.99 s, contours 0.13 s, volume 0.04 s, QA 1.09 s,
  save 0.83 s, load 0.37 s.

## Applying the fixes to your own checkout

The patch is against the original zip, so:

```bash
git clone https://github.com/Burntbisquit/SurveyManager.git && cd SurveyManager
unzip workspace-01a1009b-*.zip          # gives plumbline/
cd plumbline
git init && git add -A && git commit -m "v0.1 as shipped"
git apply ../plumbline-review-fixes.patch
```

Or simply copy `plumbline/` over your working copy.

## Running the verification harnesses

They locate the source relative to themselves, so no setup is needed:

```bash
cd verification
QT_QPA_PLATFORM=offscreen python3 check_surface_math.py    # ALL SURFACE MATH CHECKS PASSED
QT_QPA_PLATFORM=offscreen python3 property_tests.py        # ALL ROUND-TRIP / PROPERTY CHECKS PASSED
QT_QPA_PLATFORM=offscreen python3 property_tests2.py       # ALL CHECKS PASSED
QT_QPA_PLATFORM=offscreen python3 property_tests3.py       # ALL CHECKS PASSED
QT_QPA_PLATFORM=offscreen python3 bench.py                 # the performance table
```

These are **independent** of the project's own test suite — they were written to check the maths and
the round trips from the outside, not to re-run the author's assertions.

## What was verified, briefly

- **Cut/fill integration** (`_split_volumes`): worst relative error **4.1e-9** over 20,000 random
  triangles against independent analytic integration; exact to 1e-16 on a plane.
- **Breaklines**: 59/59 sub-segments become real TIN edges; ridge elevation exact; no point moved.
- **CRS**: 5 pairs round-trip within **2.8e-8** (sub-micrometre in feet); Z, text heights and
  contour intervals convert correctly.
- **Save/load is byte-identical**; DXF/CSV/GIS round trips preserve bulges, Z and layers.
- **Contours**: exact on a plane to 5e-8; the deviation on a cone matches the predicted
  inscribed-polygon sagitta and shrinks with mesh refinement (discretisation, not a bug).

Full detail, including the things that are *already* right and should be left alone, is in
`docs/CODE_REVIEW.md`.

## Known open items (deliberately not changed)

- LandXML: no profiles, cross-sections or pipe networks; spirals become chords.
- DXF: hatches, dimensions and leaders are skipped on import; no paper-space layouts.
- Surfaces are TIN only; no grid surfaces, end-area or corridor volumes.
- `search_crs` scans the whole EPSG + ESRI catalogue linearly per keystroke — fine at 400 results,
  but a prefix/trigram index is the next step if the CRS dialog ever feels slow.
- Label placement on closed contours can place two labels near the loop's start/midpoint; needs a
  placement rule rather than a patch.
- Pre-existing, correct-but-surprising behaviour, now documented rather than changed: a multi-layer
  GeoPackage import reads the first layer unless the dialog picks one; `volume_between` reports
  `cut` when the existing surface is above the proposed one.
