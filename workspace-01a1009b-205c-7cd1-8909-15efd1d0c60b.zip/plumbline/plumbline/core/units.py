"""Linear-unit helpers.

US survey feet and international feet differ by 2 ppm.  That is invisible on a
small site but matters on State Plane coordinates, so they are distinct units.
"""
from __future__ import annotations

M_PER_UNIT = {
    "m": 1.0,
    "ft": 0.3048,
    "ftUS": 1200.0 / 3937.0,
    "in": 0.0254,
    "yd": 0.9144,
    "km": 1000.0,
    "mi": 1609.344,
}

LABEL = {"m": "m", "ft": "ft", "ftUS": "US ft", "in": "in", "yd": "yd", "km": "km", "mi": "mi"}
LINEAR_CHOICES = ["ftUS", "ft", "m"]


def factor_to_m(unit: str) -> float:
    return M_PER_UNIT[unit]


def unit_from_factor(factor: float | None, name: str = "") -> str:
    """Map a pyproj unit (factor to metres and/or name) to one of our unit codes."""
    if factor:
        for code, f in M_PER_UNIT.items():
            if abs(factor - f) < 1e-9:
                return code
    n = (name or "").lower()
    if "us survey" in n or "survey foot" in n or "survey feet" in n:
        return "ftUS"
    if "foot" in n or "feet" in n:
        return "ft"
    if "metre" in n or "meter" in n:
        return "m"
    return "m"


def convert(value, from_unit: str, to_unit: str):
    return value * (M_PER_UNIT[from_unit] / M_PER_UNIT[to_unit])


def is_foot(unit: str) -> bool:
    return unit in ("ft", "ftUS")


def area_to_acres(area: float, unit: str) -> float:
    """Area in unit^2 -> acres (43,560 sq ft for foot units, as surveyors use)."""
    if is_foot(unit):
        return area / 43560.0
    return area * M_PER_UNIT[unit] ** 2 / 4046.8564224


def area_to_hectares(area: float, unit: str) -> float:
    return area * M_PER_UNIT[unit] ** 2 / 10000.0


def volume_to_cubic_yards(vol: float, h_unit: str, v_unit: str | None = None) -> float:
    """Volume (h_unit^2 * v_unit) -> cubic yards."""
    v_unit = v_unit or h_unit
    m3 = vol * M_PER_UNIT[h_unit] ** 2 * M_PER_UNIT[v_unit]
    return m3 / (0.9144 ** 3)


def volume_to_cubic_meters(vol: float, h_unit: str, v_unit: str | None = None) -> float:
    v_unit = v_unit or h_unit
    return vol * M_PER_UNIT[h_unit] ** 2 * M_PER_UNIT[v_unit]


def fmt_len(value: float, unit: str, decimals: int = 3) -> str:
    return f"{value:,.{decimals}f} {LABEL.get(unit, unit)}"
