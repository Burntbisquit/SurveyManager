"""Synthetic sample site (a small commercial lot with a street) used by the tutorial, screenshots and tests.

Everything here is computer-generated - it is NOT a real survey.  Coordinates sit in NAD83 / Texas North
Central (ftUS, EPSG:2276) near Mesquite, TX only so the CRS tools and imagery have a plausible place to land;
change the project CRS (Coordinates > Project Coordinate System > Assign) to move it anywhere.
"""
from __future__ import annotations

import csv
import math
from pathlib import Path

import numpy as np

from .core.crs import ProjectCRS
from .core.model import ImportBatch, SurveyPoint
from .core.project import Project

E0, N0 = 2552600.0, 6967000.0          # south-west corner of the site


def swale_y(x):
    """North coordinate of the drainage-swale flowline at local easting x."""
    return 300.0 - 0.12 * np.asarray(x, float)


def terrain(x, y):
    """Ground elevation (ftUS-ish) for local coordinates x east, y north of the SW corner."""
    base = 512.0 - 0.012 * x + 0.020 * y
    hill = 5.0 * np.exp(-(((x - 430) / 130.0) ** 2 + ((y - 140) / 130.0) ** 2))
    swale = -1.5 * np.exp(-(((y - swale_y(x)) / 75.0) ** 2))
    return base + hill + swale


def _arc(cx, cy, r, a0, a1, n=7):
    """Points along an arc (degrees, CCW positive), excluding the first point."""
    return [(cx + r * math.cos(math.radians(a)), cy + r * math.sin(math.radians(a))) for a in np.linspace(a0, a1, n)[1:]]


def sample_points(seed: int = 11) -> list[tuple]:
    """[(x, y, z, desc)] in local coordinates (x east, y north of the SW corner)."""
    rng = np.random.default_rng(seed)
    rows: list[tuple] = []
    T = terrain

    def add(x, y, dz, desc):
        rows.append((float(x), float(y), float(T(x, y) + dz), desc))

    R = 30.0
    # -- main street: south edge of pavement y=28, north edge y=52, centreline y=40; side street at x=560 going north
    xs = list(range(0, 621, 40))
    for i, x in enumerate(xs):
        add(x, 28, -0.15, "EP1" + (" B" if i == 0 else " E" if i == len(xs) - 1 else ""))
    north = [(x, 52) for x in range(0, 519, 40)] + [(518, 52)]
    north = [pt for k, pt in enumerate(north) if k == 0 or pt != north[k - 1]]
    for i, (x, y) in enumerate(north):
        add(x, y, -0.15, "EP2" + (" B" if i == 0 else ""))
    for x, y in _arc(518, 82, R, -90, 0):                              # west corner fillet
        add(x, y, -0.15, "EP2")
    for y in range(120, 341, 40):
        add(548, y, -0.15, "EP2")
    add(548, 340, -0.15, "EP2 E") if False else None
    rows[-1] = (*rows[-1][:3], "EP2 E")
    for i, y in enumerate(range(340, 81, -40)):                       # side street east edge, heading south
        add(572, y, -0.15, "EP3" + (" B" if i == 0 else ""))
    add(572, 82, -0.15, "EP3")
    for x, y in _arc(602, 82, R, 180, 270):                           # east corner fillet
        add(x, y, -0.15, "EP3")
    add(620, 52, -0.15, "EP3 E")
    for i, x in enumerate(range(0, 621, 40)):
        add(x, 40, 0.05, "CL1" + (" B" if i == 0 else " E" if x == 620 else ""))
    for i, y in enumerate(range(80, 341, 52)):
        add(560, y, 0.05, "CL2" + (" B" if i == 0 else ""))
    rows[-1] = (*rows[-1][:3], "CL2 E")

    # -- sidewalk behind the north curb
    for i, x in enumerate(range(10, 539, 66)):
        add(x, 60, -0.05, "SW1" + (" B" if i == 0 else ""))
    rows[-1] = (*rows[-1][:3], "SW1 E")

    # -- property line (closed) and fence
    for i, (x, y) in enumerate(((0, 62), (540, 62), (540, 345), (0, 345))):
        add(x, y, 0.0, "PL1" + (" B" if i == 0 else " CLS" if i == 3 else ""))
    for i, x in enumerate(range(0, 541, 90)):
        add(x, 343, 0.0, "FNC1" + (" B" if i == 0 else " E" if x == 540 else ""))

    # -- building 90 x 54 ft with a finished floor 2 ft above the surrounding ground
    bx, by, bw, bh = 150.0, 170.0, 90.0, 54.0
    ff = float(T(bx + bw / 2, by + bh / 2)) + 2.0
    for x, y in ((bx, by), (bx + bw, by), (bx + bw, by + bh), (bx, by + bh)):
        rows.append((x, y, round(ff - 0.35, 2), "BLDG"))
    rows.append((bx + bw / 2, by + bh / 2, round(ff, 2), "FFE"))
    # -- parking lot edge (closed) and a walk to the door
    for i, (x, y) in enumerate(((120, 100), (280, 100), (280, 150), (120, 150))):
        add(x, y, -0.05, "EP4" + (" B" if i == 0 else " CLS" if i == 3 else ""))
    add(195, 152, 0.1, "SW2 B")
    add(195, 100, 0.05, "SW2 E")

    # -- utilities, furniture, trees  (rims sit within a tenth or two of the pavement, as in real life)
    add(95, 46, -0.12, "MH")
    add(430, 46, -0.10, "SSMH")
    add(300, 57, 0.10, "FH")
    add(60, 58, 0.05, "LP")
    add(350, 58, 0.05, "LP")
    add(255, 66, 0.0, "SIGN")
    for x, y, d in ((330, 300, 14), (360, 120, 18), (90, 240, 22), (470, 230, 16), (40, 320, 12)):
        add(x, y, 0.0, f"TREE {d} OAK")

    # -- drainage swale flowline (a breakline: SWL string 1)
    for i, x in enumerate(range(30, 531, 50)):
        add(x, float(swale_y(x)), 0.0, "SWL1" + (" B" if i == 0 else " E" if x == 530 else ""))

    # -- general ground shots on a loose grid (skipping the building, the parking lot and the street)
    for x in np.arange(14, 540, 38):
        for y in np.arange(74, 336, 36):
            if bx - 14 < x < bx + bw + 14 and by - 14 < y < by + bh + 14:
                continue
            if 108 < x < 292 and 88 < y < 162:
                continue
            xx, yy = x + rng.uniform(-9, 9), y + rng.uniform(-9, 9)
            rows.append((float(xx), float(yy), float(T(xx, yy) + rng.normal(0, 0.04)), "GS"))
    for x in range(20, 600, 60):                                      # south of the street
        add(x + rng.uniform(-8, 8), 14 + rng.uniform(-3, 3), rng.normal(0, 0.04), "GS")
    return rows


def make_sample_project(with_surface: bool = True, plant_bust: bool = True) -> Project:
    pr = Project("Sample site (synthetic)", ProjectCRS.from_epsg(2276, vunit="ftUS", vdatum="NAVD88 (assumed)"))
    rows = sample_points()
    pts = []
    for i, (x, y, z, d) in enumerate(rows, start=1):
        pts.append(pr.add_point(E0 + x, N0 + y, round(float(z), 2), number=str(i), desc=d))
    if plant_bust:
        gs = [p for p in pts if p.desc == "GS"]
        b = gs[len(gs) // 2]
        b.z = round(b.z + 4.9, 2)                        # a fat-finger elevation for the QA tool to find
        b.desc = "GS"
    pr.apply_codes_to_points()
    pr.process_linework()
    if with_surface:
        from .core.surface import build_surface_from_project, generate_contours
        sf, rep = build_surface_from_project(pr, "Existing ground", {"ground_only": True, "use_breakline_kind": True,
                                                                     "max_edge": 160.0})
        pr.add_surface(sf)
    pr.notes = ("Synthetic sample: terrain = plane + hill + swale. Point numbers near the middle of the GS shots include "
                "one deliberate +4.9 ft bust for the Data QA tool.")
    return pr


def write_sample_files(folder) -> dict:
    """Write the sample as importable files (CSV points, DXF, LandXML, GeoJSON, KML) plus a project file."""
    from .io import dxf_io, gis_io, kml_io, landxml
    from .core.crs import make_transform

    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    pr = make_sample_project()
    out = {}
    # PNEZD text, the format every data collector can make
    f = folder / "sample_points_PNEZD.csv"
    with open(f, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        for p in pr.points.values():
            w.writerow([p.number, f"{p.y:.3f}", f"{p.x:.3f}", f"{p.z:.2f}", p.desc])
    out["csv"] = f
    # a second, header-ful, tab-separated file in X,Y,Z order (to exercise column mapping)
    f = folder / "sample_points_XYZ_tab.txt"
    with open(f, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, delimiter="\t")
        w.writerow(["PointID", "X", "Y", "Elev", "Code"])
        for p in pr.points.values():
            w.writerow([p.number, f"{p.x:.3f}", f"{p.y:.3f}", f"{p.z:.2f}", p.desc])
    out["tsv"] = f
    f = folder / "sample_site.dxf"
    dxf_io.write_dxf(pr, f, dxf_io.DxfOptions(text_height=3.0))
    out["dxf"] = f
    f = folder / "sample_site.xml"
    landxml.write_landxml(f, pr)
    out["landxml"] = f
    f = folder / "sample_site.gpkg"
    gis_io.write_gis(f, pr, driver="GPKG", crs="EPSG:2276")
    out["gpkg"] = f
    tf = pr.crs.transform_to(4326)
    f = folder / "sample_site.kmz"
    kml_io.write_kml(f, pr, lambda x, y: tf(x, y))
    out["kmz"] = f
    f = folder / "sample_site.plb"
    pr.save(f)
    out["project"] = f
    return out
