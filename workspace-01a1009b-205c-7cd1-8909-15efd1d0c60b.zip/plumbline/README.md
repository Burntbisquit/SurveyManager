# Plumbline

**Planimetric and topographic CAD for survey data** - a desktop app (Python + Qt) that takes your points, LandXML, DXF and GIS
data in, lets you check it against imagery, builds surfaces / contours / volumes, and sends DXF, LandXML, GIS, Google Earth
files and reports back out. It is built to be grown: every piece is plain Python, there is a plugin / script / console layer,
and a headless command line.

> *Plumbline is a working name* - change `APP_NAME` in `plumbline/__init__.py`.
> **This is v0.1, built from scratch against synthetic data. Treat it as a strong foundation, not a finished product** -
> see [What was verified, and what wasn't](#what-was-verified-and-what-wasnt) before trusting it with a deliverable.

![Plumbline main window](docs/img/main_light.png)

## Contents
[Install and run](#install-and-run) · [A 10-minute tour](#a-10-minute-tour) · [Coordinate systems](#coordinate-systems) ·
[Imagery checks](#imagery-checks-and-an-honest-word-on-accuracy) · [Import / export](#import-and-export) ·
[Feature codes](#feature-codes-and-linework) · [Surfaces](#surfaces-contours-volumes-profiles) ·
[3D / depth view / Google Maps](#3d-view-depth-view-and-google-maps) · [Reports](#reports) ·
[Make it yours](#make-it-yours) · [Project layout](#project-layout) · [Verified / limits](#what-was-verified-and-what-wasnt) ·
[Next steps](#where-id-take-it-next)

## Install and run

**Windows, and new to the command line?** Follow [`docs/WINDOWS_SETUP.md`](docs/WINDOWS_SETUP.md). It checks your Python 3.14 and PATH, then you
either type five commands in PowerShell or double-click `install_windows.bat`. After that, double-click `Plumbline.bat` whenever you want to work.

**Linux / macOS, or if you like terminals:**

```bash
python3.14 -m venv .venv && source .venv/bin/activate    # (Windows: skip this line - see the Windows guide)
pip install -r requirements.txt                           # or:  pip install -e .
python -m plumbline doctor                                # checks every library is installed and really works
python -m plumbline                                       # opens the welcome window
```

* **Python 3.14, and only 3.14** (`requires-python` is `>=3.14,<3.15`; PySide6 has no 3.15 support yet). The full test suite passes on it (on Linux), and on Windows every library has a ready-made 64-bit wheel for it (checked with pip's resolver). Everything installs from wheels (PySide6, pyproj, shapely, pyogrio, ezdxf, rasterio ...).
* `rasterio` is optional (GeoTIFF orthophotos); without it PNG/JPG + world file images still work.
* Linux needs the usual Qt system libraries (`libxkbcommon0`, `libegl1`, `libxcb-*` ...) - if Qt complains on start, install them.
* On a headless Linux machine (a server, a cloud sandbox) `tools/live_preview.sh` runs the real window on a virtual screen and serves it to a web browser
  through noVNC (needs `xvfb openbox x11vnc novnc websockify wmctrl`), so you can look at it and click around without a monitor.
* Developed and tested on **Linux (headless/offscreen Qt) only**. PySide6 is cross-platform and I audited the code for OS-specific behaviour
  (explicit UTF-8 for every text file - a test enforces that - fonts that fall back to the system's own, no POSIX-only calls), but I have
  **not run it on Windows or macOS**; the Windows scripts were written from the python.org / PyPI documentation. `python -m plumbline doctor`
  tells you quickly if anything is off.
* `python -m plumbline sample sample_data` regenerates the sample files; `pytest` runs the tests (set `QT_QPA_PLATFORM=offscreen` on a server).

## A 10-minute tour

1. **File > Open Sample Project** (a synthetic lot with a street, building, utilities and ~100 ground shots).
2. **Survey > Data Quality Check** - it finds the planted +4.9 ft elevation bust (point 186). Click the finding to select the point.
3. **Surface > Create Surface** (defaults are fine), then **Surface > Create Contours**. The bust shows up as a tight cluster of contours.
4. Select the building outline, **Reports > Line and Curve Table** (bearings, distances, area).
5. **Surface > Volumes** - surface to a datum, or between two surfaces, optionally inside a selected closed polyline.
6. **File > Export > DXF**, open it in AutoCAD / BricsCAD: real layers and colours, arcs as arcs, contours at elevation.
7. **Imagery > Add Imagery > Esri World Imagery**, then *Look up imagery source* in the Imagery panel (more on that below).
8. **View > 3D View** (drag to orbit), **View > Depth View** (turn the dial to look from any bearing), and **Imagery > Open View Center in Google Maps**.

Typed coordinates work in every drawing tool (box in the toolbar): `N,E` (or `E,N` - see Settings), `@dN,dE`, `@100<N45-30E`,
or just a point number. Drag and drop any supported file onto the drawing.

## Coordinate systems

The coordinate-system manager (**Coordinates > Project Coordinate System**) is the part of a CAD tool that bites, so it is explicit:

![CRS manager](docs/img/crs_manager.png)

* **Nothing is assumed.** A new project asks for a coordinate system, or you choose *local coordinates* (no datum, no position on earth;
  assign a real system later). Texas North Central State Plane in US feet is EPSG:2276 - but you must pick it.
* **Assign vs Reproject.** *Assign* = "these numbers already are EPSG:xxxx, just label them" (nothing moves). *Reproject* = convert
  every coordinate (points, polylines, text, surfaces) and the elevations when the unit changes (US ft <-> m).
* The full **EPSG + ESRI catalogue** is searchable (`texas north central`, `2276`, `UTM 14N`), with favourites, projection parameters,
  area of use and datum shown. The dialog warns when your data falls **outside the system's area of use** - the usual symptom of
  the wrong zone, wrong units or swapped northing/easting (importing offers a one-click swap).
* **Datum transformation is your call**: *automatic*, *none* (NAD83 ~ WGS84), or a specific operation. Each operation is listed
  with PROJ's **stated accuracy** and whether its shift grids are installed (a switch lets PROJ download NADCON5 / geoid grids). Without
  grids the available NAD83 -> WGS84 operations are only 2-4 m accurate - that is shown, not hidden.
* **Ground coordinates**: grid-to-ground scaling about a base point, with a combined-factor calculator (grid scale factor x elevation factor
  from latitude/longitude/height). Assign relabels; Reproject converts grid <-> ground.
* **Calculator tab**: project coordinates <-> lat/lon (decimal + DMS), grid convergence, scale factor, a Google Maps link and
  *Copy 'lat, lon'* for pasting into Google Earth.
* Z is never pushed through horizontal datum shifts; vertical unit and datum label are kept separately.

![Ground scale](docs/img/crs_ground_scale.png)

## Imagery checks (and an honest word on accuracy)

![Imagery panel](docs/img/imagery_panel.png)

**Imagery > Add Imagery** adds Esri World Imagery, USGS orthoimagery, OpenStreetMap (context), **any XYZ tile URL** (e.g. a county
orthophoto service), or **your own georeferenced image** (GeoTIFF, or PNG/JPG + world file, or a KMZ ground overlay). Tiles are cached on disk
(works offline afterwards) and drawn with the correct grid-convergence rotation for your projection.

**Read this before you rely on a check.** Online imagery is not survey-grade. Esri publishes the source and stated accuracy of its mosaic, and
Plumbline fetches it (*Source accuracy > Look up*): at the sample location (Mesquite, TX) the service reported
*Vantor Vivid Advanced WV03, captured 10/8/2025, 0.31 m pixels, **stated accuracy 8.47 m (27.8 ft)***. So against that imagery you can catch
blunders (wrong zone, swapped coordinates, mis-keyed points, systematic shifts of tens of feet) but **not** verify a survey to the foot -
offsets smaller than the imagery's own accuracy say nothing about your points. The panel and every report print the stated accuracy next to
your results and warn when it exceeds your tolerance. For a *precise* check, load a high-accuracy orthophoto (state / county / your own) through
*Georeferenced image* or *Custom tile URL*.

**Workflow**
1. *Start checking* (selected points / points in view / all, optionally filtered by description such as `BLDG|MH|SW` - pick hard, visible features).
2. The view centres on each point at a fixed picking scale. **Click the same feature in the imagery.** Space skips, Backspace goes back, Esc stops.
3. Live statistics: mean offset, RMSE x / y / radial, scatter after removing the mean shift (random vs systematic), **NSSDA horizontal accuracy at 95%**
   (the standard 2.4477 x 0.5 x (RMSEx + RMSEy) formula when RMSEx/RMSEy is 0.6-1.0; flagged as approximate otherwise; warns below 20 points),
   count within tolerance, and a best-fit rotation/scale.
4. *Apply suggested nudge* shifts the **displayed** imagery by minus the mean offset (your survey is never altered). *Report...* gives a table
   with a thumbnail of every pick; save as PDF / HTML / CSV / Excel.

![Imagery check report](docs/img/report_imagery.png)
<sub>(Simulated picks over real imagery, for illustration only.)</sub>

**Google Earth round trip**: *Export KMZ* (datum handling shown and remembered) -> open in Google Earth -> drop a pin on the same feature for each
point, named with the point number -> save the pins as KML/KMZ -> *Import pins*. Offsets and statistics are computed the same way.

Terms: the Esri / USGS / OSM tile services have their own terms of use and attribution (shown on the map). Check them before putting
screenshots in deliverables; Google Maps tiles are deliberately **not** used (their terms forbid it).

## Import and export

| | Import | Export |
|---|---|---|
| **Point text** (CSV, TXT, PNEZD...) | any delimiter, header detection, column-role preview, presets (P,N,E,Z,D / P,E,N,Z,D / lat-lon...), null elevation, bad-row report | same presets, delimiter, decimals, elevation unit, output CRS or lat/lon |
| **LandXML** 1.x | CgPoints, TIN surfaces (invisible faces skipped), parcels, plan features, alignments (lines, arcs, irregular lines; spirals as chords), file CRS + units | points, TIN surfaces, linework with true arcs |
| **DXF** | lines, polylines with bulges, 3D polylines, circles, arcs, splines/ellipses, text/mtext, points, blocks (as attributed points or exploded), 3DFACE/polyface -> surface, layer colours | layers + colours + linetypes, LWPOLYLINE with bulges, 3D polylines where Z varies, contours at elevation, point labels or attributed blocks, optional 3DFACE TIN, `$INSUNITS`, R2000-R2018 |
| **GIS** | Shapefile, GeoPackage, GeoJSON (all layers at once or one), field mapping, polygons with holes | GeoPackage (points/lines/polygons layers), Shapefile, GeoJSON, any output CRS |
| **Google Earth** | KML/KMZ placemarks, lines, polygons, ground overlays | KML / KMZ, WGS84, styled by layer |

Every import states **where the numbers live** (project system / another system / local), checks plausibility against the area of use, and
handles unit conversion (horizontal *and* elevations), duplicate point numbers (renumber / skip / overwrite / keep) and layer assignment.

## Feature codes and linework

A description is parsed as `CODE[string] [flags] [notes]`: `EP B` begins an edge-of-pavement string, `EP` continues it, `EP E` ends it,
`EP CLS` closes it, `EP2` is string 2 (interleaved strings are kept apart), `TREE 18 OAK` is a point code with notes. **Survey > Feature Code Table**
edits the 42-code starter library (layer, colour, linetype, point/line/polygon, breakline, counts-as-ground). *Process Linework* builds polylines
(regenerated, never duplicated); breakline codes feed the surface.

## Surfaces, contours, volumes, profiles

* **TIN** (Delaunay) from ground points; **breaklines are honoured exactly** (conforming insertion, crossings noded with elevation averaging and a warning),
  optional boundary / hole polylines and a maximum edge length (with a suggestion) so the TIN doesn't bridge gaps. A surface whose inputs changed is flagged
  *out of date*; Edit / Rebuild fixes it.
* **Contours**: minor/index, base, smoothing, labels placed upright along the line. Generated entities - re-running replaces them.
* **Volumes**: exact per-triangle cut/fill to a datum (with the triangle split exactly where it crosses the datum), clipped to a polygon; surface-to-surface by
  the composite method (or a grid method for comparison with other software). Results in cubic units, cubic yards, cubic metres, with areas.
* **Profile** along any polyline (exact TIN-edge intersections, gaps where the line leaves the surface), vertical exaggeration, hover read-out, CSV / PNG;
  **cross-sections** at an interval and half-width to CSV.
* Display: elevation tint + hill-shade (smooth, Gouraud), hill-shade only, slope classes, TIN edges; big TINs use a cached raster so panning stays fast.

## 3D view, depth view and Google Maps

![3D view](docs/img/view3d.png)

* **3D view** (*View > 3D View*, `Ctrl+3`) - orbit around the surface, points and linework. Drag to orbit, Shift / right / middle drag to pan, wheel to zoom,
  double-click to fit. Presets: *Top* (the plan, north up), *Front*, *Right*, *Back*, *Left*, *Iso*; perspective or orthographic; a **vertical exaggeration**
  that is picked for you (a flat site needs several times to show its shape). It is a *viewer*: no editing or drawing tools - select points in the plan and
  they light up in 3D. Terrain hides what is behind it while anything lying on the surface (survey points, breaklines, contours) stays visible. Big data is
  simplified while you move and sharpens a moment after you let go.
* **Depth view** (*View > Depth View*, `Ctrl+4`) - a side-on window you can **rotate to any bearing**, so it is not stuck looking from the front:

  ![Depth view](docs/img/depthview.png)

  ![The depth line and slab drawn on the plan, with the depth view looking across them](docs/img/main_depth.png)

  You look along a compass direction at a *slab* of the site that starts at the **depth line** and runs a chosen **Depth** beyond it. The ground is drawn as
  sections cut through the surface at the line and at planes further in (fainter = deeper); points and linework inside the slab get smaller and dimmer with
  depth. **Rotate** with *N / E / S / W*, the dial, the bearing box, *-15 / +15*, *Flip*, the arrow keys, or right-drag in the view. The slab is drawn on the plan
  (line, shaded depth, arrow for the viewing direction). *Follow plan* keeps the line through the middle of the plan as you pan it; or aim it yourself with
  **View > Depth Line** / *Pick line on plan...*: click a start and an end (snaps to points) and the view looks across that line to its LEFT - draw it the other
  way to look the other way. *Start* / *Depth* move and thicken the slab, wheel zooms about the cursor, `Ctrl`+wheel changes the vertical exaggeration.
* **Google Maps** (*Imagery > Open View Center in Google Maps*, `Ctrl+Shift+M`) - opens the **center of the plan view** (the middle of what you see) in your browser,
  satellite layer with a pin, at a zoom that matches the plan's scale; a street-map variant and *Copy Google Maps Link* are next to it. It needs a real coordinate
  system (a project in local coordinates has no place on earth); if no browser can be started the link goes to the clipboard.

## Reports

Point list, surface summary (with slope distribution), volume, line & curve table (bearing/distance/radius/area/acres), data-quality findings, coordinate-system
and imagery-check reports. One viewer: **Save PDF / HTML / CSV / Excel** (the on-screen page is always white, like the print).

## Make it yours

**Plugins** - drop a `.py` in the plugin folder (*Plugins > Open Plugin Folder*; *Install example plugins* in the Plugin Manager):

```python
from plumbline.plugins import command, importer, exporter, Param

@command("Tools/Round elevations", params=[Param("decimals", int, 2, "Decimal places")])
def round_z(api, decimals=2):
    with api.edit("Round elevations"):                      # one undo step, repaint, dirty flag - all handled
        for p in api.selected_points() or api.points():
            if p.z == p.z:
                p.z = round(p.z, decimals)
```

Commands get an auto-built parameter dialog and appear under *Plugins*; importers join *File > Import*, exporters *File > Export*. A plugin that raises is rolled back and
reported, and a plugin file with an error never stops the app from starting.

**Scripts and console** - *Plugins > Run Script* runs any `.py` with `project`, `api`, `np`, `math`, `G` (geometry), `cogo`, `U` (units) in scope; the **Python console** dock
does the same interactively. **Headless**: `python -m plumbline run script.py job.plb --save out.plb`, `python -m plumbline export-dxf job.plb out.dxf`, `python -m plumbline info job.plb`. `python -m plumbline job.plb` opens a project
(or imports a CSV / DXF / LandXML / GIS file); on Windows `Plumbline.bat` does the same, and you can drag a file onto it.

[`docs/EXTENDING.md`](docs/EXTENDING.md) has the data model, the key functions and worked examples (new importer, batch script, custom report).

## Project layout

```
plumbline/
  core/      Qt-free engine: crs, project/model, surface (TIN, contours, volumes, profiles), featurecodes, cogo, spatial (pick/snap),
             imagery (Web-Mercator maths, NSSDA stats, georeferenced images), tiles (disk-cached tile store, Esri metadata), qa, units, settings,
             scene3d (3D / depth-view camera maths + software renderer), maps (Google Maps links), ramps (colour ramps)
  io/        csv_points, landxml, dxf_io, gis_io, kml_io, reports (HTML / CSV / XLSX)
  plugins/   the plugin & script API (+ examples/)
  ui/        main_window, canvas + render (scene cache, fast Qt paths, Gouraud surface), tools, docks, dialogs per area,
             view3d (orbit view), depthview (rotatable elevation / depth view)
  sample.py  the synthetic sample site          cli.py  command line          doctor.py  `plumbline doctor` health check
Plumbline.bat, install_windows.bat   Windows launcher and one-time setup (see docs/WINDOWS_SETUP.md)
tests/       181 automated tests (core maths, I/O round trips, plugins, the 3D renderer, an end-to-end Qt suite driving real mouse events, and portability checks)
sample_data/ sample files in every format       tools/make_screenshots.py   regenerates docs/img      tools/live_preview.sh   window in a browser (Xvfb + noVNC)
```

Projects are saved as **`.plb`** - plain JSON (numpy arrays zlib+base64 inside), versioned, written atomically; easy to inspect or convert.
Undo is whole-project snapshots (30 deep).

## What was verified, and what wasn't

**Verified (automated):** 181 tests, including analytic checks - exact plane and gable-roof volumes, datum-crossing triangles, breaklines surviving noisy data,
closed contours, profile gaps; CRS round trips, ground-scale algebra, combined factors against known values, unit conversion in every importer (a metric LandXML and DXF landing on
top of the original US-foot data); import/export round trips for every format; the imagery check tool against a local tile server (offsets recovered to the pixel, nudge, report, offline
mode); the Google Earth pin round trip; the 3D renderer (camera conventions, terrain hiding what is behind it while points on the surface stay visible, slab clipping for the depth view) and the Google Maps link; undo/redo; plugin isolation and rollback; and a Qt suite that clicks, drags and types into the real window.
Several real bugs were found and fixed that way.
Live checks: real Esri tiles load, orient correctly (north-up with the expected ~1 degree grid rotation) and the accuracy lookup works against Esri's service.

**Performance** (100,000 points, ~200,000-triangle TIN, 2 CPU sandbox): import 0.14 s, TIN build 1.3 s, contours 0.1 s, volume 0.03 s, data-quality scan 1 s, save 0.9 s / load 0.5 s, redraw 0.04-0.35 s,
one undo snapshot 0.6 s, DXF export 6 s as points only - or about 47 s with the default number / elevation / description labels, because ezdxf creates each of the 300,000 text entities one by one (a few thousand points take a second or two).
3D view, same data plus 87,000 line segments, 1100 x 750 window: the sharp picture takes about 1.4 s, while you drag it is simplified to about 0.1 s a frame
(drawn in software, no graphics card needed; a few thousand points redraw in ~10 ms).

**Not verified / limits you should know about**
* No real field data was available - all test data are synthetic. **Run your own jobs through it and compare against your usual software before relying on it** (volumes, contours and
  coordinate conversions especially). Send me what breaks.
* Not run on Windows or macOS (see Install above); GUI looked at only through offscreen screenshots.
* Datum shifts without grids are metre-level (shown in the UI). No vertical-datum / geoid transformations (the vertical datum is a label).
* Online imagery accuracy is what it is (see above). No automatic feature matching - checks are manual picks.
* LandXML: no profiles, cross-sections or pipe networks; spirals become chords. DXF: hatches, dimensions and leaders are skipped (reported on import); no paper-space layouts.
* CAD editing is basic (draw, select, grips, move, transform; no trim / extend / offset / fillet). Surfaces are TIN only (no grid surfaces); no end-area / corridor volumes.
* Undo snapshots the whole project: fine to ~100k points, sluggish beyond. Plugins run arbitrary Python - only install ones you trust.
* 3D / depth views: drawn in software and sorted far-to-near by triangle centre, so very long sliver triangles can mis-order at grazing angles; point and line
  visibility is tested to about 1.5 % of the scene depth (something that far *behind* the ground can still show); point numbers in 3D are not hidden by terrain;
  text, imagery and DXF-only entities are not drawn in 3D. Linework without elevations is draped on the surface (or shown at the mean elevation of the points).

## Where I'd take it next
1. Your real data: bring a typical job (CSV + the CAD file you hand off) and let's tighten import presets, feature codes, DXF layer standards and text styles to match your office.
2. Plot sheets: title blocks, scale-aware plan sheets and PDF plotting.
3. Corridor tools (alignments with stationing, cross-section end-area volumes) and profile sheets.
4. Higher-accuracy imagery sources for your area (state / county orthos as tile services) wired in as presets.
5. Raw-data support (RW5 / JobXML) and least-squares adjustment.

## Third-party notes
PySide6 (Qt) is LGPL; pyproj, shapely, ezdxf, pyogrio, rasterio, matplotlib, openpyxl, scipy and numpy have permissive licences. Imagery services belong to their providers (Esri, USGS, OpenStreetMap).
