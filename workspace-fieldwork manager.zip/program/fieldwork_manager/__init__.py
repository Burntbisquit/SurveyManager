
"""fieldwork_manager package — modular dev, single-file ship via build.py"""
from .config import *
from .config import CONTROL_RANGE, BOUNDARY_RANGE, GENERAL_START, DEFAULT_CREW_NUMBER
from .utils_sort import natural_key, NaturalSortItem, NumericSortItem
from .detectors import normalize_point_number, point_number_core, find_exact_duplicate_groups, find_similar_number_groups, find_close_ne_groups, find_close_xy_groups, _cardinal_direction, _bearing_dms, _format_dms, _format_distance_direction
from .io_carlson import read_carlson_fieldbook, write_fwb_file, read_fwb_file, write_check_report, read_check_report, build_check_report_rows, build_unified_report_rows, write_unified_report, read_unified_report
from .parse import _strip_trailing_digits, _classify_tokens_sequential, _extract_tokens, parse_desc_field, _validate_line_command_order, build_f2f_set_from_fieldbook
from .clean import CleanDescriptionDialog, is_descriptions_clean, validate_renumber_allowed, crew_blocks
