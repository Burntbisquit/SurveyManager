
# utils_sort.py — natural sort, numeric sort items
import re
from PyQt6.QtWidgets import QTableWidgetItem

def natural_key(s, letters_first=True):
    if s is None:
        return []
    text = str(s)
    parts = re.split(r'(\d+)', text)
    key_list = []
    digit_code = 1 if letters_first else 0
    letter_code = 0 if letters_first else 1
    for p in parts:
        if not p:
            continue
        if p.isdigit():
            key_list.append((digit_code, int(p)))
        else:
            key_list.append((letter_code, p.lower()))
    return key_list

class NaturalSortItem(QTableWidgetItem):
    def __init__(self, text="", letters_first=True):
        super().__init__(text)
        self.letters_first = letters_first
    def __lt__(self, other):
        if not isinstance(other, QTableWidgetItem):
            return False
        return natural_key(self.text(), self.letters_first) < natural_key(other.text(), getattr(other, 'letters_first', self.letters_first))

class NumericSortItem(QTableWidgetItem):
    def __init__(self, value=None):
        super().__init__()
        self._numeric_value = None
        if value is not None:
            self.set_value(value)
    def set_value(self, value):
        if value is None:
            self._numeric_value = None
            self.setText("")
            return
        s = str(value).strip()
        if s == "":
            self._numeric_value = None
            self.setText("")
            return
        try:
            self._numeric_value = float(s)
        except (ValueError, TypeError):
            self._numeric_value = None
    def numeric_value(self):
        return self._numeric_value
    def __lt__(self, other):
        if not isinstance(other, NumericSortItem):
            return super().__lt__(other)
        left = self._numeric_value
        right = other._numeric_value
        if left is None and right is None:
            return False
        if left is None:
            return True
        if right is None:
            return False
        return left < right
