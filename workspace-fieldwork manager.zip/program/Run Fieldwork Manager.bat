@echo off
title Fieldwork Manager
cd /d "%~dp0"
echo Launching Fieldwork Manager (modules)...
py -3 run.py
if %errorlevel%==9009 (
  echo py launcher not found, trying python...
  python run.py
)
if %errorlevel%==9009 (
  echo python not found, trying python3...
  python3 run.py
)
if %errorlevel%==9009 (
  echo Python not found. Install Python 3.10+ and ensure py or python is on PATH.
)
pause
