#!/usr/bin/env python3
"""Launch Fieldwork Manager — modular (program/fieldwork_manager/*)"""
import sys
from PyQt6.QtWidgets import QApplication
from fieldwork_manager.ui_main import MainWindow
if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec())
