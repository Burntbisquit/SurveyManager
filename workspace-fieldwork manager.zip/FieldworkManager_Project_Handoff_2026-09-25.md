# Fieldwork Manager — Project Handoff (Uploadable for Next Chat)

**Date:** 2026-09-25 (America/Chicago, Mesquite TX)  
**Workspace root:** `/home/user`  
**Ship:** `FieldworkManager.zip` 163K 18 files — 2026-09-25 16:31 (latest, includes QCheckBox + _on_coord_manage fixes)  
**Launch:** `program/Run Fieldwork Manager.bat` (py -3 → python → python3, 9009-only fallback) or `py -3 program/run.py` / `python program/run.py`  
**Python:** 3.10+, PyQt6, pyproj 3.8.0 (optional but required for accurate State Plane → WGS84; pure-python Texas 2011 LCC fallback active if missing)

---

## 1. What This Is
Modular Carlson fieldwork manager for Texas survey crews. Scans raw fieldwork CSVs, builds **Consolidated Field Data** (`.fwk` 8-col OID/PtNum/N/E/Z/Desc/Parent/Source), runs **unified checks** (Exact Duplicate, Similar Number, Close NE 0.1 + elev 0.1, Description/Line), offers **master-protected renumbering** (crew blocks), and exports **KML/KMZ (Google Earth, clampToGround)** and **GeoJSON/CSV (QGIS)** using **2011 Texas State Plane + TXDOT SAF top-layer scaler**.

---

## 2. Current Coordinate System — 2011 Texas ONLY (per 2026-09-25 user request)

**User constraints (113-115):**
- (113) ONLY 2011 Texas 2011 adjustments — no legacy 2275-2279/32137-32141, no UTM/CONUS.
- (114) REMOVE CSF / GRID/GROUND toggle — keep only SAF.
- (115) TOP LAYER SCALER first-out-last-in: `GPS → State Plane grid (TXNC 2011 pre-final ≈6M N ×3M E, origin 0,0) → × SAF → Final Ground (stored)`. SAF is user-keyed TXDOT county-wide factor (e.g., Bexar 1.00017, any). Export = `Final ÷ SAF → Grid → WGS84`.

**Library:** `program/fieldwork_manager/coord_systems.py` ~14.8K, `EPSG_LIBRARY` 11 entries only:

| EPSG | Name | Zone | Units |
|------|------|------|-------|
| 6581 | NAD83(2011) / Texas North (m) | North (m) 2011 | m |
| 6582 | NAD83(2011) / Texas North (USft) | North 2011 | USft |
| 6583 | NAD83(2011) / Texas North Central (m) | North Central (m) 2011 | m |
| **6584** | **NAD83(2011) / Texas North Central (USft)** | **North Central 2011** — **Mesquite, TX default** | USft |
| 6577 | NAD83(2011) / Texas Central (m) | Central (m) 2011 | m |
| 6578 | NAD83(2011) / Texas Central (USft) | Central 2011 | USft |
| 6587 | NAD83(2011) / Texas South Central (m) | South Central (m) 2011 | m |
| 6588 | NAD83(2011) / Texas South Central (USft) | South Central 2011 | USft |
| 6585 | NAD83(2011) / Texas South (m) | South (m) 2011 | m |
| 6586 | NAD83(2011) / Texas South (USft) | South 2011 | USft |
| 4326 | WGS 84 (lat/lon) | Geographic | deg |

`DEFAULT_ACTIVE_EPSGS = [6584,6582,6578,6588,6586,4326]` (USft zones + WGS84)  
`MESQUITE_TX_RECOMMENDED_EPSG = 6584` (was 2276, migrated)

**TEXAS_LCC_PARAMS** (meters, from `CRS.to_json_dict()` via pyproj, verified):

```
6581/6582 North:          lat1 36.18333333 lat2 34.65 lat0 34.0 lon0 -101.5 fe 200000 fn 1000000
6583/6584 North Central:  lat1 33.96666666 lat2 32.13333333 lat0 31.66666666 lon0 -98.5 fe 600000 fn 2000000
6577/6578 Central:        lat1 31.88333333 lat2 30.11666666 lat0 29.66666666 lon0 -100.33333333 fe 700000 fn 3000000
6587/6588 South Central:  lat1 30.28333333 lat2 28.38333333 lat0 27.83333333 lon0 -99.0 fe 600000 fn 4000000
6585/6586 South:          lat1 27.83333333 lat2 26.16666666 lat0 25.66666666 lon0 -98.5 fe 300000 fn 5000000
```

**SAF handling:** `coord_systems.py` `apply_surface_factor(n,e,factor, direction="ground_to_grid")` and `apply_saf(n,e,saf, is_ground=True)` both do `N_grid = N_ground / SAF, E_grid = E_ground / SAF` from **origin 0,0** (no base point). `convert_to_wgs84(n,e,epsg, surface_factor, factor_mode, is_ground)` infers `is_ground = (factor_mode=="ground_to_grid")`; if `is_ground and SAF!=1` then divides first, then `pyproj Transformer EPSG→4326` or fallback `_texas_lcc_to_wgs84` (which converts USft→m via `USFT_TO_METERS=1200/3937` then `_lcc_inverse` with GRS80 a/f/e2). Verified: `32.7668,-96.5992 → 6584 E2552722.866 N6967192.918 → back lat diff 0.0 pyproj, ~9e-10 fallback; SAF 1.00017 ground → back 0.0 diff`.

**Legacy migration:** `LEGACY_2011_MAP = {2275:6582,2276:6584,2277:6578,2278:6588,2279:6586,32138:6581,...}`, `migrate_epsg()` and `migrate_active_list()` called on project load (`ui_main.py` ~2227) and on Import; old `coord_csf` key also migrated to `coord_surface_factor`.

---

## 3. UI — Coordinate System Manager + Map Export (2026-09-25)

**File:** `program/fieldwork_manager/ui_main.py` ~398K, ~7349 lines, 180 defs. Key recent changes:

### Coordinate tab (`_build_coord_tab` ~3801)
- Title `Coordinate Settings — 2011 Texas State Plane (NAD83 2011) + TXDOT SAF Top-Layer Scaler (from origin 0,0)`
- Hint with TXNC 6M×3M origin story
- **⚙ Manage Coordinate System — 2011 Texas (Import / Save, TXDOT SAF from Origin 0,0)...** button → opens `CoordinateSystemDialog` (see below). Connected to `self._on_coord_manage` (was missing → fixed 16:12).
- Form: `2011 Texas Zone (EPSG)` combo (populated via `epsg_choices_for_combo(DEFAULT_ACTIVE_EPSGS)`), **`TOP LAYER SCALER — TXDOT SAF (first out last in, from origin 0,0)`** QGroupBox with `QLineEdit` `coord_csf_edit` (alias `coord_saf_edit`/`coord_saf_value`) + `coord_saf_info` label auto-updates `1.0=grid / >1 ground larger`. Hidden compat `coord_is_ground_cb` (QCheckBox) + `coord_mode_combo` (ground_to_grid) auto-synced from SAF `!=1`.
- Active 2011 Library combo, buttons `Refresh 2011 List / Import EPSG from Library... / Test Convert / Export KML... (clampToGround)`, status label showing `pyproj ver + SAF mode`, info box.
- Requires `QCheckBox` globally — fixed 16:31 (`from PyQt6.QtWidgets import ... QCheckBox`).

### Dialog `CoordinateSystemDialog` (464)
- Window `Coordinate System Manager — 2011 Texas Only (TXDOT SAF from Origin 0,0)` 700×520
- Top group `TOP LAYER SCALER — First Out Last In (TXDOT SOP)` with RichText `Final Ground = Grid × SAF` and `TXDOT SAF:` QLineEdit
- Middle group `2011 Texas State Plane ... (NAD83 2011 — USft preferred)` with combo filtered to `state==TX and "2011" in name`, sorted North→South, plus `Import... (from library/file)` / `Save to Project` / `Save to File (.json)` / `Load from File` buttons. Save/load JSON `{"epsg":6584,"saf":1.0,"note":"TXDOT SAF from origin..."}`.
- Status label, OK/Cancel.

### Handler `_on_coord_manage` (3927)
- Reads `coord_epsg`/`coord_surface_factor`, opens dialog, on Accept validates `info and "2011" in name` else warning, updates `self.coord_epsg`/factor, syncs `coord_csf_edit`, selects combo, `self._refresh_coord_combos()`, `is_dirty`, refresh canvases, `statusBar`.

### Tools menu (`_create_menus` ~973)
```
Tools
 ├─ Convert Field Book (F2F CSV → .fwb)...
 ├─ Import Carlson Used Ranges... / .grp...
 ├─ Renumber Single / Range... (Master Protected)
 ├─ Export Steps Report CSV / HTML
 ├─ Export to Google Earth (KML)...  (tooltip updated 2011+SAF, clampToGround)
 ├─ Coordinate System Manager... (2011 Texas TXDOT SAF)  → _on_coord_manage  [NEW 09-25]
 ├─ Send Selected Errors to Map... (any error table → KML/QGIS) → _export_selected_errors_to_map [NEW 09-25]
 └─ Show Master Protected Points...
```
`View` still has `Coordinate Settings` (shows coord_tab) for backward compat.

### Map export — any error table by OID (1589+)
- **Methods:**
  - `_collect_selected_oids_from_all_tables()` — deduped OIDs from **any** table with selection: `check_table` OID col2 (N4 E5 Z6 Pt3 Desc7), `desc_parse_table` col0 (N2 E3 Z4 Pt1 Desc5), `line_table` col2 (Pt3 Detail5, no N/E → lookup), `numbering_table` col0 (N2 E3 Z4 Pt1 Desc5), `final_report_table` col3 (Unified, no N/E), `edit_table` col0 (consolidated N2 E3 Z4 Pt1 Desc5). Returns `oid_map, oid_list`.
  - `_write_geojson(dest, working_rows, epsg, factor, mode, is_ground)` — converts each N/E via `convert_to_wgs84` (SAF ÷ from 0,0) → GeoJSON `FeatureCollection` EPSG:4326 with props OID/PtNum/N/E/Z/Desc/EPSG/SAF/ErrorSource/IssueType.
  - `_export_selected_errors_to_map()` — collects OIDs, gets EPSG/SAF (`coord_epsg_combo` or `coord_epsg`, `coord_csf_edit` or `coord_surface_factor`, `coord_is_ground_cb`→ mode), builds `consol_by_oid` from `edit_table`, for each OID: if in consolidated use that row (+ source/issue tags), else use N/E from error row if present, else missing. Then `QFileDialog` `KML/KMZ/GeoJSON/CSV` (defaults `Selected_Errors_Map_{n}pts`), routes to `_write_kml` (existing, clampToGround, colored pins) or `_write_geojson` or CSV with `Lon_WGS84/Lat_WGS84`. Shows QMessageBox with sources summary `Duplicate:3, Line:2` and missing.
- **Context menus:** `_on_error_table_context_menu(table,pos)` — right-click any error table body offers `📍 Send Selected (N) to Map...` + `⚙ Coordinate System Manager...`. Installed via `setContextMenuPolicy(CustomContextMenu)` + `customContextMenuRequested` for `check/desc_parse/line/numbering/final_report` tables. `_on_edit_table_context_menu` also Patched to show `Renumber Point... / Send Selected to Map / Coordinate Manager` menu (instead of direct renumber dialog) and early-delegates non-OID cols to error-table menu.

### Other key methods
- `_refresh_coord_combos()` (3927 next) — enforces 2011-only filter `EPSG_LIBRARY.get(e) and "2011" in name or e==4326`, updates both combos, shows status `pyproj ver — N active (2011 Texas only), TOP-LAYER SAF=... from origin 0,0` vs fallback text.
- `_import_epsg()` (3884) — now migrated + enforces 2011-only, shows `Migrated to 2011 Texas` info if needed.
- `_test_coord_convert()` (3948) — uses `coord_csf_edit` SAF + `is_ground` → `convert_to_wgs84`, message now says `SAF` (was CSF).
- `_export_kml()` (4581) — reads same SAF/is_ground, prompts for `KML/KMZ` path, collects selected OIDs from `edit_table` (or asks All vs Cancel), builds `working_rows` (8-col), calls `_write_kml`.
- `_write_kml()` (~4800) — `convert_to_wgs84` per row, `clampToGround` `<altitudeMode>clampToGround</altitudeMode><coordinates>lon,lat,0`, colored by PtNum, line groups via `parse_desc_field` ST/END, writes via `zipfile` for KMZ.

---

## 4. Workspace Map

```
/home/user/
  FieldworkManager.zip                # Ship — 18 files, program/ + 3 md at root
  FieldworkManager_Project_Handoff_2026-09-25.md  # <- THIS FILE (uploadable)
  README.md (6.9K) ; FUTURE_FIX_TOOLS.md (3.3K) ; fieldwork-manager-profile.md (19K)
  STEPS_REPORT_EXAMPLE.* ; Fieldwork_GoogleEarth_EXAMPLE.kml/kmz
  program/
    Run Fieldwork Manager.bat         # 396 bytes 16:12 — py -3 → python → python3 (9009-only)
    run.py (316)                      # QApplication + MainWindow
    fieldwork_manager/
      __init__.py (983)
      ui_main.py (398K 16:31)         # MainWindow + dialogs + ~10 tabs
      coord_systems.py (14.8K 15:51)  # 2011 Texas ONLY library + SAF
      clean.py (142K)                 # Clean Description dialog
      config.py (14.7K)               # CHECK_REPORT_HEADERS etc, crew_blocks
      io_carlson.py (32.8K)           # FWB/FWK read/write, #EXTRA_JSON
      detectors.py (8.3K)             # duplicate/similar/close NE
      parse.py (19.9K)                # parse_desc_field, line orders
      renumber_tool.py (21.2K)        # single/range renumber
      steps_report.py (16.7K 15:52)   # SAF wording fixed
      utils_sort.py (2K)              # NaturalSortItem
```

**Zip contents (unzip -l):** `program/` + `program/fieldwork_manager/* (9 py + __init__)` + `run.py` + `Run Fieldwork Manager.bat` + `README.md` + `FUTURE_FIX_TOOLS.md` + `fieldwork-manager-profile.md` (excludes `__pycache__/*.pyc`)

---

## 5. Recent Bug Fixes (must keep)

- **2026-09-25 15:30** SAF origin fix verified (ground *1.00014 → divide gives 0.000000° diff); pivoted to 2011 Texas only. Replaced `EPSG_LIBRARY` via `/tmp/patch_coord_2011.py`, `DEFAULT_ACTIVE_EPSGS → [6584,6582,6578,6588,6586,4326]`, `TEXAS_LCC_PARAMS` 10-entry correct meters, `py_compile` ok.
- **2026-09-25 15:49** Added `CoordinateSystemDialog` + `_build_coord_tab` rewrite (TOP LAYER SCALER group, hidden compat CB, auto SAF label), `_on_coord_manage` insertion, `steps_report` CSF→SAF wording, zip 152K→157K.
- **2026-09-25 16:00** Added **Tools > Send Selected Errors to Map** (`_collect_selected_oids...`, `_write_geojson`, `_export_selected_errors_to_map`) + Tools menu Coordinate Manager, zip 163K.
- **2026-09-25 16:12** **AttributeError: _on_coord_manage missing** — file had 3 refs but no def (lost after re-patches). Re-inserted before `_refresh_coord_combos`, fixed `Run Fieldwork Manager.bat` to `if %errorlevel%==9009` only, zip re-made.
- **2026-09-25 16:31** **NameError: QCheckBox not defined** at `ui_main.py:3852` `self.coord_is_ground_cb = QCheckBox(...)` because global import lacked `QCheckBox`. Patched `from PyQt6.QtWidgets import ... QCheckBox` + local import in `_build_coord_tab`, re-zipped 163K 16:31. **Current HEAD is this fix.**
- Previous dead ends: `TEXAS_LCC_PARAMS` wrong mapping gave lat 52-60 error ~28°, fixed via `CRS.to_json_dict()` per EPSG.

---

## 6. Build / Verify / Launch

```bash
python3 -m py_compile program/fieldwork_manager/*.py  # all ok (180 defs)
# or
py -3 program/run.py
python program/run.py
# Windows double-click
program/Run Fieldwork Manager.bat
# Rezip
cd /home/user && rm -f FieldworkManager.zip && zip -r FieldworkManager.zip program README.md FUTURE_FIX_TOOLS.md fieldwork-manager-profile.md -x "*/__pycache__/*" "*/__pycache__" "*.pyc"
unzip -l FieldworkManager.zip
```

**Verify after launch:**
1. `Tools > Coordinate System Manager` should open 700×520 dialog listing 11 EPSGs, SAF edit, Import/Save.
2. Run checks to populate error tabs → select rows in any error table (Ctrl+Click) → `Tools > Send Selected Errors to Map` → save KML and open in Google Earth (clampToGround) or save GeoJSON and drag into QGIS.

---

## 7. Known Behaviors / Notes for Next Chat

- `QCheckBox` must stay in global QtWidgets import — hidden compat CB depends on it.
- `_on_coord_manage` must stay in `MainWindow` before any `_build_coord_tab` connect; class order doesn't matter at runtime but keep def present.
- `DEFAULT_ACTIVE_EPSGS` is source of truth for 2011; `_refresh_coord_combos` filters any legacy saved in `.fmp` via `migrate_active_list`.
- `check_table`/`desc_parse_table` have local N/E; `line_table`/`final_report` rely on `edit_table` lookup — missing OIDs go to `missing` list and warn.
- `convert_to_wgs84` always divides by SAF from **0,0** when `is_ground` True (which auto-syncs from `SAF!=1` via `_auto_saf` lambda in coord tab). No CSF, no base point.
- `steps_report.py` no longer mentions CSF; uses `2011 Texas State Plane + TXDOT SAF top-layer (from origin 0,0)`.
- No UTM/CONUS fallback expected — `pyproj` missing will still allow Texas 2011 via pure-python, but UTM needs pyproj (info in status).
- OneDrive path `C:/Users/codyc/OneDrive/Documents/FieldworkManager` has spaces — batch uses `"%~dp0"` correctly.

---

## 8. Uploadable Prompt for Next Chat (copy-paste)

> You are continuing `Fieldwork Manager` (Mesquite TX, 2011 Texas State Plane ONLY + TXDOT SAF top-layer from origin 0,0). Workspace at `/home/user`, ship `FieldworkManager.zip` 163K 16:31 (program/fieldwork_manager/*, run.py, Run Fieldwork Manager.bat). Current HEAD fixes: `_on_coord_manage` re-added (was AttributeError), `QCheckBox` added to global import (was NameError at 3852). Recent feature: `Tools > Send Selected Errors to Map (any error table by OID → KML/KMZ clampToGround for Google Earth or GeoJSON for QGIS)` via `_collect_selected_oids_from_all_tables` + `_write_geojson` + context menus on all error tables. Coordinate lib is 2011 Texas ONLY (6581/6582 North, 6583/6584 North Central default 6584, 6577/6578 Central, 6587/6588 South Central, 6585/6586 South +4326) with correct LCC params (see `TEXAS_LCC_PARAMS`) and SAF `Ground=Grid*SAF` from 0,0. See `FieldworkManager_Project_Handoff_2026-09-25.md` for full map, bug history, and build steps. Ask before guessing.

---

## 9. File Stats (for reference)

```
coord_systems.py  14.8K  14.8K  lines ~260  2026-09-25 15:51
ui_main.py       398K   7349 lines  2026-09-25 16:31  (was 363K 15:52 → 395K 16:12)
steps_report.py  16.7K            2026-09-25 15:52
FieldworkManager.zip 163K 702K uncompressed 18 files
```

EPSG_LIBRARY keys: [4326, 6577, 6578, 6581, 6582, 6583, 6584, 6585, 6586, 6587, 6588]
DEFAULT_ACTIVE_EPSGS: [6584, 6582, 6578, 6588, 6586, 4326]
MESQUITE_TX_RECOMMENDED_EPSG: 6584
TEXAS_LCC_PARAMS keys: [6577, 6578, 6581, 6582, 6583, 6584, 6585, 6586, 6587, 6588]

---

## 10. Contact / Paths

- Dev: `codyc` @ OneDrive `FieldworkManager`
- Approx location: Mesquite, TX, US (America/Chicago)
- Date trust: 2026-09-25 local

--- END OF HANDOFF ---
