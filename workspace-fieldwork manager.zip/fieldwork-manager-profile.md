# Fieldwork Manager — Working Profile & Study Recap

**DURABLE FILE — changes rarely, but retired single-file era 2026-09-23.** See `README.md` for current modular layout. The original `fieldwork benchmark.pdf` was **retired and deleted on 2026-09-18**; `error_catalog.md` and `test_fieldwork_manager.py` retired 2026-09-23.

| File | Role |
| :--- | :--- |
| `fieldwork-manager-profile.md` | This file: who you are, how to work with you, durable domain rules, study recaps (still current for domain/sorts) |
| `program/run.py` + `program/fieldwork_manager/*` | The app itself — modular workspace copy of record (see README.md) |
| `FieldworkManager_v1.0001.zip` | Ship — `program/` zipped |

**Versioning policy (retired single-file, kept for history):** Old policy was major milestones iterate `fieldwork_manager_v1.py → _v2.py` and archived. Current: modular `program/fieldwork_manager/` edited in place; ship re-zipped as `FieldworkManager_v1.0001.zip`. No `APP_MODULE` dial anymore.

**Candidate workflow (retired 2026-09-23):** Previously unreviewed changes went into `fieldwork_manager_v1-1.py` candidate file. Now deprecated — agent edits `program/fieldwork_manager/*.py` directly.

**Workflow — agent edits workspace files directly:** the agent changes the shared-workspace copies in `program/`, verifies with `python -m py_compile` + offscreen smoke, then the user copies the whole `program/` or zip. No chat copy-paste of code blocks. Every batch of changes ships with a **layman explanation** — WHAT changed and WHY, in plain language with jargon defined — plus verification steps.

---

## 1. Who You Are

- Prefer to stay anonymous; if a name must be used: **Ann Anya Mist**.
- Learning **Python + PyQt6 at the same time**. Beginner-to-early-intermediate in Python, new to Qt, but very hands-on and self-directed.
- **Domain expert: Land Surveying.** You know exactly what the tool must do in the real world.
- Building a real tool, not a tutorial toy: **Fieldwork Manager**.

## 2. Your Learning Style

1. **Notes-first, then build.** You started with handwritten notes: `variable = ClassName(args)`, `app = QApplication([])`, `window.show()`, `app.exec()`. Understand *why* before building.
2. **Fundamentals through analogies.** `super().__init__()` = "build the foundation before adding the bedroom"; `sys.argv` = Argument Vector; Parent-Child = memory ownership.
3. **Learn by breaking and fixing.** Paste the full traceback; learn to *read* it bottom-up, not just get a fix.
4. **Incremental, not waterfall.** "lets wait on filtering until we get to this part but we can implement sorting now" — finish one feature cleanly before adding the next.
5. **Try it yourself first.** You split Settings into `ProjectPathsDialog` + `PrecisionDialog` on your own, then asked for help crossing the finish line.

## 3. How You Want to Communicate

1. **Workspace-first edits, layman explanations.** The agent edits the workspace `.py` files directly and re-runs the test suite; the user copies whole files. In chat: WHAT changed and WHY in plain language (2–3 lines per change, jargon defined), plus verification steps. No 600-line regenerations in chat, no line-by-line pasting unless asked.
2. **Explain the why in 2–3 lines.**
3. **Show verification.** ("Click Point Number header, you should see 1,3,6,6a,6b,15,a2,a4,a20")
4. **Tables, summaries, checklists.**
5. **End with a mission.**
6. **Respect the code.** Don't rename variables unless needed. Keep Qt conventions: `parent=None`, `if __name__ == "__main__":`, `sys.exit(app.exec())`.

## 4. What Works Best With You

- Small fix first, then the concept behind it.
- When a full file is pasted, scan for **duplicate blocks** (the blank-Description bug was a duplicated Point Number block overwriting column 4).
- Define Qt jargon on first use: `QStackedWidget` = "deck of cards", `lambda` = "tiny anonymous function".
- Windows quirks: spaces in paths (`ai learning 3.py` → needs quotes), terminal holding open with "Press any key", needing the `.py` extension.
- When a feature split has a cost difference, call it out: **rescan disk** (slow, do rarely) vs **redraw table** (cheap).

## 5. What To Avoid

- Regenerating 600 lines when 5 lines changed.
- **String-sorting numbers.** Correct survey sorting is non-negotiable.
- Truncating instead of rounding.
- Adding parked features. If told "hold off on field book", don't add field book code.
- QSS / advanced patterns before the core works.

## 6. Starting a New Chat (current modular system)

1. Paste or link: this profile + `README.md` + `program/run.py` + `program/fieldwork_manager/ui_main.py` (or whole `program/` zip).
2. The AI must acknowledge it understands the architecture — `NaturalSortItem` + `natural_key()` with `letters_first`, `NumericSortItem` (stores the float separately from display text), split dialogs (`ProjectPathsDialog` → rescan, `PrecisionDialog` → redraw, `CorrectionRulesDialog` / `LineCommandsDialog` (fillable Command → locked Meaning) → stored in `.fwb` extra), **two dirty flags** (`is_dirty` for the project JSON, `edit_dirty` for the working file + `check_dirty`), persistent hide/show tabs with a View menu, canonical `.fwk` export (OID assigned after folder→point sort) — then **ask what the next incremental step is**.
3. Changes land in `program/fieldwork_manager/*.py`, verified with `py_compile` + offscreen smoke, the user copies the `program/` folder or `FieldworkManager_v1.0001.zip`: done.

## 7. Environment

| Item | Value |
| :--- | :--- |
| OS | Windows |
| Python | *(fill in from mission below)* |
| PyQt6 | *(fill in from mission below)* |
| Filenames | Spaces in paths — quote them in terminal |

**Mission (run once):**
```
python -c "import sys, PyQt6.QtCore; print(sys.version.split()[0], PyQt6.QtCore.PYQT_VERSION_STR)"
```

---

## 8. Domain Reference (durable rules — do not change without asking)

### File format
- **5-column CSV, no header:** `Point Number,Northing,Easting,Elevation,Description`
- Nested deep: `project > survey > fieldwork > crew date folder (maybe deeper)`
- Descriptions may contain commas — extra columns get re-joined.
- Scanner: `.csv` only, case-insensitive, recursive (`Path.rglob("*")`).

### Sort conventions
| Column | Rule | Ascending example |
| :--- | :--- | :--- |
| Point Number (0) | Natural sort, **letters-first** | `a2, a4, a20, c43, 1, 3, 6, 6a, 6b, 15` |
| N / E / Z (1–3) | True numeric sort via `NumericSortItem` | smallest → largest |
| Description (4) | Natural sort, **numbers-first** | `1, 2, 3, a, b, c` |

### Rounding convention (decided 2026-09-17)
- **Half-up** (`decimal.ROUND_HALF_UP`) — standard survey practice: `2.5 → 3`, `102.335 → 102.34`.
- **Not** Python's default half-even: `round(2.5)` → 2, `round(102.335, 2)` → 102.33.
- Parse via `Decimal(str(num))` to dodge binary-float artifacts (`round(2.675, 2)` → 2.67, should be 2.68).
- Round, never truncate. Implemented in `_format_decimal` only.

### Sample test data
Save as a CSV under the fieldwork folder; use for sort + rounding verification.

```csv
a2,100002.675,500000.125,102.335,AXLE
a4,100033.21,500044.4455,101.9,BOLT
a20,100050.0,500060.75,100.425,12 OAK
1,100001.5,500005.25,103.15,3 PINE
3,100003.75,500006.0,104.0,AXLE 2
6a,100006.1,500007.3,105.55,1 IRON ROD
6b,100006.2,500007.35,105.6,2 IPF
15,100015.99,500016.125,106.035,BENCHMARK
```

**Expected results:**

| Test | Expected |
| :--- | :--- |
| Sort Point Number asc | `a2, a4, a20, 1, 3, 6a, 6b, 15` |
| Sort Description asc | `1 IRON ROD, 2 IPF, 3 PINE, 12 OAK, AXLE, AXLE 2, BENCHMARK, BOLT` |
| Precision N/E = 2, row a2 | N `100002.68`, E `500000.13` |
| Precision Elev = 2 | a2 Z `102.34`, a20 Z `100.43`, 15 Z `106.04` |

### Working file schema (v2 — 2026-09-18)

The export is a **working file** (start of the editing pipeline), not a deliverable. Headerless by design — in-house structure is always the same. Content is plain CSV, saved with the extension **`.fwk`** (constant `WORKING_FILE_EXT` in code; avoids `.fld`/`.fbk` collisions with other tools).

**File classes:**

| Extension | Class | Home |
| :--- | :--- | :--- |
| `.csv` | Raw field data | Fieldwork tree (scanned recursively, `.csv` suffix only) |
| `.fmp` | Project file (paths, precision, notes) — custom ext, JSON inside | Project folder |
| `.fwk` | Working/edit file | Project folder |
| `.fwb` | Field-book library (distilled Carlson F2F, headered, 6 cols) | Project folder |
| *(future)* | Clean points (fixed numbers/descriptions), geometry fixes | Project folder |

The scanner's `.csv`-only filter means `.fwk` files are ignored by raw scans **by mechanics, not discipline** — file type is differentiated by extension. Convention stays: fieldwork tree = raw data only; project folder = everything the pipeline produces.

| Col | Content | Notes |
| :--- | :--- | :--- |
| 1 | **OID** | Position 1..N at export time, assigned AFTER the canonical sort (Source File path, then Point Number natural letters-first). Arbitrary tracking only — NOT a durable ID. Changes with every export; does not necessarily match on-screen row numbers. |
| 2–6 | RawPoint, RawNorthing, RawEasting, RawElevation, RawDescription | Values as displayed (precision locked at export) |
| 7–8 | Parent Folder, Source File | Provenance metadata |

**Rules:**
- **Append-only schema.** Future metadata (NewPoint, duplicate resolution, fieldbook codes, corrections) is added as NEW columns at the END. Never reorder, insert, or delete columns — position IS the schema.
- **Home = project folder.** The `.fwk` extension makes working files invisible to raw scans anywhere on disk, but project folder remains the intended home for all pipeline files.
- **Project linkage:** the project JSON stores `working_file` (path to the `.fwk`). Opening a project reopens its working file into the edit tab automatically; if the file was moved, reattach via **File > Load Edit File (Ctrl+E)**. Changing the link marks the project dirty so it must be saved.
- Metadata grows over time; stripped-down data views are built FROM the full working file, never by deleting from it.

**Rules:**
- **Append-only schema.** Future metadata (NewPoint, duplicate resolution, fieldbook codes, corrections) is added as NEW columns at the END. Never reorder, insert, or delete columns — position IS the schema.
- **Home = project folder.** The `.fwk` extension makes working files invisible to raw scans anywhere on disk, but project folder remains the intended home for all pipeline files.
- **Project linkage:** the project JSON stores `working_file` (path to the `.fwk`). Opening a project reopens its working file into the edit tab automatically; if the file was moved, reattach via **File > Load Edit File (Ctrl+E)**. Changing the link marks the project dirty so it must be saved.
- Metadata grows over time; stripped-down data views are built FROM the full working file, never by deleting from it.

### Field-book library schema (v1 — 2026-09-19)

Headered, never sorted, Model A artifact — generated from Carlson F2F CSV, reconverted when Carlson changes. Extension `.fwb` (`FIELDBOOK_EXT`).

| Col | Content | Notes |
| :--- | :--- | :--- |
| 1 | Code | From Carlson `Code` |
| 2 | Description | From `Description` — quoted commas preserved (`"1/2"" cirf"` → `1/2" cirf`) |
| 3 | Symbol | From `Symbol` (e.g. `CG08`, `Iron_Pin_Found`) |
| 4 | Layer | From `Layer` (e.g. `V-SITE-DEFAULT`) |
| 5 | Entity Type | From `Entity Type` mapped 0→Point,1→Line,2→2D Polyline,3→3D Polyline; unknown codes kept as-is with warning |
| 6 | Category | From `Category,<name>` group rows; rows before first group get `Default`; blank row 2 is skipped; source order preserved (never sorted) |

Rules: **headered** (field data CSVs stay headerless); **append-only** (future `Symbol Size` etc add at END); home = project folder; JSON stores `fieldbook_file`; `Tools > Convert Field Book (F2F CSV → .fwb)...` picks source CSV then save `.fwb` (defaults to project folder), auto-wires path and opens **Field Book** tab (read-only viewer). Viewer is **View → Field Book** (hide/show). `Check File` if no book prompts `Pick an existing file now?` and loads viewer.


---

## Project Status Log (rolling, newest first)

- **2026-09-19 (merge)** — Field-book converter + viewer shipped and merged: `Tools > Convert Field Book (F2F CSV → .fwb)...` (Model A, headered 6 cols `Code,Desc,Symbol,Layer,Entity Type,Category`, `Default` before first `Category`, blank row 2 handled, quoted descs kept, never sorted, lean ~92 KB from 250+ col source), **Field Book** viewer tab (read-only, 4 tabs at startup, `View → Field Book`), `Settings > Project Paths` 3rd field `Field Book (.fwb)`, JSON `fieldbook_file`, `Check File` guard prompts to pick, Edit tab gets `Open Edit File...` button. `fieldwork_manager_v1-1.py` folded into `fieldwork_manager_v1.py`, candidate deleted, `APP_MODULE` re-pointed, **106-check suite green**.
- **2026-09-19** — App renamed `working_fieldwork_v2.py` → **`fieldwork_manager_v1.py`** ("past testing working sets"); versioning + archive policy adopted (bump suffix on major milestones, archive previous). Test dial (`APP_MODULE`) updated. 56-check suite green.
- **2026-09-18** — Three-file handoff adopted; `fieldwork benchmark.pdf` retired/deleted. GUI: movable + closable hide/show tabs, View menu, edit tab exists at startup with empty-state hint, button renamed "Create Edit Fieldwork...". 56-check suite green.
- **2026-09-17/18** — Edit phase shipped end-to-end: canonical `.fwk` export (OID after folder→point sort), edit tab with its own dirty flag + Save/Discard/Cancel, JSON `working_file` link with auto-reopen + Load Edit File (Ctrl+E) relocate, half-up rounding fix, `_fill_row`/`_row_texts` helpers, signal-echo fix in Close Project.
- **Earlier** — View phase (original handoff): recursive scan, combined/single-file views, natural + numeric sorting, split settings dialogs, JSON project persistence.

**Parked roadmap (original priority order):** ① field book path in settings ② Carlson vs custom field book table structure ③ select field books alongside CSVs ④ description filters built from the field book list. **Nearest doors:** Check File implementation (duplicate Point Numbers first), then clean-points file, then geometry fixes. No filtering until field book is done.

---

## 9. Study Recap — Python Fundamentals

| Concept | What you learned |
| :--- | :--- |
| **OOP basics** | `variable = ClassName(args)` creates an *object* from a *class* (blueprint) |
| **`class Child(Parent)`** | Inheritance — "Is-A" rule |
| **`__init__`** | Constructor; runs automatically on creation |
| **`self`** | "This specific object"; shares data via `self.is_dirty` etc. |
| **`super().__init__()`** | Run the parent's setup first (foundation before bedroom) |
| **Default args** | `def __init__(self, path="", parent=None)` — caller can omit them |
| **`sys.argv` / `sys.exit`** | Command-line word list; report 0 (clean) / 1 (error) to OS |
| **`if __name__ == "__main__":`** | Only run when launched directly, not imported |
| **`lambda:`** | Tiny anonymous function; passes arguments to slots |
| **`pathlib.Path`** | `.rglob("*")`, `.suffix`, `.parent.name`, `.relative_to()` |
| **`csv.reader`** | Read headerless CSV rows as lists |
| **`json.dump` / `json.load`** | Save/restore project state |
| **`re.split(r'(\d+)', s)`** | Split text into digit / non-digit chunks |
| **Tuple sort keys** | `(type_code, value)` so Python never compares `int < str` |
| **`decimal.Decimal`** | Exact base-10 rounding; `quantize(quantum, ROUND_HALF_UP)` |
| **f-string `:.nf`** | Fixed-decimal display of a rounded number |
| **Dunder methods** | Override `__lt__` to control comparison |
| **`try / except`** | Graceful fallback when `float()` or file reads fail |
| **`getattr(obj, name, default)`** | Safe attribute lookup |
| **DRY principle** | One helper (`_fill_row`) instead of copy-pasted blocks |

## 10. Study Recap — PyQt6: The Skeleton

```
App -> Window -> Show -> Loop
```

```python
app = QApplication(sys.argv)
window = MainWindow()
window.show()
sys.exit(app.exec())
```

**The 5 Pillars:** ① Subclassing ② Layouts (never `.move(x,y)`) ③ Signals → Slots ④ `QMainWindow` vs `QWidget` vs `QDialog` ⑤ Parent-child ownership (memory, centering, modality)

## 11. Widgets Used

| Widget | Purpose |
| :--- | :--- |
| `QLabel`, `QPushButton`, `QLineEdit`, `QTextEdit` | Basic text / input |
| `QSpinBox` | Numeric input with range |
| `QGroupBox` | Titled settings group |
| `QTabWidget` | Fieldwork / Notes tabs |
| `QSplitter` | Draggable divider, file list vs table |
| `QListWidget` + `QListWidgetItem` | Checkable file list; full path in `UserRole` |
| `QTableWidget` + `QTableWidgetItem` | Points table |
| `QHeaderView` | Column resize mode (`Interactive` vs `Stretch`) |
| `QFileDialog` | Native file/folder pickers |
| `QMessageBox` | Save / Discard / Cancel |
| `QDialog` | Modal settings (`accept()` / `reject()`) |
| `QMenuBar` / `QAction` | Menus, shortcuts, `.triggered.connect()` |

## 12. Key PyQt Patterns

- **Menus:** `addMenu()` → `addAction()` → `setShortcut()` → `triggered.connect()`
- **Modal dialogs:** `if dialog.exec() == QDialog.DialogCode.Accepted:` then pull data via getters
- **`closeEvent`:** intercept X button; `event.accept()` / `event.ignore()`; `self.close()` on Exit reuses the same unsaved-changes check
- **Dirty-state:** `is_dirty` + `_mark_dirty()` + title/status `*`
- **`blockSignals(True/False)`:** stop `itemChanged` while bulk-updating checkboxes
- **`setSortingEnabled(False)` → fill → `(True)`:** don't let Qt re-sort mid-population
- **Custom sort items:** subclass `QTableWidgetItem`, override `__lt__`
- **Rescan ≠ redraw:** paths changed → `_scan_fieldwork()`; display changed → `_update_combined_points()`
- **One row-builder:** `_fill_row()` serves both combined and single-file views

## 13. Debugging Skills

- **Read tracebacks bottom-up:** error type → offending line → call chain
- **"Did you mean…?"** hints catch typos (`setSortcut`)
- **`NameError`** = referenced before defined; **`TypeError: '<' int vs str`** = mixed-type sort key
- **Silent bugs** (blank Description) = duplicate copy-pasted block — no traceback, read the code
- **Exit codes:** `0` clean, `1` Python error, negative = hard crash inside Qt
- **Pre-flight compile check:** `py -m py_compile file.py` — catches stray tokens (a pasted `py` launcher command, missing imports) in 3 seconds, without launching the GUI. Run after every paste.
- **Signal echo:** reset methods must clear flags AFTER clearing widgets that fire signals. `notes.clear()` emits `textChanged` → `_mark_dirty()`, so `is_dirty = False` must come after it, or the project silently re-dirties itself (found by the test suite's Close Project → Open sequence).
- **Verification:** `python -m py_compile program/fieldwork_manager/*.py` + offscreen smoke (`QT_QPA_PLATFORM=offscreen python -c "from PyQt6..."`) after any structural change. Old `test_fieldwork_manager.py` 106-check suite retired 2026-09-23 with the single-file era.
