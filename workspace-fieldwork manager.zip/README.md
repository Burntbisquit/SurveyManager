# Fieldwork Manager — Current (Modular)

> Workspace is source of truth. Code lives in `program/fieldwork_manager/` — launched via `program/run.py` or `program/Run Fieldwork Manager.bat`.

## Launch

```bash
# Windows (double-click)
program/Run Fieldwork Manager.bat

# Or
py -3 program/run.py
python program/run.py

# Compile check (no GUI)
python -m py_compile program/fieldwork_manager/*.py
```

## Workspace Map (current)

```
/home/user/
  program/
    Run Fieldwork Manager.bat   # Windows launcher -> run.py
    run.py                      # Entry point: QApplication + MainWindow
    fieldwork_manager/
      __init__.py
      ui_main.py                # MainWindow, all tabs, dialogs (3485 lines)
      clean.py                  # Clean Description dialog, autocorrect w/ " - "
      parse.py                  # parse_desc_field, _validate_line_command_order
      config.py                 # LINE_COMMAND_DEFAULTS / LABELS (ST/PC/PT/END/X → Start Line/Curve/End...), get_command_set(), get_correction_rules()
      io_carlson.py             # read/write .fwb with #EXTRA_JSON single-file (commands first, rules last), read/write .fwk/.chk
      detectors.py              # ExactDuplicate / SimilarNumber / CloseNE (0.1 + 0.1 elev)
      utils_sort.py             # NaturalSortItem, NumericSortItem, _format_decimal (half-up)
  FieldworkManager_v1.0001.zip  # Ship — contains entire program/ folder (12 files)
  README.md                     # This file
  fieldwork-manager-profile.md  # Durable domain rules + study recaps (still useful, but version history is dated)
  FUTURE_FIX_TOOLS.md           # Flags → Actions plan (4 tools)
  uploads/                      # Real job data (CARLSON F2F.csv, Edit points.fwk) — archived, not deleted
```

No `fieldwork_manager_v1.py` single-file in root — that era is retired. No `error_catalog.md` (removed 2026-09-23). No `build.py` / single-file bundle — ship is the modular `program/` zip.

## Workflow (current)

1. **Scan** Fieldwork folder (`.csv` only, `.fwk` ignored) → combined table (natural sorts: PtNum letters-first, Desc numbers-first, N/E/Z half-up rounding)
2. **Create Edit Fieldwork** → canonical sort (SourceFile → PtNum) + OID 1..N → `.fwk` (8-col: OID,PtNum,N,E,Z,Desc,Parent,Source) — lives in project folder, `Edit Fieldwork` tab
3. **Field Book** — `Tools > Convert Field Book (F2F CSV → .fwb)...` or `File > Open Field Book...` → `.fwb` (headered 6 cols: Code,Description,Symbol,Layer,Entity Type,Category) + per-file extras `#EXTRA_JSON` single-file (commands first — fixed, rules last — append) for **Correction Rules** and **Line Commands (Start Line / Start Curve / End Curve / End Line / Close)**. Viewer in `Field Book` tab (read-only).
4. **Settings**
   - `Settings > Project Paths...` — Fieldwork / Project / Field Book (.fwb)
   - `Settings > Precision...` — N/E and Elev decimals (display only, half-up)
   - `Settings > Correction Rules...` — 2-column table Common Error → Fix (Field Book code). Stored in the `.fwb` file itself, travels with it. Autocorrect checks rules first (exact case-insensitive, dash/space tolerant).
   - `Settings > Line Commands...` — 2-column table: **fillable Line Command** → **locked Meaning** (defaults ST=Start Line, PC=Start Curve, PT=End Curve, END=End Line, X=Close; prompts on Field Book creation). Stored in the `.fwb`; `parse.py` and `Check Settings` protect toggles respect it.
   - `Check Settings` tab — protects: ST→PC, PT→END, PT→X, orphan, PC-after-END, ST-after-END + tan placeholder
5. **Run Checks**
   - `Tools > Run Checks (All)...` or Edit tab `Run Checks` button — requires Edit `.fwk`; if no Field Book selected, warns and prompts to pick one *before* the Save dialog (no save without Field Book)
   - Writes unified `.chk` (OID-minimal, DisplayTab routed) → reveals `Duplicate Error`, `Description Error`, `Close NE` tabs (hidden at startup, `View` to restore)
   - Duplicate: ExactDuplicate / SimilarNumber / CloseNE (pseudo-Euclidean N=X, E=Y, dist sqrt(dN²+dE²), XY ≤0.1 + elev ≤0.1, ≥2 distinct numbers)
   - Description: flagged-only `UnknownCode | OrphanCommand | MisplacedAfterSlash | LineOrderError` — tolerant dash/space, no leading strip, trailing digits only on exact miss, orphan one-per-code, slash-split, `Check Settings` line-order validation

## Unified .chk Contract

```
Headers = [GroupID, DisplayTab, IssueType, OID, Flags, Detail, FlagDetail, Status, Comments]
DisplayTab = Duplicate | Description
Duplicate IssueType = ExactDuplicate | SimilarNumber | CloseNE — Flags empty
Description IssueType = UnknownCode | OrphanCommand | MisplacedAfterSlash | LineOrderError | Multiple
```
Raw PtNum/N/E/Z/Desc pulled live via OID → Edit table / .fwk (not stored in .chk). Legacy 13-col still reads.

## Tabs (startup)

5 visible: `Fieldwork | Notes | Edit Fieldwork | Field Book | Check Settings`. Duplicate/Description/Close NE hidden until `Run Checks`. All tabs movable/closable, `View` menu restores. `Edit Fieldwork` has `Open Edit File...` + `Run Checks` (enabled as soon as consolidated `.fwk` is loaded, even without Field Book).

## Cleaning Descriptions

`Description Error` row → double-click → `CleanDescriptionDialog`:
- Best guess from field book (Levenshtein + trailing-digit strip) **or** autocorrect pulling valid codes → rebuilt with ` - ` between groups
- Options: **Fix** (apply best guess), **Key-In Fix Token**, **Ignore/Remove** (existing correction shown in single `Existing Correction/Ignore` field), **Key-In Entire**
- Validates `F2F` + line-order before accept; updates Edit Desc live

## Project File (`.fmp`)

Custom extension `*.fmp` — JSON inside. Testing only, no legacy `*.json` — abandon. Save/Load via `File > Save / Save As... / Open` (`Fieldwork Manager Project (*.fmp)`).

```json
// example.fmp — JSON content
{
  "project_path": "...",
  "fieldwork_path": "...",
  "fieldbook_file": "...fwb",
  "check_report_file": "...chk",
  "working_file": "...fwk",
  "ne_decimals": 5, "elev_decimals": 5,
  "notes": "..."
}
```

## Ship

`FieldworkManager_v1.0001.zip` — `zip -r program` (excludes `__pycache__`). Contains `program/Run Fieldwork Manager.bat` + `program/run.py` + `program/fieldwork_manager/*`.

## What Was Removed 2026-09-23

- `error_catalog.md` — 10-year taxonomy shell (empty template) — deleted per cleanup
- Legacy references to `fieldwork_manager_v1.py` single-file, `build.py`, `APP_MODULE` candidate workflow — now outdated; this README replaces them
- `test_fieldwork_manager.py` — old 106-check single-file regression (points at non-existent module) — removed (not serving current modular code)

## Remaining Docs

- `fieldwork-manager-profile.md` — durable learning/domain reference; version history inside is dated but domain rules/sorts/rounding still valid
- `FUTURE_FIX_TOOLS.md` — 4-tool plan for flagged → action; still current (reference to error_catalog removed)
